import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import net from 'node:net';
import * as cheerio from 'cheerio';
import type { DomElementRef, PageSnapshot } from './src/types/browser.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

function isBlockedHostname(hostname: string): boolean {
  const lower = hostname.toLowerCase();
  if (
    lower === 'localhost' ||
    lower === 'ip6-localhost' ||
    lower.endsWith('.local') ||
    lower.endsWith('.internal')
  ) {
    return true;
  }

  if (net.isIPv4(lower)) {
    const parts = lower.split('.').map(Number);
    const [a, b] = parts;
    if (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168)
    ) {
      return true;
    }
  }

  if (net.isIPv6(lower)) {
    if (
      lower === '::1' ||
      lower.startsWith('fc') ||
      lower.startsWith('fd') ||
      lower.startsWith('fe80')
    ) {
      return true;
    }
  }

  return false;
}

function resolveAbsoluteUrl(baseUrl: string, rawUrl?: string | null): string | undefined {
  if (!rawUrl) return undefined;
  const trimmed = rawUrl.trim();
  if (
    !trimmed ||
    trimmed.startsWith('javascript:') ||
    trimmed.startsWith('data:') ||
    trimmed.startsWith('mailto:') ||
    trimmed.startsWith('tel:') ||
    trimmed.startsWith('#')
  ) {
    return undefined;
  }
  try {
    return new URL(trimmed, baseUrl).toString();
  } catch {
    return undefined;
  }
}

function sanitizeAndBuildMobilePage(html: string, finalUrl: string): Omit<PageSnapshot, 'isExternal' | 'fetchLatencyMs' | 'statusCode'> {
  const $ = cheerio.load(html);

  // Remove dangerous or noisy elements
  $('script, noscript, iframe, object, embed, style, link[rel="preload"], svg path').remove();
  $('*').each((_, el) => {
    const attribs = (el as unknown as { attribs?: Record<string, string> }).attribs;
    if (!attribs) return;
    for (const attr of Object.keys(attribs)) {
      if (attr.toLowerCase().startsWith('on')) {
        $(el).removeAttr(attr);
      }
    }
  });

  const title = $('title').first().text().trim() || new URL(finalUrl).hostname;

  // Rewrite relative URLs for images, links, forms
  $('a[href]').each((_, el) => {
    const abs = resolveAbsoluteUrl(finalUrl, $(el).attr('href'));
    if (abs) $(el).attr('href', abs);
  });
  $('img[src]').each((_, el) => {
    const abs = resolveAbsoluteUrl(finalUrl, $(el).attr('src'));
    if (abs) {
      $(el).attr('src', abs);
      $(el).attr('referrerpolicy', 'no-referrer');
      $(el).attr('loading', 'lazy');
    } else {
      $(el).remove();
    }
  });
  $('form[action]').each((_, el) => {
    const abs = resolveAbsoluteUrl(finalUrl, $(el).attr('action'));
    if (abs) $(el).attr('action', abs);
  });

  // Extract interactive elements and stamp data-compass-ref
  const elements: DomElementRef[] = [];
  let refCounter = 1;

  const interactiveSelector = 'a[href], button, input, select, textarea, [role="button"]';
  $(interactiveSelector).each((_, el) => {
    if (refCounter > 65) return;
    const node = $(el);
    const tag = (el as unknown as { tagName?: string }).tagName?.toLowerCase() || 'div';
    const type = node.attr('type')?.toLowerCase();
    if (tag === 'input' && type === 'hidden') return;

    const href = node.attr('href');
    const placeholder = node.attr('placeholder')?.trim();
    const ariaLabel = node.attr('aria-label')?.trim();
    const rawText = node.text().replace(/\s+/g, ' ').trim();
    const value = node.attr('value')?.trim();
    const name = node.attr('name')?.trim();

    const label = (rawText || ariaLabel || placeholder || value || name || href || tag).slice(0, 90);
    if (!label && tag === 'a') return;

    const refId = refCounter++;
    node.attr('data-compass-ref', String(refId));

    const options: string[] = [];
    if (tag === 'select') {
      node.find('option').each((__, opt) => {
        const optText = $(opt).text().trim();
        if (optText) options.push(optText.slice(0, 50));
      });
    }

    elements.push({
      refId,
      tag,
      role: tag === 'a' ? 'link' : tag === 'button' || node.attr('role') === 'button' ? 'button' : tag,
      label,
      type,
      href,
      placeholder,
      value,
      options: options.length > 0 ? options.slice(0, 12) : undefined,
      disabled: node.attr('disabled') !== undefined,
    });
  });

  // Extract clean text snapshot
  const textBlocks: string[] = [];
  $('h1, h2, h3, h4, p, li, td, th, article, blockquote').each((_, el) => {
    const txt = $(el).clone().children('ul, ol, table').remove().end().text().replace(/\s+/g, ' ').trim();
    if (txt.length > 15 && textBlocks.join('\n').length < 6500) {
      textBlocks.push(txt);
    }
  });
  let text = textBlocks.length > 0
    ? Array.from(new Set(textBlocks)).join('\n').slice(0, 6500)
    : $('body').text().replace(/\s+/g, ' ').trim().slice(0, 6500);

  let bodyHtml = $('body').html() || '';
  if (text.trim().length < 25 && elements.length <= 2) {
    const host = new URL(finalUrl).hostname;
    text = `${host} requires JavaScript or blocked proxy rendering. Try searching for "${host}" in the address bar.`;
    bodyHtml = `<div style="padding:16px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc;">
      <h2 style="margin:0 0 8px;border:none;">Page Preview Unavailable</h2>
      <p style="margin:0 0 12px;">${host} returned an empty or JavaScript-only page.</p>
      <a href="https://html.duckduckgo.com/html/?q=${encodeURIComponent(host)}&kl=us-en" data-compass-ref="1">Search ${host} results</a>
    </div>`;
    if (elements.length === 0) {
      elements.push({
        refId: 1,
        tag: 'a',
        role: 'link',
        label: `Search ${host} results`,
        href: `https://html.duckduckgo.com/html/?q=${encodeURIComponent(host)}&kl=us-en`,
      });
    }
  }

  const renderedHtml = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 16px 14px 48px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      font-size: 14px;
      line-height: 1.55;
      color: #0f172a;
      background: #ffffff;
      word-break: break-word;
    }
    img { max-width: 100%; height: auto; border-radius: 8px; display: block; margin: 10px 0; }
    a { color: #1a56db; text-decoration: none; }
    a:hover { text-decoration: underline; }
    h1 { font-size: 20px; line-height: 1.25; margin: 0 0 10px; color: #0f172a; }
    h2 { font-size: 17px; line-height: 1.3; margin: 18px 0 8px; color: #1e293b; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; }
    h3 { font-size: 15px; margin: 14px 0 6px; color: #1e293b; }
    p { margin: 0 0 10px; color: #334155; }
    ul, ol { padding-left: 18px; margin: 0 0 12px; }
    li { margin-bottom: 5px; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 12px; }
    th, td { border: 1px solid #e2e8f0; padding: 6px 8px; text-align: left; }
    th { background: #f8fafc; font-weight: 600; }
    input, select, textarea {
      font: inherit;
      padding: 8px 10px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      background: #f8fafc;
      color: #0f172a;
      max-width: 100%;
    }
    button, input[type="submit"] {
      font: inherit;
      font-weight: 600;
      padding: 8px 14px;
      border-radius: 8px;
      border: 1px solid #1a56db;
      background: #1a56db;
      color: #ffffff;
      cursor: pointer;
    }
    form { display: flex; flex-wrap: wrap; gap: 8px; margin: 10px 0; align-items: center; }
    nav, header, footer { margin-bottom: 12px; }
    [data-compass-active="true"] {
      outline: 2.5px solid #1a56db !important;
      outline-offset: 2px !important;
      background-color: rgba(26, 86, 219, 0.1) !important;
      border-radius: 4px;
      transition: outline 0.15s ease;
    }
  </style>
</head>
<body>
  ${bodyHtml}
  <script>
    (function() {
      document.addEventListener('click', function(e) {
        const link = e.target.closest('a[href]');
        if (link) {
          e.preventDefault();
          const href = link.getAttribute('href');
          if (href) {
            window.parent.postMessage({ type: 'compass-navigate', url: href }, '*');
          }
        }
      }, true);

      document.addEventListener('submit', function(e) {
        e.preventDefault();
        const form = e.target;
        const action = form.getAttribute('action') || ${JSON.stringify(finalUrl)};
        const method = (form.getAttribute('method') || 'GET').toUpperCase();
        const data = new FormData(form);
        const params = new URLSearchParams();
        for (const [k, v] of data.entries()) {
          if (typeof v === 'string') params.append(k, v);
        }
        if (method === 'GET') {
          const targetUrl = new URL(action, ${JSON.stringify(finalUrl)});
          for (const [k, v] of params.entries()) targetUrl.searchParams.set(k, v);
          window.parent.postMessage({ type: 'compass-navigate', url: targetUrl.toString() }, '*');
        } else {
          window.parent.postMessage({ type: 'compass-navigate', url: action, method: 'POST', formBody: params.toString() }, '*');
        }
      }, true);

      window.addEventListener('message', function(event) {
        const msg = event.data;
        if (!msg || typeof msg !== 'object') return;

        document.querySelectorAll('[data-compass-active]').forEach(el => el.removeAttribute('data-compass-active'));

        if (msg.type === 'compass-scroll') {
          const dir = msg.direction;
          if (dir === 'top') window.scrollTo({ top: 0, behavior: 'smooth' });
          else if (dir === 'bottom') window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
          else if (dir === 'up') window.scrollBy({ top: -380, behavior: 'smooth' });
          else window.scrollBy({ top: 380, behavior: 'smooth' });
        }

        if (msg.type === 'compass-action' && msg.refId) {
          const target = document.querySelector('[data-compass-ref="' + msg.refId + '"]');
          if (!target) return;
          target.setAttribute('data-compass-active', 'true');
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });

          if (msg.action === 'type') {
            if ('value' in target) {
              target.focus();
              target.value = msg.text || '';
              target.dispatchEvent(new Event('input', { bubbles: true }));
              target.dispatchEvent(new Event('change', { bubbles: true }));
            }
            if (msg.submitAfter && target.form) {
              target.form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
            }
          } else if (msg.action === 'click') {
            setTimeout(function() {
              if (target.tagName === 'A' && target.getAttribute('href')) {
                window.parent.postMessage({ type: 'compass-navigate', url: target.getAttribute('href') }, '*');
              } else if (target.type === 'submit' && target.form) {
                target.form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
              } else {
                target.click();
              }
            }, 350);
          } else if (msg.action === 'select' && target.tagName === 'SELECT') {
            for (let i = 0; i < target.options.length; i++) {
              if (target.options[i].value === msg.optionValue || target.options[i].text.includes(msg.optionValue)) {
                target.selectedIndex = i;
                target.dispatchEvent(new Event('change', { bubbles: true }));
                break;
              }
            }
          }
        }
      });
    })();
  </script>
</body>
</html>`;

  return {
    url: finalUrl,
    title,
    text,
    elements,
    renderedHtml,
  };
}

interface AgentMessagePart {
  text?: string;
  functionCall?: {
    id?: string;
    name?: string;
    args?: Record<string, unknown>;
  };
  functionResponse?: {
    id?: string;
    name?: string;
    response?: Record<string, unknown>;
  };
}

interface AgentContent {
  role?: string;
  parts?: AgentMessagePart[];
}

interface OpenRouterToolCall {
  id?: string;
  type?: string;
  function?: {
    name?: string;
    arguments?: string;
  };
}

interface OpenRouterMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | null;
  tool_calls?: OpenRouterToolCall[];
  tool_call_id?: string;
}

const DEFAULT_OPENROUTER_MODEL = 'baidu/ernie-5.5-flash-preview:free';

const OPENROUTER_TOOLS = [
  {
    type: 'function',
    function: {
      name: 'navigate_to_url',
      description:
        'Navigate the active Android browser tab to an https:// URL or built-in portal (compass://home, compass://shop, compass://flights, compass://bank, compass://mail).',
      parameters: {
        type: 'object',
        properties: {
          url: { type: 'string', description: 'Full URL starting with https:// or compass://' },
          reason: { type: 'string', description: 'Short reason for navigation.' },
        },
        required: ['url', 'reason'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'open_web_search',
      description:
        'Run a live web search inside the Android browser WebView on DuckDuckGo or Wikipedia.',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Search query text.' },
          engine: {
            type: 'string',
            enum: ['duckduckgo', 'wikipedia'],
            description: 'Search engine: "duckduckgo" or "wikipedia".',
          },
        },
        required: ['query', 'engine'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'click_element',
      description:
        'Tap an interactive element (button, link, card, tab, checkbox) on the current webpage using its numeric ref_id.',
      parameters: {
        type: 'object',
        properties: {
          ref_id: { type: 'integer', description: 'Numeric refId from the current page elements snapshot.' },
          element_description: { type: 'string', description: 'Short label of the element being tapped.' },
        },
        required: ['ref_id', 'element_description'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'type_text',
      description: 'Focus an input/textarea by ref_id, type text into it, and optionally submit.',
      parameters: {
        type: 'object',
        properties: {
          ref_id: { type: 'integer', description: 'Numeric refId of the input/textarea.' },
          text: { type: 'string', description: 'Exact text to enter.' },
          submit_after: { type: 'boolean', description: 'Whether to submit immediately after typing.' },
        },
        required: ['ref_id', 'text', 'submit_after'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'select_option',
      description: 'Choose an option inside a <select> dropdown element.',
      parameters: {
        type: 'object',
        properties: {
          ref_id: { type: 'integer', description: 'Numeric refId of the select dropdown.' },
          option_value: { type: 'string', description: 'Visible label or value to select.' },
        },
        required: ['ref_id', 'option_value'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'scroll_page',
      description: 'Scroll the Android WebView vertically.',
      parameters: {
        type: 'object',
        properties: {
          direction: {
            type: 'string',
            enum: ['down', 'up', 'top', 'bottom'],
            description: 'Scroll direction.',
          },
        },
        required: ['direction'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'manage_tabs',
      description: 'Create a new tab, switch tabs, or close a tab.',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['new', 'switch', 'close'],
            description: 'Tab operation.',
          },
          tab_id: { type: 'string', description: 'Target tab ID when switching or closing.' },
          url: { type: 'string', description: 'Optional URL for new tab.' },
        },
        required: ['action'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'go_back',
      description: 'Navigate backward in tab history.',
      parameters: {
        type: 'object',
        properties: {
          reason: { type: 'string', description: 'Reason for going back.' },
        },
        required: ['reason'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'go_forward',
      description: 'Navigate forward in tab history.',
      parameters: {
        type: 'object',
        properties: {
          reason: { type: 'string', description: 'Reason for going forward.' },
        },
        required: ['reason'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'reload_page',
      description: 'Reload the active Android browser tab.',
      parameters: {
        type: 'object',
        properties: {
          reason: { type: 'string', description: 'Reason for reloading.' },
        },
        required: ['reason'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'manage_bookmarks',
      description: 'Add, list, or remove browser bookmarks.',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['add', 'list', 'remove'],
            description: 'Bookmark action.',
          },
          url: { type: 'string', description: 'Optional URL to bookmark or remove.' },
          title: { type: 'string', description: 'Optional bookmark title.' },
        },
        required: ['action'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'read_browsing_history',
      description: 'Read recent pages visited in the Android browser.',
      parameters: {
        type: 'object',
        properties: {
          limit: { type: 'integer', description: 'Max entries to return (default 10).' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'request_user_confirmation',
      description:
        'Pause and ask user approval before irreversible actions (payment, order checkout, flight booking confirmation, sending email).',
      parameters: {
        type: 'object',
        properties: {
          action_summary: { type: 'string', description: 'Short summary of action awaiting approval.' },
          details: { type: 'string', description: 'Key amounts/recipient/details to verify.' },
          risk_level: {
            type: 'string',
            enum: ['low', 'medium', 'high'],
            description: 'Risk level.',
          },
        },
        required: ['action_summary', 'details', 'risk_level'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'complete_task',
      description:
        'Finish immediately with a short, straight, direct answer (max 1-2 brief sentences, no long explanation).',
      parameters: {
        type: 'object',
        properties: {
          summary: { type: 'string', description: 'Short, direct answer (1-2 sentences max, no filler).' },
          key_findings: {
            type: 'array',
            items: { type: 'string' },
            description: 'Optional max 3 short bullet points.',
          },
        },
        required: ['summary'],
      },
    },
  },
];

const AGENT_SYSTEM_INSTRUCTION = `You are Compass Assistant, an autonomous AI personal assistant controlling an Android mobile browser via tool calls.

Portals: compass://home, compass://shop (store/cart/promo/checkout), compass://flights (search/seat/booking), compass://bank (balances/bills/pay), compass://mail (inbox/reply), plus public https:// sites via navigate_to_url or open_web_search.

Rules:
1. Inspect URL, pageText, and [refId] elements, then act autonomously with tools—never ask the user to click for you.
2. Call request_user_confirmation BEFORE final payments, order placement, flight booking confirmation, or sending emails.
3. SAVED RESPONSE STYLE: No vast explanations. Give short, straight, direct responses only (1-2 brief sentences or max 3 short bullets).`;

function convertContentsToOpenRouterMessages(contents: AgentContent[]): OpenRouterMessage[] {
  const messages: OpenRouterMessage[] = [
    { role: 'system', content: AGENT_SYSTEM_INSTRUCTION },
  ];

  for (const item of contents) {
    const parts = Array.isArray(item.parts) ? item.parts : [];
    const fnResponses = parts.filter((p) => p.functionResponse);
    if (fnResponses.length > 0) {
      for (const p of fnResponses) {
        const fr = p.functionResponse!;
        messages.push({
          role: 'tool',
          tool_call_id: fr.id || fr.name || `call_${messages.length}`,
          content: JSON.stringify(fr.response || {}),
        });
      }
      continue;
    }

    if (item.role === 'model' || item.role === 'assistant') {
      const text = parts
        .map((p) => p.text || '')
        .filter(Boolean)
        .join('\n')
        .trim();
      const toolCalls: OpenRouterToolCall[] = parts
        .filter((p) => p.functionCall?.name)
        .map((p, idx) => ({
          id: p.functionCall!.id || `call_${messages.length}_${idx}`,
          type: 'function',
          function: {
            name: p.functionCall!.name!,
            arguments: JSON.stringify(p.functionCall!.args || {}),
          },
        }));

      messages.push({
        role: 'assistant',
        content: text || null,
        ...(toolCalls.length > 0 ? { tool_calls: toolCalls } : {}),
      });
      continue;
    }

    const userText = parts
      .map((p) => p.text || '')
      .filter(Boolean)
      .join('\n')
      .trim();
    if (userText) {
      messages.push({ role: 'user', content: userText });
    }
  }

  return messages;
}

function safeParseJsonObject(raw?: string): Record<string, unknown> {
  if (!raw || typeof raw !== 'string') return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : {};
  } catch {
    return {};
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      service: 'compass-browser-agent',
      provider: 'openrouter',
      model: process.env.OPENROUTER_MODEL || DEFAULT_OPENROUTER_MODEL,
    });
  });

function isGoogleSearchDomain(hostname: string): boolean {
  const lower = hostname.toLowerCase();
  return lower === 'google.com' || lower === 'www.google.com' || /^www\.google\.[a-z.]{2,}$/.test(lower);
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildEnglishSearchHomeHtml(): string {
  return `<!doctype html>
<html lang="en">
<head><title>Google Search</title></head>
<body>
  <div style="padding-top:36px;max-width:360px;margin:0 auto;">
    <h1 style="font-size:26px;font-weight:700;text-align:center;margin:0 0 6px;color:#0f172a;">Web Search</h1>
    <p style="font-size:12px;text-align:center;color:#64748b;margin:0 0 18px;">English Mobile Search</p>
    <form action="https://html.duckduckgo.com/html/" method="GET" style="display:flex;gap:8px;margin-bottom:20px;">
      <input type="hidden" name="kl" value="us-en" />
      <input type="search" name="q" placeholder="Search the web..." aria-label="Search the web" required style="flex:1;min-height:42px;" />
      <button type="submit" style="min-height:42px;">Search</button>
    </form>
    <div style="border-top:1px solid #e2e8f0;padding-top:14px;">
      <p style="font-size:12px;font-weight:600;color:#475569;margin:0 0 8px;">Quick Links</p>
      <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px;">
        <li><a href="https://en.wikipedia.org/wiki/Main_Page">Wikipedia (English)</a></li>
        <li><a href="https://news.ycombinator.com">Hacker News</a></li>
        <li><a href="https://html.duckduckgo.com/html/?q=latest+technology+news&kl=us-en">Latest Tech News</a></li>
      </ul>
    </div>
  </div>
</body>
</html>`;
}

function unwrapDuckDuckGoHref(rawHref?: string): string | undefined {
  if (!rawHref) return undefined;
  try {
    const resolved = rawHref.startsWith('//') ? `https:${rawHref}` : rawHref;
    const u = new URL(resolved, 'https://html.duckduckgo.com');
    const uddg = u.searchParams.get('uddg');
    if (uddg) return uddg;
    if (u.protocol === 'http:' || u.protocol === 'https:') return u.toString();
  } catch {
    return undefined;
  }
  return undefined;
}

function formatDuckDuckGoResultsHtml(html: string, finalUrl: string): string {
  const $ = cheerio.load(html);
  const parsedUrl = new URL(finalUrl);
  const query = parsedUrl.searchParams.get('q') || $('input[name="q"]').attr('value') || '';

  const cards: string[] = [];
  $('.result, .web-result').each((_, el) => {
    if (cards.length >= 15) return;
    const node = $(el);
    if (node.hasClass('result--ad')) return;

    const titleAnchor = node.find('a.result__a').first();
    const title = titleAnchor.text().replace(/\s+/g, ' ').trim();
    const href = unwrapDuckDuckGoHref(titleAnchor.attr('href'));
    const snippet = node.find('.result__snippet').text().replace(/\s+/g, ' ').trim();
    const displayUrl = node.find('.result__url').text().replace(/\s+/g, ' ').trim();

    if (!title || !href) return;

    cards.push(`
      <article style="padding:12px 0;border-bottom:1px solid #e2e8f0;">
        <div style="font-size:11px;color:#059669;margin-bottom:2px;word-break:break-all;">${escapeHtml(displayUrl || href)}</div>
        <h3 style="margin:0 0 4px;font-size:15px;line-height:1.3;">
          <a href="${escapeHtml(href)}">${escapeHtml(title)}</a>
        </h3>
        ${snippet ? `<p style="margin:0;font-size:13px;color:#475569;line-height:1.45;">${escapeHtml(snippet)}</p>` : ''}
      </article>
    `);
  });

  const bodyContent =
    cards.length > 0
      ? cards.join('\n')
      : '<p style="color:#64748b;padding:12px 0;">No search results found. Try a different English query.</p>';

  return `<!doctype html>
<html lang="en">
<head><title>${escapeHtml(query ? `${query} — Search` : 'Web Search')}</title></head>
<body>
  <form action="https://html.duckduckgo.com/html/" method="GET" style="display:flex;gap:8px;margin:0 0 12px;padding-bottom:12px;border-bottom:1px solid #e2e8f0;">
    <input type="hidden" name="kl" value="us-en" />
    <input type="search" name="q" value="${escapeHtml(query)}" placeholder="Search the web..." aria-label="Search query" style="flex:1;min-height:40px;" />
    <button type="submit" style="min-height:40px;">Search</button>
  </form>
  <div>
    ${bodyContent}
  </div>
</body>
</html>`;
}

  app.post('/api/browser/fetch', async (req: Request, res: Response) => {
    const start = Date.now();
    try {
      const { url, method = 'GET', formBody } = req.body as {
        url?: string;
        method?: string;
        formBody?: string;
      };

      if (!url || typeof url !== 'string') {
        res.status(400).json({ error: 'Missing valid URL parameter.' });
        return;
      }

      let parsed: URL;
      try {
        parsed = new URL(url.startsWith('http://') || url.startsWith('https://') ? url : `https://${url}`);
      } catch {
        res.status(400).json({ error: `Invalid URL format: ${url}` });
        return;
      }

      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        res.status(400).json({ error: 'Only http:// and https:// protocols are supported.' });
        return;
      }

      if (isBlockedHostname(parsed.hostname)) {
        res.status(403).json({ error: 'Access to private or local network hosts is blocked.' });
        return;
      }

      // Google Search blocks server-side fetches with regional Chinese/Japanese or JS-challenge blank pages.
      // Serve a clean English search home on google.com and route /search?q= queries to live English web search.
      if (isGoogleSearchDomain(parsed.hostname)) {
        const googleQuery = parsed.searchParams.get('q')?.trim();
        if (!googleQuery && (parsed.pathname === '/' || parsed.pathname === '/webhp')) {
          const parsedHome = sanitizeAndBuildMobilePage(
            buildEnglishSearchHomeHtml(),
            'https://www.google.com/?hl=en'
          );
          res.json({
            ...parsedHome,
            isExternal: true,
            fetchLatencyMs: Date.now() - start,
            statusCode: 200,
          });
          return;
        }
        if (googleQuery) {
          parsed = new URL(
            `https://html.duckduckgo.com/html/?q=${encodeURIComponent(googleQuery)}&kl=us-en`
          );
        }
      }

      // Ensure DuckDuckGo HTML search stays in English (kl=us-en) instead of server IP region
      if (
        parsed.hostname.toLowerCase().includes('duckduckgo.com') &&
        parsed.pathname.includes('/html') &&
        !parsed.searchParams.has('kl')
      ) {
        parsed.searchParams.set('kl', 'us-en');
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12000);

      const fetchInit: RequestInit = {
        method: method === 'POST' ? 'POST' : 'GET',
        redirect: 'follow',
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          ...(method === 'POST' && formBody
            ? { 'Content-Type': 'application/x-www-form-urlencoded' }
            : {}),
        },
        ...(method === 'POST' && formBody ? { body: formBody } : {}),
      };

      const upstream = await fetch(parsed.toString(), fetchInit);
      clearTimeout(timeout);

      const finalUrl = upstream.url || parsed.toString();
      const finalParsed = new URL(finalUrl);
      if (isBlockedHostname(finalParsed.hostname)) {
        res.status(403).json({ error: 'Redirect target is blocked.' });
        return;
      }

      const contentType = upstream.headers.get('content-type') || '';
      const rawBody = await upstream.text();
      const latency = Date.now() - start;

      if (!contentType.includes('text/html') && !contentType.includes('application/xhtml')) {
        const plainText = rawBody.slice(0, 6000);
        const snapshot: PageSnapshot = {
          url: finalUrl,
          title: finalParsed.hostname,
          isExternal: true,
          fetchLatencyMs: latency,
          statusCode: upstream.status,
          text: plainText,
          elements: [],
          renderedHtml: `<!doctype html><html><body style="font-family:monospace;padding:16px;font-size:13px;white-space:pre-wrap;word-break:break-word;">${plainText
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')}</body></html>`,
        };
        res.json(snapshot);
        return;
      }

      const htmlToRender =
        finalParsed.hostname.toLowerCase().includes('duckduckgo.com') &&
        finalParsed.pathname.includes('/html')
          ? formatDuckDuckGoResultsHtml(rawBody, finalUrl)
          : rawBody;

      const parsedPage = sanitizeAndBuildMobilePage(htmlToRender, finalUrl);
      const snapshot: PageSnapshot = {
        ...parsedPage,
        isExternal: true,
        fetchLatencyMs: latency,
        statusCode: upstream.status,
      };
      res.json(snapshot);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch webpage';
      res.status(502).json({
        error: message.includes('abort') ? 'Page request timed out after 12 seconds.' : message,
      });
    }
  });

  app.post('/api/agent/step', async (req: Request, res: Response) => {
    try {
      const { contents, messages, model } = req.body as {
        contents?: AgentContent[];
        messages?: Array<{ role?: string; content?: string }>;
        model?: string;
      };

      const normalizedContents: AgentContent[] =
        Array.isArray(contents) && contents.length > 0
          ? contents
          : Array.isArray(messages) && messages.length > 0
            ? messages.map((m) => ({
                role: m.role === 'assistant' ? 'model' : 'user',
                parts: [{ text: String(m.content || '') }],
              }))
            : [];

      if (normalizedContents.length === 0) {
        res.status(400).json({ error: 'Conversation contents array is required.' });
        return;
      }

      const apiKey = process.env.OPENROUTER_API_KEY?.trim();
      if (!apiKey || apiKey === 'MY_OPENROUTER_API_KEY') {
        res.status(503).json({
          error: 'OPENROUTER_API_KEY is not configured on the server.',
        });
        return;
      }

      const selectedModel =
        (typeof model === 'string' && model.trim()) ||
        process.env.OPENROUTER_MODEL?.trim() ||
        DEFAULT_OPENROUTER_MODEL;

      const openRouterMessages = convertContentsToOpenRouterMessages(normalizedContents);
      const stepStart = Date.now();

      let upstreamRes: globalThis.Response | null = null;
      let rawText = '';

      for (let attempt = 0; attempt < 3; attempt++) {
        upstreamRes = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            'X-Title': 'Compass Browser',
          },
          body: JSON.stringify({
            model: selectedModel,
            messages: openRouterMessages,
            tools: OPENROUTER_TOOLS,
            tool_choice: 'auto',
            temperature: 0.2,
            max_tokens: 1024,
          }),
        });

        rawText = await upstreamRes.text();
        if (
          (upstreamRes.status === 429 || upstreamRes.status === 502 || upstreamRes.status === 503) &&
          attempt < 2
        ) {
          await new Promise((resolve) => setTimeout(resolve, 450 * Math.pow(2, attempt)));
          continue;
        }
        break;
      }

      if (!upstreamRes || !upstreamRes.ok) {
        let errMessage = `OpenRouter error (${upstreamRes?.status || 500})`;
        try {
          const errJson = JSON.parse(rawText) as { error?: { message?: string } };
          if (errJson.error?.message) errMessage = errJson.error.message;
        } catch {
          if (rawText) errMessage = rawText.slice(0, 220);
        }
        res.status(upstreamRes?.status || 500).json({ error: errMessage });
        return;
      }

      const completion = JSON.parse(rawText) as {
        choices?: Array<{
          message?: {
            content?: string | null;
            tool_calls?: OpenRouterToolCall[];
          };
        }>;
      };

      console.log(
        `[agent/step] provider=openrouter model=${selectedModel} elapsedMs=${Date.now() - stepStart}`
      );

      const message = completion.choices?.[0]?.message;
      const text = typeof message?.content === 'string' ? message.content.trim() : '';
      const rawToolCalls = Array.isArray(message?.tool_calls) ? message.tool_calls : [];

      const toolCalls = rawToolCalls
        .filter((tc) => tc.function?.name)
        .map((tc, idx) => ({
          id: tc.id || `call_${Date.now()}_${idx}`,
          name: tc.function!.name!,
          args: safeParseJsonObject(tc.function?.arguments),
        }));

      const assistantParts: AgentMessagePart[] = [];
      if (text) {
        assistantParts.push({ text });
      }
      for (const tc of toolCalls) {
        assistantParts.push({
          functionCall: {
            id: tc.id,
            name: tc.name,
            args: tc.args,
          },
        });
      }

      res.json({
        assistantContent: {
          role: 'model',
          parts: assistantParts.length > 0 ? assistantParts : [{ text: '' }],
        },
        toolCalls,
        text,
      });
    } catch (err) {
      const rawMessage = err instanceof Error ? err.message : 'OpenRouter agent error';
      res.status(500).json({ error: rawMessage });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Compass Browser server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
