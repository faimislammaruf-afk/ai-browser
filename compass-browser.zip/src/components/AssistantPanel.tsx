import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  BookmarkPlus,
  Check,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Mic,
  MicOff,
  Send,
  ShieldAlert,
  Square,
} from 'lucide-react';
import type { AgentActionLog, ChatMessage } from '../types/browser';

interface AssistantPanelProps {
  messages: ChatMessage[];
  isRunning: boolean;
  currentStepLabel: string | null;
  inputRef?: React.RefObject<HTMLTextAreaElement | null>;
  onSendPrompt: (prompt: string) => void;
  onStopAgent: () => void;
  onConfirmAction: (messageId: string, approved: boolean) => void;
  onSaveRoutine: (prompt: string) => void;
}

const STARTER_PROMPTS = [
  {
    title: 'Cross-App Bill Pay',
    prompt:
      'Check my unread emails in Pulse Mail for any overdue bill, verify the account number and amount, then open Apex Bank and prepare the payment.',
  },
  {
    title: 'Shop & Apply Promo',
    prompt:
      'Go to ShopSphere, find the highest-rated wireless noise-canceling headphones under $250, add to cart, apply promo code SAVE15, and proceed to checkout.',
  },
  {
    title: 'Book Nonstop Flight',
    prompt:
      'Open Horizon Flights, search for nonstop Economy flights from San Francisco to Tokyo under $900, pick window seat 14A, and prepare booking for Alex Mercer.',
  },
  {
    title: 'Browse Live Hacker News',
    prompt:
      'Navigate to https://news.ycombinator.com, inspect the top 5 front-page stories, open the first story, and summarize what it covers.',
  },
];

interface SpeechRecognitionInstance {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

export const AssistantPanel: React.FC<AssistantPanelProps> = ({
  messages,
  isRunning,
  currentStepLabel,
  inputRef,
  onSendPrompt,
  onStopAgent,
  onConfirmAction,
  onSaveRoutine,
}) => {
  const [draft, setDraft] = useState('');
  const [expandedSteps, setExpandedSteps] = useState<Record<string, boolean>>({});
  const [isListening, setIsListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [savedPromptId, setSavedPromptId] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const feedEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionInstance;
      webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
    };
    setVoiceSupported(Boolean(win.SpeechRecognition || win.webkitSpeechRecognition));
  }, []);

  useEffect(() => {
    feedEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, currentStepLabel]);

  const toggleVoice = () => {
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionInstance;
      webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
    };
    const SpeechRec = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SpeechRec) return;

    const rec = new SpeechRec();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = 'en-US';
    rec.onresult = (event) => {
      const lastIdx = event.results.length - 1;
      const transcript = event.results[lastIdx]?.[0]?.transcript || '';
      setDraft(transcript);
    };
    rec.onerror = () => setIsListening(false);
    rec.onend = () => setIsListening(false);
    recognitionRef.current = rec;
    setIsListening(true);
    rec.start();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text || isRunning) return;
    setDraft('');
    onSendPrompt(text);
  };

  const formatActionSummary = (act: AgentActionLog) => {
    const argPreview = Object.entries(act.args || {})
      .filter(([, v]) => v !== undefined && v !== '')
      .map(([k, v]) => `${k}=${typeof v === 'string' ? `"${v.slice(0, 42)}"` : String(v)}`)
      .join(' ');
    return `${act.toolName}(${argPreview})`;
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl border border-slate-200 overflow-hidden">
      {/* Assistant Header */}
      <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between gap-3 shrink-0">
        <div className="min-w-0">
          <h2 className="font-display text-sm font-semibold text-slate-900">
            Personal Browser Assistant
          </h2>
          <p className="text-xs text-slate-500 truncate">
            {isRunning && currentStepLabel
              ? currentStepLabel
              : 'Describe any task — Compass navigates, clicks, types, and verifies'}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="hidden sm:inline text-[11px] font-mono text-slate-500 whitespace-nowrap">
            OpenRouter · baidu/ernie-5.5-flash-preview:free
          </span>

          {isRunning && (
            <button
              type="button"
              onClick={onStopAgent}
              className="min-h-[34px] px-3 rounded-lg border border-red-200 bg-red-50 text-red-700 text-xs font-medium flex items-center gap-1.5 hover:bg-red-100 shrink-0"
            >
              <Square className="w-3 h-3 fill-current" />
              <span>Stop</span>
            </button>
          )}
        </div>
      </div>

      {/* Conversation & Autonomous Execution Feed */}
      <div className="flex-1 overflow-y-auto compass-scroll p-5 space-y-5">
        {messages.length === 0 ? (
          <div className="space-y-5">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900">
                Autonomous Mobile Web Control
              </h3>
              <p className="text-sm text-slate-600 mt-1 leading-relaxed">
                Tell Compass Assistant to browse live websites, compare products, manage inbox items, pay bills, or book travel directly inside the Android viewport.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {STARTER_PROMPTS.map((item) => (
                <button
                  key={item.title}
                  type="button"
                  disabled={isRunning}
                  onClick={() => onSendPrompt(item.prompt)}
                  className="text-left p-3.5 rounded-xl border border-slate-200 hover:border-[#1A56DB] hover:bg-slate-50/80 transition-colors flex flex-col justify-between gap-1.5"
                >
                  <span className="text-xs font-semibold text-slate-900">{item.title}</span>
                  <span className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {item.prompt}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            if (msg.role === 'user') {
              return (
                <div key={msg.id} className="flex flex-col items-end gap-1">
                  <div className="max-w-[88%] rounded-2xl rounded-tr-sm bg-slate-900 text-white px-4 py-2.5 text-sm leading-relaxed">
                    {msg.text}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400">
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        onSaveRoutine(msg.text);
                        setSavedPromptId(msg.id);
                        setTimeout(() => setSavedPromptId(null), 1800);
                      }}
                      className="inline-flex items-center gap-1 text-slate-500 hover:text-[#1A56DB]"
                      title="Save as Automation Routine"
                    >
                      {savedPromptId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span className="text-emerald-700">Saved</span>
                        </>
                      ) : (
                        <>
                          <BookmarkPlus className="w-3 h-3" />
                          <span>Save routine</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            }

            const actions = msg.actions || [];
            const isExpanded = expandedSteps[msg.id] ?? actions.length <= 4;

            return (
              <div key={msg.id} className="space-y-2.5">
                {actions.length > 0 && (
                  <div className="border border-slate-200 rounded-xl bg-slate-50/70 overflow-hidden">
                    <button
                      type="button"
                      onClick={() =>
                        setExpandedSteps((prev) => ({ ...prev, [msg.id]: !isExpanded }))
                      }
                      className="w-full px-3.5 py-2 flex items-center justify-between text-xs font-medium text-slate-700 hover:bg-slate-100/70"
                    >
                      <span className="font-mono tabular-nums">
                        Browser Actions · {actions.length} step{actions.length === 1 ? '' : 's'}
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5 text-slate-500" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                      )}
                    </button>
                    {isExpanded && (
                      <div className="border-t border-slate-200 divide-y divide-slate-200/80">
                        {actions.map((act) => (
                          <div
                            key={act.id}
                            className="px-3.5 py-2 text-[11px] font-mono flex items-start justify-between gap-2"
                          >
                            <div className="min-w-0">
                              <span className="text-slate-500 mr-1.5 tabular-nums">
                                {String(act.step).padStart(2, '0')}.
                              </span>
                              <span className="text-slate-900 break-all">
                                {formatActionSummary(act)}
                              </span>
                              {act.resultSummary && (
                                <div className="text-slate-500 mt-0.5 font-sans">
                                  {act.resultSummary}
                                </div>
                              )}
                            </div>
                            <span
                              className={`shrink-0 font-sans font-medium ${
                                act.status === 'error'
                                  ? 'text-red-600'
                                  : act.status === 'running'
                                    ? 'text-[#1A56DB]'
                                    : act.status === 'paused'
                                      ? 'text-amber-700'
                                      : 'text-emerald-700'
                              }`}
                            >
                              {act.status === 'completed'
                                ? 'Done'
                                : act.status === 'running'
                                  ? 'Running'
                                  : act.status === 'paused'
                                    ? 'Paused'
                                    : 'Error'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Human-in-the-loop Confirmation Prompt */}
                {msg.confirmation && (
                  <div className="border border-amber-300 bg-amber-50/70 rounded-xl p-4 space-y-3">
                    <div className="flex items-start gap-2.5">
                      <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-amber-900">
                          Approval Required · {msg.confirmation.riskLevel.toUpperCase()} Risk
                        </div>
                        <h4 className="text-sm font-semibold text-slate-900 mt-0.5">
                          {msg.confirmation.actionSummary}
                        </h4>
                        <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                          {msg.confirmation.details}
                        </p>
                      </div>
                    </div>

                    {msg.confirmationDecision ? (
                      <div className="text-xs font-medium text-slate-700 pt-1">
                        Decision:{' '}
                        <span
                          className={
                            msg.confirmationDecision === 'approved'
                              ? 'text-emerald-700 font-semibold'
                              : 'text-red-700 font-semibold'
                          }
                        >
                          {msg.confirmationDecision === 'approved'
                            ? 'Approved — continuing execution'
                            : 'Declined by user'}
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => onConfirmAction(msg.id, true)}
                          className="min-h-[40px] px-4 rounded-lg bg-[#1A56DB] text-white text-xs font-semibold hover:bg-[#1E40AF]"
                        >
                          Approve & Continue
                        </button>
                        <button
                          type="button"
                          onClick={() => onConfirmAction(msg.id, false)}
                          className="min-h-[40px] px-4 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs font-medium hover:bg-slate-50"
                        >
                          Cancel Action
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Assistant Text Output */}
                {msg.text && (
                  <div
                    className={`rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-line ${
                      msg.isError
                        ? 'border border-red-200 bg-red-50 text-red-800 flex items-start gap-2.5'
                        : 'border border-slate-200 bg-white text-slate-800'
                    }`}
                  >
                    {msg.isError && <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />}
                    <div className="min-w-0">{msg.text}</div>
                  </div>
                )}

                {/* Search Grounding Sources */}
                {msg.groundingLinks && msg.groundingLinks.length > 0 && (
                  <div className="pt-1 space-y-1">
                    <div className="text-[11px] font-medium text-slate-500">Web Sources</div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1">
                      {msg.groundingLinks.slice(0, 5).map((link, idx) => (
                        <a
                          key={`${link.uri}-${idx}`}
                          href={link.uri}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-[#1A56DB] hover:underline"
                        >
                          <span className="truncate max-w-[220px]">{link.title}</span>
                          <ExternalLink className="w-3 h-3 shrink-0" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={feedEndRef} />
      </div>

      {/* Chat & Voice Input Bar */}
      <form
        onSubmit={handleSubmit}
        className="p-3.5 border-t border-slate-200 bg-slate-50/70 shrink-0"
      >
        <div className="flex items-end gap-2">
          <textarea
            ref={inputRef}
            rows={2}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
            placeholder="Tell Compass Assistant what to do in the browser..."
            aria-label="Assistant command input"
            disabled={isRunning}
            className="flex-1 resize-none rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#1A56DB] focus:border-[#1A56DB] disabled:opacity-60"
          />
          {voiceSupported && (
            <button
              type="button"
              onClick={toggleVoice}
              disabled={isRunning}
              aria-label={isListening ? 'Stop voice dictation' : 'Start voice dictation'}
              className={`min-h-[44px] min-w-[44px] rounded-xl border flex items-center justify-center transition-colors shrink-0 ${
                isListening
                  ? 'bg-red-600 border-red-600 text-white'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          )}
          <button
            type="submit"
            disabled={isRunning || !draft.trim()}
            aria-label="Run autonomous task"
            className="min-h-[44px] px-4 rounded-xl bg-[#1A56DB] text-white text-sm font-medium flex items-center gap-1.5 hover:bg-[#1E40AF] disabled:opacity-45 shrink-0"
          >
            <Send className="w-4 h-4" />
            <span>Run</span>
          </button>
        </div>
      </form>
    </div>
  );
};
