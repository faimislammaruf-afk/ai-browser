import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BatteryCharging,
  Code2,
  Compass,
  Home,
  Layers,
  Lock,
  Mic,
  Plus,
  RotateCw,
  Signal,
  Wifi,
  X,
} from 'lucide-react';
import type { AgentOverlayTarget, BrowserTab, PageSnapshot } from '../types/browser';
import type { VisualTargetRect } from '../utils/domBridge';
import { BrowserPortals } from './portals/BrowserPortals';

interface AndroidDeviceFrameProps {
  tabs: BrowserTab[];
  activeTab: BrowserTab;
  portalContainerRef: React.RefObject<HTMLDivElement | null>;
  iframeRef: React.RefObject<HTMLIFrameElement | null>;
  overlayTarget: AgentOverlayTarget | null;
  visualRect: VisualTargetRect | null;
  isAgentRunning: boolean;
  onNavigate: (url: string, initiatedBy?: 'user' | 'agent') => void;
  onGoBack: () => void;
  onGoForward: () => void;
  onReload: () => void;
  onNewTab: (url?: string) => void;
  onSwitchTab: (tabId: string) => void;
  onCloseTab: (tabId: string) => void;
  onOpenAssistantSheet?: () => void;
  liveSnapshot?: PageSnapshot;
}

export const AndroidDeviceFrame: React.FC<AndroidDeviceFrameProps> = ({
  tabs,
  activeTab,
  portalContainerRef,
  iframeRef,
  overlayTarget,
  visualRect,
  isAgentRunning,
  onNavigate,
  onGoBack,
  onGoForward,
  onReload,
  onNewTab,
  onSwitchTab,
  onCloseTab,
  onOpenAssistantSheet,
  liveSnapshot,
}) => {
  const [urlInput, setUrlInput] = useState(activeTab.url);
  const [showTabSwitcher, setShowTabSwitcher] = useState(false);
  const [showDomInspector, setShowDomInspector] = useState(false);

  useEffect(() => {
    setUrlInput(activeTab.url);
  }, [activeTab.url, activeTab.id]);

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = urlInput.trim();
    if (!trimmed) return;
    if (
      trimmed.startsWith('http://') ||
      trimmed.startsWith('https://') ||
      trimmed.startsWith('compass://')
    ) {
      onNavigate(trimmed, 'user');
    } else if (trimmed.includes('.') && !trimmed.includes(' ')) {
      onNavigate(`https://${trimmed}`, 'user');
    } else {
      onNavigate(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(trimmed)}&kl=us-en`, 'user');
    }
    setShowTabSwitcher(false);
  };

  const canGoBack = activeTab.historyIndex > 0;
  const canGoForward = activeTab.historyIndex < activeTab.history.length - 1;
  const isInternalPortal = activeTab.url.startsWith('compass://');
  const snapshot = liveSnapshot || activeTab.snapshot;

  return (
    <div className="w-full max-w-[410px] mx-auto flex flex-col bg-slate-900 rounded-[36px] p-2.5 shadow-xl border border-slate-800 select-none">
      {/* Inner Android Screen */}
      <div className="bg-white rounded-[28px] overflow-hidden flex flex-col h-[700px] lg:h-[740px] relative border border-slate-200">
        {/* Android 15 System Status Bar */}
        <div className="h-8 px-5 bg-slate-50 border-b border-slate-200/80 flex items-center justify-between text-[11px] font-medium text-slate-800 shrink-0">
          <span className="font-mono tabular-nums">9:47</span>
          <div className="w-20 h-4 rounded-full bg-slate-900 mx-auto" aria-hidden="true" />
          <div className="flex items-center gap-1.5 text-slate-700">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <BatteryCharging className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Android Browser Omnibox */}
        <div className="px-2.5 py-2 bg-white border-b border-slate-200 flex items-center gap-1.5 shrink-0">
          <form onSubmit={handleAddressSubmit} className="flex-1 flex items-center min-w-0">
            <div className="flex items-center gap-1.5 w-full bg-slate-100 hover:bg-slate-200/70 focus-within:bg-white focus-within:ring-2 focus-within:ring-[#1A56DB] rounded-full px-3 min-h-[38px] border border-transparent focus-within:border-[#1A56DB] transition-colors">
              {isInternalPortal ? (
                <Compass className="w-3.5 h-3.5 text-[#1A56DB] shrink-0" />
              ) : (
                <Lock className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              )}
              <input
                type="text"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                onFocus={(e) => e.target.select()}
                aria-label="Browser address bar"
                className="w-full bg-transparent text-xs font-mono text-slate-800 focus:outline-none truncate"
              />
            </div>
          </form>

          <button
            type="button"
            onClick={onReload}
            aria-label="Reload page"
            className="min-h-[38px] min-w-[38px] rounded-full flex items-center justify-center text-slate-700 hover:bg-slate-100 shrink-0"
          >
            <RotateCw className={`w-4 h-4 ${activeTab.isLoading ? 'animate-spin text-[#1A56DB]' : ''}`} />
          </button>

          <button
            type="button"
            onClick={() => {
              setShowDomInspector((v) => !v);
              setShowTabSwitcher(false);
            }}
            aria-label="Toggle DOM accessibility tree"
            title="Inspect DOM elements indexed by Compass"
            className={`min-h-[38px] min-w-[38px] rounded-full flex items-center justify-center shrink-0 ${
              showDomInspector ? 'bg-[#1A56DB] text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Code2 className="w-4 h-4" />
          </button>
        </div>

        {/* Loading Progress Bar */}
        {activeTab.isLoading && (
          <div className="h-0.5 w-full bg-slate-100 overflow-hidden shrink-0">
            <div className="h-full w-1/2 bg-[#1A56DB] animate-pulse" />
          </div>
        )}

        {/* Active Agent Action Banner */}
        {isAgentRunning && overlayTarget && (
          <div className="px-3 py-1.5 bg-[#1A56DB] text-white text-[11px] font-medium flex items-center justify-between gap-2 shrink-0">
            <span className="truncate">
              Compass · {overlayTarget.actionType.toUpperCase()} · {overlayTarget.label}
            </span>
          </div>
        )}

        {/* Main Mobile Viewport */}
        <div className="flex-1 relative overflow-hidden bg-white select-text">
          {showTabSwitcher ? (
            <div className="absolute inset-0 bg-slate-100 z-20 p-3.5 overflow-y-auto compass-scroll space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-semibold text-slate-900">
                  Open Tabs ({tabs.length})
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    onNewTab('compass://home');
                    setShowTabSwitcher(false);
                  }}
                  className="min-h-[36px] px-3 rounded-lg bg-[#1A56DB] text-white text-xs font-medium flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Tab</span>
                </button>
              </div>
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const isActive = tab.id === activeTab.id;
                  return (
                    <div
                      key={tab.id}
                      className={`rounded-xl border p-3 bg-white flex items-center justify-between gap-2 ${
                        isActive ? 'border-[#1A56DB] ring-1 ring-[#1A56DB]' : 'border-slate-200'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSwitchTab(tab.id);
                          setShowTabSwitcher(false);
                        }}
                        className="flex-1 text-left min-w-0"
                      >
                        <div className="text-xs font-semibold text-slate-900 truncate">
                          {tab.title || 'New Tab'}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 truncate mt-0.5">
                          {tab.url}
                        </div>
                      </button>
                      {tabs.length > 1 && (
                        <button
                          type="button"
                          onClick={() => onCloseTab(tab.id)}
                          aria-label={`Close ${tab.title}`}
                          className="min-h-[34px] min-w-[34px] rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 hover:text-slate-900"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ) : showDomInspector ? (
            <div className="absolute inset-0 bg-slate-950 text-slate-100 z-20 p-3.5 overflow-y-auto compass-scroll space-y-2.5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h3 className="font-display text-xs font-semibold text-white">
                    Accessibility DOM Snapshot
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono tabular-nums">
                    {snapshot?.elements.length ?? 0} interactive elements indexed
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowDomInspector(false)}
                  className="min-h-[32px] px-2.5 rounded-md bg-slate-800 text-xs text-slate-200"
                >
                  Close
                </button>
              </div>
              <div className="space-y-1.5">
                {(snapshot?.elements ?? []).map((el) => (
                  <div
                    key={el.refId}
                    className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono"
                  >
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-[#60A5FA] font-semibold">
                        [{el.refId}] &lt;{el.tag}&gt;
                      </span>
                      <span className="text-slate-500">{el.role}</span>
                    </div>
                    <div className="text-slate-200 mt-0.5 break-words">{el.label}</div>
                    {el.value && (
                      <div className="text-emerald-400 mt-0.5 truncate">value=&quot;{el.value}&quot;</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : null}

          {/* Portal or Live External WebView */}
          {isInternalPortal ? (
            <div
              ref={portalContainerRef}
              className="h-full w-full overflow-y-auto compass-scroll relative"
            >
              <BrowserPortals
                url={activeTab.url}
                onNavigate={(nextUrl) => onNavigate(nextUrl, 'user')}
              />
            </div>
          ) : activeTab.snapshot?.error ? (
            <div className="h-full flex flex-col items-center justify-center p-6 text-center space-y-3 bg-slate-50">
              <AlertTriangle className="w-8 h-8 text-amber-600" />
              <div>
                <h3 className="font-display text-sm font-semibold text-slate-900">
                  Unable to Load Page
                </h3>
                <p className="text-xs text-slate-600 mt-1">{activeTab.snapshot.error}</p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={onReload}
                  className="min-h-[40px] px-4 rounded-lg bg-[#1A56DB] text-white text-xs font-medium"
                >
                  Retry
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('compass://home', 'user')}
                  className="min-h-[40px] px-4 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs font-medium"
                >
                  Home
                </button>
              </div>
            </div>
          ) : activeTab.snapshot?.renderedHtml ? (
            <iframe
              ref={iframeRef}
              title={activeTab.title || 'Android WebView'}
              srcDoc={activeTab.snapshot.renderedHtml}
              sandbox="allow-scripts allow-forms"
              className="w-full h-full border-0 bg-white"
            />
          ) : (
            <div className="h-full flex items-center justify-center p-6 text-xs text-slate-500">
              Loading page...
            </div>
          )}

          {/* Visual AI Tap / Type Highlight Overlay */}
          {visualRect && overlayTarget && !showTabSwitcher && !showDomInspector && (
            <div
              className="pointer-events-none absolute z-30 border-2 border-[#1A56DB] bg-[#1A56DB]/10 rounded-lg transition-all duration-200"
              style={{
                top: Math.max(4, visualRect.top - 2),
                left: Math.max(4, visualRect.left - 2),
                width: Math.max(24, visualRect.width + 4),
                height: Math.max(24, visualRect.height + 4),
              }}
            >
              <div
                className="absolute w-5 h-5 rounded-full bg-[#1A56DB]/50 animate-tap-ripple"
                style={{ top: '50%', left: '50%' }}
              />
            </div>
          )}
        </div>

        {/* Android Bottom Browser Thumb Navigation */}
        <div className="h-14 px-2 bg-slate-50 border-t border-slate-200 grid grid-cols-5 items-center shrink-0">
          <button
            type="button"
            disabled={!canGoBack}
            onClick={onGoBack}
            aria-label="Back"
            className="min-h-[44px] flex items-center justify-center text-slate-700 disabled:opacity-30 hover:bg-slate-200/60 rounded-xl"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            disabled={!canGoForward}
            onClick={onGoForward}
            aria-label="Forward"
            className="min-h-[44px] flex items-center justify-center text-slate-700 disabled:opacity-30 hover:bg-slate-200/60 rounded-xl"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              onNavigate('compass://home', 'user');
              setShowTabSwitcher(false);
            }}
            aria-label="Browser Home"
            className="min-h-[44px] flex items-center justify-center text-slate-700 hover:bg-slate-200/60 rounded-xl"
          >
            <Home className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              setShowTabSwitcher((v) => !v);
              setShowDomInspector(false);
            }}
            aria-label="Switch Tabs"
            className="min-h-[44px] flex items-center justify-center gap-1 text-slate-700 hover:bg-slate-200/60 rounded-xl"
          >
            <Layers className="w-4 h-4" />
            <span className="text-[11px] font-mono font-semibold tabular-nums">
              {tabs.length}
            </span>
          </button>
          <button
            type="button"
            onClick={() => {
              if (onOpenAssistantSheet) onOpenAssistantSheet();
            }}
            aria-label="Open Compass Assistant"
            className="min-h-[44px] flex items-center justify-center text-[#1A56DB] hover:bg-[#1A56DB]/10 rounded-xl"
          >
            <Mic className="w-4 h-4" />
          </button>
        </div>

        {/* Android Gesture Pill Bar */}
        <div className="h-4 bg-slate-50 flex items-center justify-center shrink-0">
          <div className="w-24 h-1 rounded-full bg-slate-300" aria-hidden="true" />
        </div>
      </div>
    </div>
  );
};
