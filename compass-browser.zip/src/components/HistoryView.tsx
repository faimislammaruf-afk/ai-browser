import React, { useState } from 'react';
import { ExternalLink, Search, Trash2 } from 'lucide-react';
import type { HistoryEntry } from '../types/browser';

interface HistoryViewProps {
  entries: HistoryEntry[];
  onOpenUrl: (url: string) => void;
  onClearHistory: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  entries,
  onOpenUrl,
  onClearHistory,
}) => {
  const [query, setQuery] = useState('');
  const [sourceFilter, setSourceFilter] = useState<'all' | 'agent' | 'user'>('all');

  const filtered = entries.filter((entry) => {
    const matchSource = sourceFilter === 'all' || entry.initiatedBy === sourceFilter;
    const matchQuery =
      !query.trim() ||
      entry.title.toLowerCase().includes(query.toLowerCase()) ||
      entry.url.toLowerCase().includes(query.toLowerCase());
    return matchSource && matchQuery;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="font-display text-2xl font-semibold text-slate-900">
            Browsing & Agent History
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Audit every page visited manually or autonomously by Compass across your Android tabs.
          </p>
        </div>
        {entries.length > 0 && (
          <button
            type="button"
            onClick={onClearHistory}
            className="min-h-[40px] px-4 rounded-xl border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter by page title or URL..."
            aria-label="Filter browsing history"
            className="w-full min-h-[42px] pl-10 pr-4 rounded-xl border border-slate-300 bg-white text-sm"
          />
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg self-start">
          {[
            { id: 'all', label: 'All Visits' },
            { id: 'agent', label: 'AI Agent' },
            { id: 'user', label: 'Manual' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSourceFilter(tab.id as 'all' | 'agent' | 'user')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                sourceFilter === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="border border-slate-200 bg-white rounded-2xl p-10 text-center">
          <p className="text-sm text-slate-600">
            No matching browser visits recorded yet.
          </p>
        </div>
      ) : (
        <div className="border border-slate-200 bg-white rounded-2xl divide-y divide-slate-200 overflow-hidden">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-slate-50/80"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium text-slate-900 truncate">
                  {item.title || item.url}
                </div>
                <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                  <span className="font-mono truncate max-w-md">{item.url}</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.initiatedBy === 'agent' ? 'Compass Agent' : 'Manual'}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {new Date(item.visitedAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onOpenUrl(item.url)}
                className="min-h-[38px] px-3.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-800 hover:bg-slate-100 flex items-center gap-1.5 shrink-0"
              >
                <span>Open</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
