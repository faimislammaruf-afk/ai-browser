import React, { useState } from 'react';
import { Check, Copy, Download } from 'lucide-react';
import { ANDROID_PROJECT_FILES } from '../data/androidSourceTemplates';

export const AndroidCodeView: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const activeFile = ANDROID_PROJECT_FILES[selectedIndex];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback not required
    }
  };

  const handleDownload = () => {
    const filename = activeFile.path.split('/').pop() || 'SourceFile.kt';
    const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="border-b border-slate-200 pb-5">
        <h1 className="font-display text-2xl font-semibold text-slate-900">
          Native Android Studio Source (Kotlin &amp; Jetpack Compose)
        </h1>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          Export the native Android WebView and Compass Accessibility Bridge architecture used by this simulator to build a standalone Android APK in Android Studio.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        <div className="lg:col-span-4 border border-slate-200 bg-white rounded-2xl divide-y divide-slate-200 overflow-hidden self-start">
          {ANDROID_PROJECT_FILES.map((file, idx) => {
            const fileName = file.path.split('/').pop();
            const isSelected = idx === selectedIndex;
            return (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedIndex(idx)}
                className={`w-full text-left p-4 transition-colors ${
                  isSelected ? 'bg-slate-900 text-white' : 'hover:bg-slate-50 text-slate-900'
                }`}
              >
                <div className="text-sm font-mono font-semibold truncate">{fileName}</div>
                <div
                  className={`text-xs mt-1 leading-relaxed ${
                    isSelected ? 'text-slate-300' : 'text-slate-500'
                  }`}
                >
                  {file.summary}
                </div>
              </button>
            );
          })}
        </div>

        <div className="lg:col-span-8 border border-slate-200 bg-slate-950 text-slate-100 rounded-2xl overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-900">
            <span className="text-xs font-mono text-slate-300 truncate">{activeFile.path}</span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleCopy}
                className="min-h-[34px] px-3 rounded-lg border border-slate-700 bg-slate-800 text-xs font-medium text-slate-100 hover:bg-slate-700 flex items-center gap-1.5"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
              <button
                type="button"
                onClick={handleDownload}
                className="min-h-[34px] px-3 rounded-lg bg-[#1A56DB] text-xs font-medium text-white hover:bg-[#1E40AF] flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>
            </div>
          </div>
          <pre className="p-4 text-xs font-mono leading-relaxed overflow-x-auto compass-scroll text-slate-200 max-h-[620px]">
            <code>{activeFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
