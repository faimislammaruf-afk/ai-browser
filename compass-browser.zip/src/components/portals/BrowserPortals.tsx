import React, { useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  CreditCard,
  Globe,
  Headphones,
  Inbox,
  Mail,
  Plane,
  Plus,
  Search,
  Send,
  ShoppingBag,
  ShoppingCart,
  Star,
  Trash2,
} from 'lucide-react';
import {
  ANDROID_WALLPAPER_URL,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_BILLS,
  INITIAL_FLIGHTS,
  INITIAL_MAILS,
  INITIAL_SHOP_PRODUCTS,
  INITIAL_TRANSACTIONS,
  TOKYO_BANNER_URL,
  type BankAccount,
  type BankTransaction,
  type FlightOption,
  type MailMessage,
  type ShopProduct,
  type UtilityBill,
} from '../../data/portalsData';

interface BrowserPortalsProps {
  url: string;
  onNavigate: (url: string) => void;
}

export const BrowserPortals: React.FC<BrowserPortalsProps> = ({ url, onNavigate }) => {
  // Home search state
  const [homeQuery, setHomeQuery] = useState('');

  // ShopSphere state
  const [shopSearch, setShopSearch] = useState('');
  const [shopCategory, setShopCategory] = useState<string>('All');
  const [shopMaxPrice, setShopMaxPrice] = useState<string>('any');
  const [selectedProduct, setSelectedProduct] = useState<ShopProduct | null>(null);
  const [shopView, setShopView] = useState<'catalog' | 'cart' | 'confirmed'>('catalog');
  const [cart, setCart] = useState<{ product: ShopProduct; qty: number }[]>([]);
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<string | null>(null);
  const [promoError, setPromoError] = useState<string | null>(null);
  const [shippingName, setShippingName] = useState('Alex Mercer');
  const [shippingAddress, setShippingAddress] = useState('742 Howard St, San Francisco, CA');
  const [lastOrderTotal, setLastOrderTotal] = useState(0);

  // Flights state
  const [originQuery, setOriginQuery] = useState('San Francisco');
  const [destQuery, setDestQuery] = useState('Tokyo');
  const [nonstopOnly, setNonstopOnly] = useState(false);
  const [cabinFilter, setCabinFilter] = useState<string>('All');
  const [selectedFlight, setSelectedFlight] = useState<FlightOption | null>(null);
  const [selectedSeat, setSelectedSeat] = useState<string>('14A');
  const [passengerName, setPassengerName] = useState('Alex Mercer');
  const [passengerEmail, setPassengerEmail] = useState('alex.mercer@pulse.example');
  const [flightConfirmedCode, setFlightConfirmedCode] = useState<string | null>(null);

  // Bank state
  const [accounts, setAccounts] = useState<BankAccount[]>(INITIAL_BANK_ACCOUNTS);
  const [bills, setBills] = useState<UtilityBill[]>(INITIAL_BILLS);
  const [transactions, setTransactions] = useState<BankTransaction[]>(INITIAL_TRANSACTIONS);
  const [payingBill, setPayingBill] = useState<UtilityBill | null>(null);
  const [bankFilter, setBankFilter] = useState('');
  const [bankNotice, setBankNotice] = useState<string | null>(null);

  // Mail state
  const [mails, setMails] = useState<MailMessage[]>(INITIAL_MAILS);
  const [mailSearch, setMailSearch] = useState('');
  const [activeMailId, setActiveMailId] = useState<string | null>(null);
  const [composingMail, setComposingMail] = useState(false);
  const [composeTo, setComposeTo] = useState('');
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');
  const [mailSentBanner, setMailSentBanner] = useState<string | null>(null);

  const normalizedUrl = url.trim().toLowerCase();

  if (normalizedUrl.startsWith('compass://shop')) {
    const filteredProducts = INITIAL_SHOP_PRODUCTS.filter((p) => {
      const matchQuery =
        !shopSearch.trim() ||
        p.name.toLowerCase().includes(shopSearch.toLowerCase()) ||
        p.brand.toLowerCase().includes(shopSearch.toLowerCase()) ||
        p.description.toLowerCase().includes(shopSearch.toLowerCase());
      const matchCat = shopCategory === 'All' || p.category === shopCategory;
      const maxP = shopMaxPrice === 'any' ? Infinity : Number(shopMaxPrice);
      return matchQuery && matchCat && p.price <= maxP;
    });

    const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.qty, 0);
    const discount = appliedPromo === 'SAVE15' ? Math.round(subtotal * 0.15 * 100) / 100 : 0;
    const total = Math.max(0, subtotal - discount);
    const totalQty = cart.reduce((sum, item) => sum + item.qty, 0);

    const addToCart = (product: ShopProduct) => {
      setCart((prev) => {
        const existing = prev.find((i) => i.product.id === product.id);
        if (existing) {
          return prev.map((i) => (i.product.id === product.id ? { ...i, qty: i.qty + 1 } : i));
        }
        return [...prev, { product, qty: 1 }];
      });
    };

    return (
      <div className="min-h-full bg-white text-slate-900 pb-8">
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur border-b border-slate-200 px-3.5 py-2.5 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            {(selectedProduct || shopView !== 'catalog') && (
              <button
                type="button"
                onClick={() => {
                  if (shopView !== 'catalog') setShopView('catalog');
                  else setSelectedProduct(null);
                }}
                aria-label="Back to ShopSphere catalog"
                className="min-h-[36px] min-w-[36px] rounded-lg border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-50"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div className="flex items-center gap-1.5 truncate">
              <ShoppingBag className="w-4 h-4 text-[#1A56DB] shrink-0" />
              <span className="font-display font-semibold text-sm truncate">ShopSphere</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setSelectedProduct(null);
              setShopView('cart');
            }}
            className="min-h-[36px] px-3 rounded-lg bg-slate-900 text-white text-xs font-medium flex items-center gap-1.5 shrink-0"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>Cart ({totalQty})</span>
          </button>
        </div>

        {shopView === 'confirmed' ? (
          <div className="p-5 text-center space-y-4">
            <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
            <div>
              <h2 className="font-display text-lg font-semibold text-slate-900">Order Confirmed</h2>
              <p className="text-xs text-slate-600 mt-1">
                Order #SS-90412 for <span className="font-mono tabular-nums">${lastOrderTotal.toFixed(2)}</span> will ship to {shippingName}.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setShopView('catalog');
                setSelectedProduct(null);
              }}
              className="w-full min-h-[44px] rounded-xl bg-[#1A56DB] text-white text-sm font-medium"
            >
              Continue Shopping
            </button>
          </div>
        ) : shopView === 'cart' ? (
          <div className="p-3.5 space-y-4">
            <h2 className="font-display text-base font-semibold">Shopping Cart & Checkout</h2>
            {cart.length === 0 ? (
              <div className="border border-slate-200 rounded-xl p-5 text-center space-y-2">
                <p className="text-sm text-slate-600">Your cart is empty.</p>
                <button
                  type="button"
                  onClick={() => setShopView('catalog')}
                  className="min-h-[40px] px-4 rounded-lg bg-[#1A56DB] text-white text-xs font-medium"
                >
                  Browse Products
                </button>
              </div>
            ) : (
              <>
                <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl">
                  {cart.map((item) => (
                    <div key={item.product.id} className="p-3 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">{item.product.name}</p>
                        <p className="text-xs text-slate-500 font-mono tabular-nums">
                          ${item.product.price.toFixed(2)} × {item.qty}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          setCart((prev) => prev.filter((c) => c.product.id !== item.product.id))
                        }
                        aria-label={`Remove ${item.product.name}`}
                        className="min-h-[36px] min-w-[36px] rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:text-red-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const code = promoInput.trim().toUpperCase();
                    if (code === 'SAVE15') {
                      setAppliedPromo('SAVE15');
                      setPromoError(null);
                    } else {
                      setPromoError('Invalid promo code. Try SAVE15.');
                    }
                  }}
                  className="flex gap-2"
                >
                  <input
                    type="text"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    placeholder="Promo code (e.g. SAVE15)"
                    aria-label="Promo code"
                    className="flex-1 min-h-[42px] px-3 rounded-lg border border-slate-300 text-xs bg-slate-50"
                  />
                  <button
                    type="submit"
                    className="min-h-[42px] px-3.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-800 hover:bg-slate-100"
                  >
                    Apply
                  </button>
                </form>
                {appliedPromo && (
                  <p className="text-xs text-emerald-700 font-medium">
                    Promo SAVE15 applied (-${discount.toFixed(2)})
                  </p>
                )}
                {promoError && <p className="text-xs text-red-600">{promoError}</p>}

                <div className="space-y-2 border-t border-slate-200 pt-3">
                  <label className="block text-xs font-medium text-slate-700">
                    Recipient Name
                    <input
                      type="text"
                      value={shippingName}
                      onChange={(e) => setShippingName(e.target.value)}
                      className="mt-1 w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs bg-white"
                    />
                  </label>
                  <label className="block text-xs font-medium text-slate-700">
                    Shipping Address
                    <input
                      type="text"
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      className="mt-1 w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs bg-white"
                    />
                  </label>
                </div>

                <div className="border-t border-slate-200 pt-3 space-y-1 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal</span>
                    <span className="font-mono tabular-nums">${subtotal.toFixed(2)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-emerald-700">
                      <span>Discount (SAVE15)</span>
                      <span className="font-mono tabular-nums">-${discount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm font-semibold text-slate-900 pt-1">
                    <span>Order Total</span>
                    <span className="font-mono tabular-nums">${total.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setLastOrderTotal(total);
                    setCart([]);
                    setAppliedPromo(null);
                    setPromoInput('');
                    setShopView('confirmed');
                  }}
                  className="w-full min-h-[44px] rounded-xl bg-[#1A56DB] text-white text-sm font-semibold hover:bg-[#1E40AF]"
                >
                  Place Order (${total.toFixed(2)})
                </button>
              </>
            )}
          </div>
        ) : selectedProduct ? (
          <div className="p-3.5 space-y-3.5">
            <div className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center">
              {selectedProduct.image ? (
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <Headphones className="w-10 h-10 text-slate-400" />
              )}
            </div>
            <div>
              <div className="text-xs text-slate-500">
                {selectedProduct.brand} · {selectedProduct.category} · {selectedProduct.rating} ★ ({selectedProduct.reviewCount} reviews)
              </div>
              <h2 className="font-display text-base font-semibold text-slate-900 mt-0.5">
                {selectedProduct.name}
              </h2>
              <p className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-1">
                ${selectedProduct.price.toFixed(2)}
              </p>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">{selectedProduct.description}</p>
            <div className="border-t border-slate-200 pt-2.5">
              <div className="text-xs font-semibold text-slate-800 mb-1.5">Key Specifications</div>
              <ul className="space-y-1 text-xs text-slate-600 list-disc pl-4">
                {selectedProduct.specs.map((spec) => (
                  <li key={spec}>{spec}</li>
                ))}
              </ul>
            </div>
            <button
              type="button"
              onClick={() => {
                addToCart(selectedProduct);
                setShopView('cart');
              }}
              className="w-full min-h-[44px] rounded-xl bg-[#1A56DB] text-white text-sm font-semibold hover:bg-[#1E40AF]"
            >
              Add to Cart & Checkout
            </button>
          </div>
        ) : (
          <div className="p-3.5 space-y-3">
            <form
              onSubmit={(e) => e.preventDefault()}
              className="flex gap-2"
            >
              <input
                type="search"
                value={shopSearch}
                onChange={(e) => setShopSearch(e.target.value)}
                placeholder="Search headphones, keyboards..."
                aria-label="Search ShopSphere catalog"
                className="flex-1 min-h-[40px] px-3 rounded-lg border border-slate-300 bg-slate-50 text-xs"
              />
            </form>

            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1 overflow-x-auto">
                {['All', 'Audio', 'Keyboards', 'Accessories'].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setShopCategory(cat)}
                    className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 ${
                      shopCategory === cat
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <select
                aria-label="Maximum price filter"
                value={shopMaxPrice}
                onChange={(e) => setShopMaxPrice(e.target.value)}
                className="min-h-[34px] px-2 rounded-lg border border-slate-300 text-xs bg-white shrink-0"
              >
                <option value="any">Any price</option>
                <option value="250">Under $250</option>
                <option value="200">Under $200</option>
                <option value="100">Under $100</option>
              </select>
            </div>

            <div className="space-y-2.5">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="border border-slate-200 rounded-xl p-2.5 flex gap-3 items-center bg-white"
                >
                  <div className="w-20 h-16 rounded-lg overflow-hidden bg-slate-100 shrink-0 flex items-center justify-center">
                    {product.image ? (
                      <img
                        src={product.image}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <ShoppingBag className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] text-slate-500">
                      {product.brand} · {product.rating} ★ ({product.reviewCount})
                    </div>
                    <h3 className="text-xs font-semibold text-slate-900 truncate">{product.name}</h3>
                    <div className="flex items-center justify-between mt-1.5 gap-2">
                      <span className="text-sm font-bold text-slate-900 font-mono tabular-nums">
                        ${product.price}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setSelectedProduct(product)}
                          className="min-h-[32px] px-2.5 rounded-lg border border-slate-300 text-[11px] font-medium text-slate-800 hover:bg-slate-50"
                        >
                          View
                        </button>
                        <button
                          type="button"
                          onClick={() => addToCart(product)}
                          className="min-h-[32px] px-2.5 rounded-lg bg-[#1A56DB] text-white text-[11px] font-medium hover:bg-[#1E40AF]"
                        >
                          Add
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  if (normalizedUrl.startsWith('compass://flights')) {
    const filteredFlights = INITIAL_FLIGHTS.filter((f) => {
      const matchOrigin =
        !originQuery.trim() || f.origin.toLowerCase().includes(originQuery.toLowerCase());
      const matchDest =
        !destQuery.trim() || f.destination.toLowerCase().includes(destQuery.toLowerCase());
      const matchNonstop = !nonstopOnly || f.nonstop;
      const matchCabin = cabinFilter === 'All' || f.cabin === cabinFilter;
      return matchOrigin && matchDest && matchNonstop && matchCabin;
    });

    return (
      <div className="min-h-full bg-white text-slate-900 pb-8">
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur border-b border-slate-200 px-3.5 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {(selectedFlight || flightConfirmedCode) && (
              <button
                type="button"
                onClick={() => {
                  setFlightConfirmedCode(null);
                  setSelectedFlight(null);
                }}
                aria-label="Back to flight search"
                className="min-h-[36px] min-w-[36px] rounded-lg border border-slate-200 flex items-center justify-center"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <Plane className="w-4 h-4 text-[#1A56DB]" />
            <span className="font-display font-semibold text-sm">Horizon Flights</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Dec 12 · 1 Adult</span>
        </div>

        {flightConfirmedCode && selectedFlight ? (
          <div className="p-5 text-center space-y-4">
            <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
            <div>
              <h2 className="font-display text-lg font-semibold">Reservation Confirmed</h2>
              <p className="text-xs text-slate-600 mt-1">
                Confirmation <span className="font-mono font-semibold">{flightConfirmedCode}</span> · {selectedFlight.airline} {selectedFlight.flightNumber}
              </p>
              <p className="text-xs text-slate-600 mt-0.5">
                Passenger: {passengerName} · Seat {selectedSeat} · <span className="font-mono">${selectedFlight.price}</span>
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setFlightConfirmedCode(null);
                setSelectedFlight(null);
              }}
              className="w-full min-h-[44px] rounded-xl bg-[#1A56DB] text-white text-sm font-medium"
            >
              Search More Flights
            </button>
          </div>
        ) : selectedFlight ? (
          <div className="p-3.5 space-y-3.5">
            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50">
              <div className="text-xs text-slate-500">
                {selectedFlight.airline} · {selectedFlight.flightNumber} · {selectedFlight.cabin}
              </div>
              <div className="text-sm font-semibold text-slate-900 mt-0.5">
                {selectedFlight.origin} → {selectedFlight.destination}
              </div>
              <div className="text-xs text-slate-600 mt-0.5 font-mono tabular-nums">
                {selectedFlight.departTime} – {selectedFlight.arriveTime} ({selectedFlight.duration}) · ${selectedFlight.price}
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-slate-800 mb-1.5">Select Seat</div>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  '14A Window',
                  '14B Middle',
                  '14C Aisle',
                  '15A Window',
                  '15B Middle',
                  '15C Aisle',
                ].map((seatLabel) => {
                  const seatCode = seatLabel.split(' ')[0];
                  const active = selectedSeat === seatCode;
                  return (
                    <button
                      key={seatCode}
                      type="button"
                      onClick={() => setSelectedSeat(seatCode)}
                      className={`min-h-[40px] px-2 rounded-lg text-xs font-medium border ${
                        active
                          ? 'bg-[#1A56DB] text-white border-[#1A56DB]'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {seatLabel}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-medium text-slate-700">
                Passenger Full Name
                <input
                  type="text"
                  value={passengerName}
                  onChange={(e) => setPassengerName(e.target.value)}
                  className="mt-1 w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
                />
              </label>
              <label className="block text-xs font-medium text-slate-700">
                Confirmation Email
                <input
                  type="email"
                  value={passengerEmail}
                  onChange={(e) => setPassengerEmail(e.target.value)}
                  className="mt-1 w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
                />
              </label>
            </div>

            <button
              type="button"
              onClick={() => setFlightConfirmedCode('HZN-84K9')}
              className="w-full min-h-[44px] rounded-xl bg-[#1A56DB] text-white text-sm font-semibold hover:bg-[#1E40AF]"
            >
              Confirm Flight Booking (${selectedFlight.price})
            </button>
          </div>
        ) : (
          <div className="space-y-3 pb-4">
            <div className="relative h-28 overflow-hidden bg-slate-900">
              <img
                src={TOKYO_BANNER_URL}
                alt="Tokyo skyline at twilight"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent flex items-end p-3">
                <p className="text-white text-sm font-display font-semibold">
                  Explore Trans-Pacific Fares
                </p>
              </div>
            </div>

            <div className="px-3.5 space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={originQuery}
                  onChange={(e) => setOriginQuery(e.target.value)}
                  placeholder="From city"
                  aria-label="Origin city"
                  className="min-h-[40px] px-2.5 rounded-lg border border-slate-300 text-xs bg-slate-50"
                />
                <input
                  type="text"
                  value={destQuery}
                  onChange={(e) => setDestQuery(e.target.value)}
                  placeholder="To city"
                  aria-label="Destination city"
                  className="min-h-[40px] px-2.5 rounded-lg border border-slate-300 text-xs bg-slate-50"
                />
              </div>

              <div className="flex items-center justify-between gap-2">
                <label className="flex items-center gap-2 text-xs text-slate-700 min-h-[36px] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={nonstopOnly}
                    onChange={(e) => setNonstopOnly(e.target.checked)}
                    className="rounded border-slate-300"
                  />
                  <span>Nonstop only</span>
                </label>

                <select
                  aria-label="Cabin class"
                  value={cabinFilter}
                  onChange={(e) => setCabinFilter(e.target.value)}
                  className="min-h-[36px] px-2.5 rounded-lg border border-slate-300 text-xs bg-white"
                >
                  <option value="All">All cabins</option>
                  <option value="Economy">Economy</option>
                  <option value="Premium Economy">Premium Economy</option>
                </select>
              </div>

              <div className="space-y-2">
                {filteredFlights.map((flight) => (
                  <div
                    key={flight.id}
                    className="border border-slate-200 rounded-xl p-3 space-y-2 bg-white"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-900">
                        {flight.airline} · {flight.flightNumber}
                      </span>
                      <span className="text-sm font-bold text-[#1A56DB] font-mono tabular-nums">
                        ${flight.price}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600">
                      {flight.origin} → {flight.destination}
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span className="font-mono tabular-nums">
                        {flight.departTime} – {flight.arriveTime} · {flight.duration}
                      </span>
                      <span>{flight.nonstop ? 'Nonstop' : '1 Stop'}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedFlight(flight)}
                      className="w-full min-h-[38px] rounded-lg bg-slate-900 text-white text-xs font-medium hover:bg-slate-800"
                    >
                      Select Flight ({flight.cabin})
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (normalizedUrl.startsWith('compass://bank')) {
    const filteredTx = transactions.filter(
      (t) =>
        !bankFilter.trim() ||
        t.merchant.toLowerCase().includes(bankFilter.toLowerCase()) ||
        t.category.toLowerCase().includes(bankFilter.toLowerCase())
    );

    const handlePayBill = (bill: UtilityBill) => {
      setAccounts((prev) =>
        prev.map((acc) =>
          acc.id === 'acc-chk'
            ? { ...acc, balance: Math.round((acc.balance - bill.amount) * 100) / 100 }
            : acc
        )
      );
      setBills((prev) =>
        prev.map((b) => (b.id === bill.id ? { ...b, status: 'Paid' } : b))
      );
      setTransactions((prev) => [
        {
          id: `tx-${Date.now()}`,
          date: 'Today',
          merchant: `${bill.biller} (${bill.accountRef})`,
          category: 'Utilities',
          amount: -bill.amount,
        },
        ...prev,
      ]);
      setBankNotice(`Paid $${bill.amount.toFixed(2)} to ${bill.biller} (${bill.accountRef}).`);
      setPayingBill(null);
    };

    return (
      <div className="min-h-full bg-white text-slate-900 pb-8">
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur border-b border-slate-200 px-3.5 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {payingBill && (
              <button
                type="button"
                onClick={() => setPayingBill(null)}
                aria-label="Back to accounts"
                className="min-h-[36px] min-w-[36px] rounded-lg border border-slate-200 flex items-center justify-center"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <CreditCard className="w-4 h-4 text-[#1A56DB]" />
            <span className="font-display font-semibold text-sm">Apex Personal Banking</span>
          </div>
        </div>

        {payingBill ? (
          <div className="p-4 space-y-4">
            <h2 className="font-display text-base font-semibold">Confirm Bill Payment</h2>
            <div className="border border-slate-200 rounded-xl p-3.5 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Payee</span>
                <span className="font-semibold text-slate-900">{payingBill.biller}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Account Ref</span>
                <span className="font-mono">{payingBill.accountRef}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">From Account</span>
                <span>Everyday Checking (••4821)</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-bold">
                <span>Payment Amount</span>
                <span className="font-mono tabular-nums">${payingBill.amount.toFixed(2)}</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => handlePayBill(payingBill)}
              className="w-full min-h-[44px] rounded-xl bg-[#1A56DB] text-white text-sm font-semibold hover:bg-[#1E40AF]"
            >
              Submit Payment (${payingBill.amount.toFixed(2)})
            </button>
          </div>
        ) : (
          <div className="p-3.5 space-y-4">
            {bankNotice && (
              <div className="p-2.5 rounded-lg border border-emerald-200 bg-emerald-50 text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{bankNotice}</span>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              {accounts.map((acc) => (
                <div key={acc.id} className="border border-slate-200 rounded-xl p-3 bg-slate-50">
                  <div className="text-[11px] text-slate-500">
                    {acc.name} {acc.accountMask}
                  </div>
                  <div className="text-base font-bold text-slate-900 font-mono tabular-nums mt-1">
                    ${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                </div>
              ))}
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-800 mb-2">Scheduled & Due Bills</h3>
              <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl">
                {bills.map((bill) => (
                  <div key={bill.id} className="p-3 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900 truncate">{bill.biller}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {bill.accountRef} · Due {bill.dueDate} ·{' '}
                        <span
                          className={
                            bill.status === 'Overdue'
                              ? 'text-red-600 font-semibold'
                              : bill.status === 'Paid'
                                ? 'text-emerald-700 font-semibold'
                                : 'text-amber-700'
                          }
                        >
                          {bill.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-xs font-bold font-mono tabular-nums">
                        ${bill.amount.toFixed(2)}
                      </span>
                      {bill.status !== 'Paid' && (
                        <button
                          type="button"
                          onClick={() => setPayingBill(bill)}
                          className="min-h-[34px] px-2.5 rounded-lg bg-[#1A56DB] text-white text-[11px] font-medium hover:bg-[#1E40AF]"
                        >
                          Pay Bill
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2 gap-2">
                <h3 className="text-xs font-semibold text-slate-800">Recent Transactions</h3>
                <input
                  type="search"
                  value={bankFilter}
                  onChange={(e) => setBankFilter(e.target.value)}
                  placeholder="Filter..."
                  aria-label="Filter transactions"
                  className="w-32 min-h-[32px] px-2 rounded-lg border border-slate-300 text-xs bg-slate-50"
                />
              </div>
              <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl">
                {filteredTx.map((tx) => (
                  <div key={tx.id} className="px-3 py-2 flex items-center justify-between text-xs">
                    <div className="min-w-0">
                      <div className="font-medium text-slate-900 truncate">{tx.merchant}</div>
                      <div className="text-[11px] text-slate-500">
                        {tx.date} · {tx.category}
                      </div>
                    </div>
                    <span
                      className={`font-mono tabular-nums font-medium ${
                        tx.amount > 0 ? 'text-emerald-700' : 'text-slate-900'
                      }`}
                    >
                      {tx.amount > 0 ? '+' : '-'}${Math.abs(tx.amount).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (normalizedUrl.startsWith('compass://mail')) {
    const activeMail = mails.find((m) => m.id === activeMailId) || null;
    const filteredMails = mails.filter(
      (m) =>
        !mailSearch.trim() ||
        m.subject.toLowerCase().includes(mailSearch.toLowerCase()) ||
        m.from.toLowerCase().includes(mailSearch.toLowerCase()) ||
        m.body.toLowerCase().includes(mailSearch.toLowerCase())
    );

    const openMail = (mail: MailMessage) => {
      setActiveMailId(mail.id);
      setMails((prev) => prev.map((m) => (m.id === mail.id ? { ...m, unread: false } : m)));
    };

    const handleSendMail = (e: React.FormEvent) => {
      e.preventDefault();
      if (!composeTo.trim() || !composeSubject.trim()) return;
      const newMail: MailMessage = {
        id: `mail-${Date.now()}`,
        from: 'You',
        fromEmail: 'alex.mercer@pulse.example',
        subject: composeSubject,
        receivedAt: 'Just now',
        unread: false,
        folder: 'Sent',
        preview: composeBody.slice(0, 70),
        body: composeBody,
      };
      setMails((prev) => [newMail, ...prev]);
      setComposingMail(false);
      setComposeTo('');
      setComposeSubject('');
      setComposeBody('');
      setMailSentBanner(`Email sent to ${composeTo}.`);
    };

    return (
      <div className="min-h-full bg-white text-slate-900 pb-8">
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur border-b border-slate-200 px-3.5 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {(activeMail || composingMail) && (
              <button
                type="button"
                onClick={() => {
                  setActiveMailId(null);
                  setComposingMail(false);
                }}
                aria-label="Back to inbox"
                className="min-h-[36px] min-w-[36px] rounded-lg border border-slate-200 flex items-center justify-center"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <Mail className="w-4 h-4 text-[#1A56DB]" />
            <span className="font-display font-semibold text-sm">Pulse Webmail</span>
          </div>
          {!composingMail && (
            <button
              type="button"
              onClick={() => {
                setActiveMailId(null);
                setComposingMail(true);
              }}
              className="min-h-[36px] px-3 rounded-lg bg-[#1A56DB] text-white text-xs font-medium flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Compose</span>
            </button>
          )}
        </div>

        {composingMail ? (
          <form onSubmit={handleSendMail} className="p-3.5 space-y-2.5">
            <h2 className="font-display text-sm font-semibold">New Message</h2>
            <input
              type="email"
              required
              value={composeTo}
              onChange={(e) => setComposeTo(e.target.value)}
              placeholder="To (e.g. maya.lin@studio.example)"
              aria-label="Recipient email"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
            />
            <input
              type="text"
              required
              value={composeSubject}
              onChange={(e) => setComposeSubject(e.target.value)}
              placeholder="Subject"
              aria-label="Email subject"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
            />
            <textarea
              rows={5}
              value={composeBody}
              onChange={(e) => setComposeBody(e.target.value)}
              placeholder="Write your message..."
              aria-label="Email body"
              className="w-full p-3 rounded-lg border border-slate-300 text-xs"
            />
            <button
              type="submit"
              className="w-full min-h-[44px] rounded-xl bg-[#1A56DB] text-white text-sm font-semibold flex items-center justify-center gap-1.5"
            >
              <Send className="w-4 h-4" />
              <span>Send Email</span>
            </button>
          </form>
        ) : activeMail ? (
          <div className="p-3.5 space-y-3">
            <div>
              <div className="text-xs text-slate-500">
                From: {activeMail.from} ({activeMail.fromEmail}) · {activeMail.receivedAt}
              </div>
              <h2 className="font-display text-base font-semibold text-slate-900 mt-1">
                {activeMail.subject}
              </h2>
            </div>
            <div className="border-t border-slate-200 pt-3 text-xs text-slate-700 whitespace-pre-line leading-relaxed">
              {activeMail.body}
            </div>
            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setComposeTo(activeMail.fromEmail);
                  setComposeSubject(`Re: ${activeMail.subject}`);
                  setComposeBody('');
                  setComposingMail(true);
                }}
                className="flex-1 min-h-[40px] rounded-lg border border-slate-300 text-xs font-semibold text-slate-800 hover:bg-slate-50"
              >
                Reply
              </button>
              {activeMail.body.includes('Apex Personal Banking') && (
                <button
                  type="button"
                  onClick={() => onNavigate('compass://bank')}
                  className="flex-1 min-h-[40px] rounded-lg bg-[#1A56DB] text-white text-xs font-semibold"
                >
                  Open Apex Bank
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="p-3.5 space-y-3">
            {mailSentBanner && (
              <div className="p-2.5 rounded-lg border border-emerald-200 bg-emerald-50 text-xs text-emerald-800">
                {mailSentBanner}
              </div>
            )}
            <input
              type="search"
              value={mailSearch}
              onChange={(e) => setMailSearch(e.target.value)}
              placeholder="Search mail..."
              aria-label="Search Pulse Webmail"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 bg-slate-50 text-xs"
            />
            <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl">
              {filteredMails.map((mail) => (
                <button
                  key={mail.id}
                  type="button"
                  onClick={() => openMail(mail)}
                  className="w-full text-left p-3 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500">
                    <span className={mail.unread ? 'font-semibold text-slate-900' : ''}>
                      {mail.from}
                    </span>
                    <span className="font-mono">
                      {mail.unread ? 'Unread · ' : ''}
                      {mail.receivedAt}
                    </span>
                  </div>
                  <div
                    className={`text-xs mt-0.5 truncate ${
                      mail.unread ? 'font-semibold text-slate-900' : 'font-medium text-slate-700'
                    }`}
                  >
                    {mail.subject}
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">{mail.preview}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Default: compass://home
  return (
    <div className="min-h-full bg-white text-slate-900 pb-8">
      <div className="relative h-36 overflow-hidden bg-slate-900">
        <img
          src={ANDROID_WALLPAPER_URL}
          alt="Compass Android Browser backdrop"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent flex flex-col justify-end p-4">
          <p className="text-xs text-white/80">Android Personal Browser</p>
          <h2 className="font-display text-lg font-semibold text-white">
            Where should we navigate today?
          </h2>
        </div>
      </div>

      <div className="p-3.5 space-y-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const q = homeQuery.trim();
            if (!q) return;
            if (q.startsWith('http://') || q.startsWith('https://') || q.startsWith('compass://')) {
              onNavigate(q);
            } else if (q.includes('.') && !q.includes(' ')) {
              onNavigate(`https://${q}`);
            } else {
              onNavigate(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}&kl=us-en`);
            }
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={homeQuery}
            onChange={(e) => setHomeQuery(e.target.value)}
            placeholder="Search web or enter URL..."
            aria-label="Search web or enter URL"
            className="flex-1 min-h-[44px] px-3.5 rounded-xl border border-slate-300 bg-slate-50 text-xs"
          />
          <button
            type="submit"
            aria-label="Go"
            className="min-h-[44px] min-w-[44px] px-3.5 rounded-xl bg-[#1A56DB] text-white text-xs font-semibold flex items-center justify-center"
          >
            <Search className="w-4 h-4" />
          </button>
        </form>

        <div>
          <h3 className="text-xs font-semibold text-slate-600 mb-2">Interactive Portals</h3>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onNavigate('compass://shop')}
              className="min-h-[56px] p-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-left flex items-center gap-2.5"
            >
              <ShoppingBag className="w-5 h-5 text-[#1A56DB] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-900 truncate">ShopSphere</div>
                <div className="text-[11px] text-slate-500 truncate">Store & Cart</div>
              </div>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('compass://flights')}
              className="min-h-[56px] p-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-left flex items-center gap-2.5"
            >
              <Plane className="w-5 h-5 text-[#1A56DB] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-900 truncate">Horizon Flights</div>
                <div className="text-[11px] text-slate-500 truncate">Travel Booking</div>
              </div>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('compass://bank')}
              className="min-h-[56px] p-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-left flex items-center gap-2.5"
            >
              <CreditCard className="w-5 h-5 text-[#1A56DB] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-900 truncate">Apex Bank</div>
                <div className="text-[11px] text-slate-500 truncate">Bills & Balances</div>
              </div>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('compass://mail')}
              className="min-h-[56px] p-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-left flex items-center gap-2.5"
            >
              <Inbox className="w-5 h-5 text-[#1A56DB] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-900 truncate">Pulse Mail</div>
                <div className="text-[11px] text-slate-500 truncate">2 Unread</div>
              </div>
            </button>
          </div>
        </div>

        <div>
          <h3 className="text-xs font-semibold text-slate-600 mb-2">Live External Web</h3>
          <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl">
            <button
              type="button"
              onClick={() => onNavigate('https://en.wikipedia.org/wiki/Main_Page')}
              className="w-full min-h-[48px] px-3 py-2 flex items-center justify-between text-left hover:bg-slate-50"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Globe className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900 truncate">Wikipedia</div>
                  <div className="text-[11px] text-slate-500 font-mono truncate">en.wikipedia.org</div>
                </div>
              </div>
              <Star className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('https://news.ycombinator.com')}
              className="w-full min-h-[48px] px-3 py-2 flex items-center justify-between text-left hover:bg-slate-50"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Globe className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900 truncate">Hacker News</div>
                  <div className="text-[11px] text-slate-500 font-mono truncate">news.ycombinator.com</div>
                </div>
              </div>
              <Star className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('https://books.toscrape.com')}
              className="w-full min-h-[48px] px-3 py-2 flex items-center justify-between text-left hover:bg-slate-50"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Globe className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900 truncate">Books to Scrape</div>
                  <div className="text-[11px] text-slate-500 font-mono truncate">books.toscrape.com</div>
                </div>
              </div>
              <Star className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
