import React, { useState } from 'react';
import { Play, Trash2 } from 'lucide-react';
import type { AutomationRoutine } from '../types/browser';

interface AutomationsViewProps {
  routines: AutomationRoutine[];
  onRunRoutine: (routine: AutomationRoutine) => void;
  onDeleteRoutine: (id: string) => void;
}

export const AutomationsView: React.FC<AutomationsViewProps> = ({
  routines,
  onRunRoutine,
  onDeleteRoutine,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const categories = ['All', ...Array.from(new Set(routines.map((r) => r.category)))];

  const visibleRoutines = routines.filter(
    (r) => categoryFilter === 'All' || r.category === categoryFilter
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="font-display text-2xl font-semibold text-slate-900">
            Saved Browser Automations
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Launch multi-step personal workflows directly inside the Android browser with a single tap.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg self-start sm:self-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                categoryFilter === cat
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {visibleRoutines.length === 0 ? (
        <div className="border border-slate-200 bg-white rounded-2xl p-8 text-center">
          <p className="text-sm text-slate-600">No saved routines in this category yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {visibleRoutines.map((routine) => (
            <div
              key={routine.id}
              className="border border-slate-200 bg-white rounded-2xl p-5 flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                  <span>
                    {routine.category} · <span className="font-mono">{routine.startUrl}</span>
                  </span>
                  {routine.lastRunAt && (
                    <span className="font-mono tabular-nums">
                      Last run {new Date(routine.lastRunAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                </div>
                <h2 className="font-display text-base font-semibold text-slate-900">
                  {routine.title}
                </h2>
                <p className="text-sm text-slate-600 leading-relaxed">{routine.description}</p>
              </div>

              <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => onRunRoutine(routine)}
                  className="min-h-[40px] px-4 rounded-xl bg-[#1A56DB] text-white text-xs font-semibold flex items-center gap-1.5 hover:bg-[#1E40AF]"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Run in Browser</span>
                </button>
                {routine.id.startsWith('custom-') && (
                  <button
                    type="button"
                    onClick={() => onDeleteRoutine(routine.id)}
                    aria-label={`Delete ${routine.title}`}
                    className="min-h-[40px] min-w-[40px] rounded-xl border border-slate-200 flex items-center justify-center text-slate-500 hover:text-red-600 hover:border-red-200"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
