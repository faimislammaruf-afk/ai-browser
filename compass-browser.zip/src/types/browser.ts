export interface DomElementRef {
  refId: number;
  tag: string;
  role: string;
  label: string;
  type?: string;
  href?: string;
  placeholder?: string;
  value?: string;
  options?: string[];
  disabled?: boolean;
  checked?: boolean;
  selectorHint?: string;
}

export interface PageSnapshot {
  url: string;
  title: string;
  isExternal: boolean;
  fetchLatencyMs?: number;
  statusCode?: number;
  text: string;
  elements: DomElementRef[];
  renderedHtml?: string;
  error?: string;
}

export interface BrowserTab {
  id: string;
  url: string;
  title: string;
  history: string[];
  historyIndex: number;
  snapshot?: PageSnapshot;
  isLoading: boolean;
  scrollY: number;
}

export interface AgentActionLog {
  id: string;
  step: number;
  toolName: string;
  args: Record<string, unknown>;
  status: 'running' | 'completed' | 'paused' | 'error';
  resultSummary?: string;
  timestamp: number;
}

export interface ConfirmationRequest {
  id: string;
  actionSummary: string;
  details: string;
  riskLevel: 'low' | 'medium' | 'high';
  pendingCallId: string;
  pendingCallName: string;
}

export interface GroundingLink {
  title: string;
  uri: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  actions?: AgentActionLog[];
  groundingLinks?: GroundingLink[];
  confirmation?: ConfirmationRequest;
  confirmationDecision?: 'approved' | 'rejected';
  isError?: boolean;
}

export interface AutomationRoutine {
  id: string;
  title: string;
  description: string;
  prompt: string;
  startUrl: string;
  category: string;
  lastRunAt?: number;
}

export interface HistoryEntry {
  id: string;
  url: string;
  title: string;
  visitedAt: number;
  initiatedBy: 'user' | 'agent';
}

export interface AgentOverlayTarget {
  refId?: number;
  label: string;
  actionType: 'tap' | 'type' | 'scroll' | 'navigate' | 'extract';
  textPreview?: string;
  timestamp: number;
}

export type AssistantModelId = 'baidu/ernie-5.5-flash-preview:free';

export interface BookmarkEntry {
  id: string;
  url: string;
  title: string;
  createdAt: number;
}


