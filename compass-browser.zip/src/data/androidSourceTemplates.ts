export interface AndroidSourceFile {
  path: string;
  language: 'kotlin' | 'javascript' | 'xml';
  summary: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidSourceFile[] = [
  {
    path: 'app/src/main/java/com/compass/browser/MainActivity.kt',
    language: 'kotlin',
    summary: 'Jetpack Compose Android browser screen combining WebView with the Compass bottom-sheet assistant.',
    content: `package com.compass.browser

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompassBrowserScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CompassBrowserScreen(vm: BrowserViewModel = viewModel()) {
    val uiState by vm.uiState.collectAsState()
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var promptText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = uiState.currentUrl,
                        onValueChange = { vm.updateAddressBar(it) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                actions = {
                    TextButton(onClick = { webViewRef?.loadUrl(uiState.currentUrl) }) {
                        Text("Go")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(modifier = Modifier.padding(12.dp)) {
                    uiState.lastAgentStep?.let { step ->
                        Text(
                            text = step,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = promptText,
                            onValueChange = { promptText = it },
                            placeholder = { Text("Tell Compass what to automate...") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            enabled = !uiState.isAgentRunning && promptText.isNotBlank(),
                            onClick = {
                                val task = promptText
                                promptText = ""
                                webViewRef?.let { vm.runAutonomousTask(task, it) }
                            }
                        ) {
                            Text(if (uiState.isAgentRunning) "Running" else "Run")
                        }
                    }
                }
            }
        }
    ) { padding ->
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            url?.let { vm.onPageLoaded(it, view?.title.orEmpty()) }
                        }
                    }
                    loadUrl(uiState.currentUrl)
                    webViewRef = this
                }
            }
        )
    }
}`,
  },
  {
    path: 'app/src/main/java/com/compass/browser/BrowserViewModel.kt',
    language: 'kotlin',
    summary: 'Autonomous Compass task-execution loop driving Android WebView DOM snapshots and JS actions.',
    content: `package com.compass.browser

import android.webkit.WebView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.coroutines.resume

data class BrowserUiState(
    val currentUrl: String = "https://en.wikipedia.org",
    val pageTitle: String = "",
    val isAgentRunning: Boolean = false,
    val lastAgentStep: String? = null
)

class BrowserViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState = _uiState.asStateFlow()

    private val agentApi = CompassBrowserAgent(BuildConfig.BACKEND_BASE_URL)

    fun updateAddressBar(url: String) {
        _uiState.update { it.copy(currentUrl = url) }
    }

    fun onPageLoaded(url: String, title: String) {
        _uiState.update { it.copy(currentUrl = url, pageTitle = title) }
    }

    fun runAutonomousTask(goal: String, webView: WebView) {
        viewModelScope.launch {
            _uiState.update { it.copy(isAgentRunning = true, lastAgentStep = "Inspecting page...") }
            try {
                for (step in 1..12) {
                    val domSnapshot = captureDomSnapshot(webView)
                    val decision = withContext(Dispatchers.IO) {
                        agentApi.nextStep(goal, _uiState.value.currentUrl, domSnapshot)
                    }

                    _uiState.update { it.copy(lastAgentStep = "Step $step: \${decision.actionName}") }

                    when (decision.actionName) {
                        "navigate_to_url" -> {
                            val target = decision.args.optString("url")
                            withContext(Dispatchers.Main) { webView.loadUrl(target) }
                            delay(1800)
                        }
                        "click_element" -> {
                            val refId = decision.args.optInt("ref_id")
                            executeJs(webView, "window.__compassBridge.click($refId)")
                            delay(1000)
                        }
                        "type_text" -> {
                            val refId = decision.args.optInt("ref_id")
                            val text = JSONObject.quote(decision.args.optString("text"))
                            val submit = decision.args.optBoolean("submit_after", false)
                            executeJs(webView, "window.__compassBridge.type($refId, $text, $submit)")
                            delay(900)
                        }
                        "scroll_page" -> {
                            val dir = JSONObject.quote(decision.args.optString("direction", "down"))
                            executeJs(webView, "window.__compassBridge.scroll($dir)")
                            delay(500)
                        }
                        "complete_task" -> {
                            _uiState.update {
                                it.copy(
                                    isAgentRunning = false,
                                    lastAgentStep = decision.args.optString("summary")
                                )
                            }
                            return@launch
                        }
                    }
                }
            } finally {
                _uiState.update { it.copy(isAgentRunning = false) }
            }
        }
    }

    private suspend fun captureDomSnapshot(webView: WebView): String =
        executeJs(webView, DomBridgeScript.CAPTURE_SCRIPT)

    private suspend fun executeJs(webView: WebView, script: String): String =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                webView.evaluateJavascript(script) { result ->
                    cont.resume(result ?: "{}")
                }
            }
        }
}`,
  },
  {
    path: 'app/src/main/assets/DomBridge.js',
    language: 'javascript',
    summary: 'Injected WebView DOM indexer and action bridge assigning refIds to interactive elements.',
    content: `window.__compassBridge = {
  capture: function () {
    const selectors = 'a[href], button, input, select, textarea, [role="button"]';
    const nodes = Array.from(document.querySelectorAll(selectors)).slice(0, 65);
    const elements = [];

    nodes.forEach((el, idx) => {
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) return;
      const refId = idx + 1;
      el.setAttribute('data-compass-ref', String(refId));
      elements.push({
        refId,
        tag: el.tagName.toLowerCase(),
        label: (el.innerText || el.getAttribute('aria-label') || el.placeholder || el.value || '').trim().slice(0, 80),
        type: el.type || null,
        href: el.href || null
      });
    });

    return JSON.stringify({
      title: document.title,
      url: window.location.href,
      text: document.body.innerText.slice(0, 5000),
      elements
    });
  },
  click: function (refId) {
    const el = document.querySelector('[data-compass-ref="' + refId + '"]');
    if (!el) return false;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.click();
    return true;
  },
  type: function (refId, value, submitAfter) {
    const el = document.querySelector('[data-compass-ref="' + refId + '"]');
    if (!el) return false;
    el.focus();
    el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    if (submitAfter && el.form) el.form.submit();
    return true;
  },
  scroll: function (direction) {
    const y = direction === 'up' ? -450 : 450;
    window.scrollBy({ top: y, behavior: 'smooth' });
  }
};`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    summary: 'Android manifest granting Internet and Microphone permissions for voice-driven browser control.',
    content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.compass.browser">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />

    <application
        android:allowBackup="true"
        android:label="Compass Browser"
        android:usesCleartextTraffic="false"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,
  },
];
