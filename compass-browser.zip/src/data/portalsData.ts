import type { AutomationRoutine } from '../types/browser';

export interface ShopProduct {
  id: string;
  name: string;
  brand: string;
  category: 'Audio' | 'Keyboards' | 'Accessories';
  price: number;
  rating: number;
  reviewCount: number;
  inStock: boolean;
  image?: string;
  specs: string[];
  description: string;
}

export interface FlightOption {
  id: string;
  airline: string;
  flightNumber: string;
  origin: string;
  destination: string;
  departTime: string;
  arriveTime: string;
  duration: string;
  nonstop: boolean;
  cabin: 'Economy' | 'Premium Economy' | 'Business';
  price: number;
  seatsAvailable: number;
}

export interface BankAccount {
  id: string;
  name: string;
  accountMask: string;
  balance: number;
}

export interface UtilityBill {
  id: string;
  biller: string;
  accountRef: string;
  dueDate: string;
  amount: number;
  status: 'Overdue' | 'Due Soon' | 'Paid';
}

export interface BankTransaction {
  id: string;
  date: string;
  merchant: string;
  category: string;
  amount: number;
}

export interface MailMessage {
  id: string;
  from: string;
  fromEmail: string;
  subject: string;
  receivedAt: string;
  unread: boolean;
  folder: 'Inbox' | 'Sent';
  preview: string;
  body: string;
}

export const ANDROID_WALLPAPER_URL =
  '/src/assets/images/android_wallpaper_abstract_1794937728593.jpg';
export const TOKYO_BANNER_URL =
  '/src/assets/images/travel_tokyo_skyline_1794937731445.jpg';

export const INITIAL_SHOP_PRODUCTS: ShopProduct[] = [
  {
    id: 'prod-anc-pro',
    name: 'Auralis Studio ANC Headphones',
    brand: 'Auralis',
    category: 'Audio',
    price: 229,
    rating: 4.9,
    reviewCount: 418,
    inStock: true,
    image: '/src/assets/images/product_headphones_studio_1794937730999.jpg',
    specs: ['42h Battery', 'Hybrid Active Noise Canceling', 'USB-C Lossless', 'Multipoint Bluetooth 5.4'],
    description:
      'Matte graphite over-ear studio headphones tuned for clear vocal presence and adaptive noise cancellation during travel.',
  },
  {
    id: 'prod-anc-lite',
    name: 'SoundCraft QuietAir 300',
    brand: 'SoundCraft',
    category: 'Audio',
    price: 179,
    rating: 4.5,
    reviewCount: 204,
    inStock: true,
    image: '/src/assets/images/product_headphones_studio_1794937730999.jpg',
    specs: ['30h Battery', 'Standard ANC', 'Foldable Frame'],
    description:
      'Lightweight everyday wireless headphones with balanced bass and compact carry case.',
  },
  {
    id: 'prod-anc-flagship',
    name: 'Monolith Reference One ANC',
    brand: 'Monolith',
    category: 'Audio',
    price: 349,
    rating: 4.8,
    reviewCount: 162,
    inStock: true,
    specs: ['50h Battery', 'Planar Drivers', 'Spatial Tracking'],
    description:
      'Flagship audiophile wireless headphones with precision CNC aluminum yokes.',
  },
  {
    id: 'prod-mech-75',
    name: 'KeyForge Tactile 65 Wireless',
    brand: 'KeyForge',
    category: 'Keyboards',
    price: 165,
    rating: 4.8,
    reviewCount: 312,
    inStock: true,
    image: '/src/assets/images/product_mechanical_keyboard_1794937729865.jpg',
    specs: ['Anodized Aluminum', 'Hot-Swappable Switches', 'QMK / VIA', 'Tri-Mode Wireless'],
    description:
      'Compact 65% machined aluminum mechanical keyboard with gasket mount acoustics and PBT dye-sub keycaps.',
  },
  {
    id: 'prod-gan-100',
    name: 'VoltCore 100W GaN Travel Charger',
    brand: 'VoltCore',
    category: 'Accessories',
    price: 58,
    rating: 4.7,
    reviewCount: 529,
    inStock: true,
    specs: ['3x USB-C + 1x USB-A', '100W PD 3.1', 'Foldable Prongs'],
    description:
      'Pocket-sized gallium nitride charger capable of powering a laptop and Pixel phone simultaneously.',
  },
];

export const INITIAL_FLIGHTS: FlightOption[] = [
  {
    id: 'fl-nh7',
    airline: 'Pacific Star Airways',
    flightNumber: 'PS 107',
    origin: 'San Francisco (SFO)',
    destination: 'Tokyo (HND)',
    departTime: '11:20 AM',
    arriveTime: '3:45 PM +1',
    duration: '11h 25m',
    nonstop: true,
    cabin: 'Economy',
    price: 845,
    seatsAvailable: 9,
  },
  {
    id: 'fl-jal2',
    airline: 'Nippon Meridian',
    flightNumber: 'NM 002',
    origin: 'San Francisco (SFO)',
    destination: 'Tokyo (NRT)',
    departTime: '1:10 PM',
    arriveTime: '5:05 PM +1',
    duration: '10h 55m',
    nonstop: true,
    cabin: 'Economy',
    price: 892,
    seatsAvailable: 4,
  },
  {
    id: 'fl-ua837',
    airline: 'TransOceanic Air',
    flightNumber: 'TO 837',
    origin: 'San Francisco (SFO)',
    destination: 'Tokyo (HND)',
    departTime: '9:30 AM',
    arriveTime: '6:15 PM +1',
    duration: '15h 45m',
    nonstop: false,
    cabin: 'Economy',
    price: 710,
    seatsAvailable: 14,
  },
  {
    id: 'fl-ps-prem',
    airline: 'Pacific Star Airways',
    flightNumber: 'PS 109',
    origin: 'San Francisco (SFO)',
    destination: 'Tokyo (HND)',
    departTime: '4:15 PM',
    arriveTime: '8:30 PM +1',
    duration: '11h 15m',
    nonstop: true,
    cabin: 'Premium Economy',
    price: 1290,
    seatsAvailable: 6,
  },
];

export const INITIAL_BANK_ACCOUNTS: BankAccount[] = [
  { id: 'acc-chk', name: 'Everyday Checking', accountMask: '••4821', balance: 4820.45 },
  { id: 'acc-sav', name: 'High-Yield Savings', accountMask: '••9104', balance: 18450.0 },
];

export const INITIAL_BILLS: UtilityBill[] = [
  {
    id: 'bill-electric',
    biller: 'Pacific Grid Electric',
    accountRef: 'PGE-88412',
    dueDate: 'Nov 18, 2026',
    amount: 142.8,
    status: 'Overdue',
  },
  {
    id: 'bill-fiber',
    biller: 'Metro Fiber Internet',
    accountRef: 'MFI-30921',
    dueDate: 'Nov 24, 2026',
    amount: 79.0,
    status: 'Due Soon',
  },
  {
    id: 'bill-water',
    biller: 'Bay Municipal Water',
    accountRef: 'BMW-11204',
    dueDate: 'Nov 05, 2026',
    amount: 54.2,
    status: 'Paid',
  },
];

export const INITIAL_TRANSACTIONS: BankTransaction[] = [
  { id: 'tx-1', date: 'Nov 15', merchant: 'Whole Foods Market', category: 'Groceries', amount: -86.4 },
  { id: 'tx-2', date: 'Nov 14', merchant: 'Direct Deposit · Payroll', category: 'Income', amount: 3420.0 },
  { id: 'tx-3', date: 'Nov 11', merchant: 'Bay Municipal Water', category: 'Utilities', amount: -54.2 },
  { id: 'tx-4', date: 'Nov 09', merchant: 'Blue Bottle Coffee', category: 'Dining', amount: -11.5 },
];

export const INITIAL_MAILS: MailMessage[] = [
  {
    id: 'mail-1',
    from: 'Pacific Grid Electric',
    fromEmail: 'billing@pacificgrid.example',
    subject: 'Action Required: Statement #PGE-88412 Past Due ($142.80)',
    receivedAt: '8:14 AM',
    unread: true,
    folder: 'Inbox',
    preview: 'Your November electricity statement of $142.80 for account PGE-88412 is ready for payment.',
    body: 'Hello,\n\nYour November electricity statement for account PGE-88412 is past due.\nAmount Due: $142.80\nDue Date: Nov 18, 2026\n\nPlease log into your Apex Personal Banking portal to complete payment and avoid late fees.',
  },
  {
    id: 'mail-2',
    from: 'ShopSphere Rewards',
    fromEmail: 'offers@shopsphere.example',
    subject: 'Member Perk: 15% Off Audio & Keyboards with code SAVE15',
    receivedAt: 'Yesterday',
    unread: true,
    folder: 'Inbox',
    preview: 'Use promo code SAVE15 at checkout on ShopSphere for 15% off studio headphones and keyboards.',
    body: 'Good news!\n\nAs a verified ShopSphere member, apply promo code SAVE15 in your shopping cart to save 15% on any Audio or Keyboard purchase over $100.',
  },
  {
    id: 'mail-3',
    from: 'Maya Lin · Design Ops',
    fromEmail: 'maya.lin@studio.example',
    subject: 'Tokyo Design Summit — Arrival Logistics',
    receivedAt: 'Nov 14',
    unread: false,
    folder: 'Inbox',
    preview: 'Looking forward to seeing you in Tokyo next month. Aim for a nonstop SFO to HND flight under $900.',
    body: 'Hi there,\n\nOur kickoff dinner in Shinjuku starts at 7:00 PM. Please book a nonstop flight from San Francisco (SFO) to Tokyo (HND) under $900 and pick a window seat if available. Reply with your flight number once reserved!',
  },
];

export const PRESET_ROUTINES: AutomationRoutine[] = [
  {
    id: 'routine-bill',
    title: 'Check Email & Pay Overdue Utility Bill',
    description:
      'Reads unread billing notices in Pulse Webmail, verifies the account number and amount, then navigates to Apex Bank to prepare payment.',
    prompt:
      'Check my unread emails in Pulse Mail for any overdue utility bill, verify the account number and exact amount, then open Apex Bank and pay that bill (ask me to confirm before finalizing payment).',
    startUrl: 'compass://mail',
    category: 'Finance',
  },
  {
    id: 'routine-shop',
    title: 'Compare ANC Headphones & Apply Promo',
    description:
      'Checks ShopSphere for noise-canceling headphones under $250, selects the highest-rated option, adds to cart, and applies promo code SAVE15.',
    prompt:
      'Go to ShopSphere, find the highest-rated wireless noise-canceling headphones under $250, open the product to check specs, add it to cart, apply promo code SAVE15, and proceed to checkout (ask for my approval before placing the order).',
    startUrl: 'compass://shop',
    category: 'Shopping',
  },
  {
    id: 'routine-flight',
    title: 'Book Nonstop SFO to Tokyo Flight',
    description:
      'Searches Horizon Flights for nonstop Economy flights from San Francisco to Tokyo under $900, selects a window seat, and prepares booking.',
    prompt:
      'Open Horizon Flights, search for nonstop Economy flights from San Francisco to Tokyo, choose the cheapest nonstop flight under $900, select a window seat like 14A, fill passenger name Alex Mercer, and ask me to confirm the booking.',
    startUrl: 'compass://flights',
    category: 'Travel',
  },
  {
    id: 'routine-hn',
    title: 'Browse Live Hacker News Top Stories',
    description:
      'Fetches live Hacker News inside the Android browser, inspects the top links, opens the #1 story, and summarizes it.',
    prompt:
      'Navigate to https://news.ycombinator.com, read the top 5 front-page headlines, open the first story or discussion link, and give me a concise summary.',
    startUrl: 'https://news.ycombinator.com',
    category: 'Live Web',
  },
  {
    id: 'routine-wiki',
    title: 'Research Android OS History on Wikipedia',
    description:
      'Searches live Wikipedia inside the Android browser for Android operating system history and extracts major milestones.',
    prompt:
      'Search Wikipedia for "Android (operating system)", open the article in the browser, scroll to review its history, and summarize 4 key milestones.',
    startUrl: 'https://en.wikipedia.org',
    category: 'Live Web',
  },
];
