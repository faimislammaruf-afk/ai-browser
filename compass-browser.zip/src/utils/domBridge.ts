import type { DomElementRef, PageSnapshot } from '../types/browser';

function isElementVisible(el: HTMLElement): boolean {
  const style = window.getComputedStyle(el);
  if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
    return false;
  }
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

export function extractDomSnapshotFromContainer(
  container: HTMLElement,
  url: string,
  title: string
): PageSnapshot {
  // Clear previous stamps
  container.querySelectorAll('[data-compass-ref]').forEach((node) => {
    node.removeAttribute('data-compass-ref');
  });

  const interactiveNodes = Array.from(
    container.querySelectorAll<HTMLElement>(
      'a[href], button, input, select, textarea, [role="button"]'
    )
  );

  const elements: DomElementRef[] = [];
  let refCounter = 1;

  for (const el of interactiveNodes) {
    if (refCounter > 65) break;
    if (!isElementVisible(el)) continue;

    const tag = el.tagName.toLowerCase();
    const inputEl = el as HTMLInputElement;
    const type = tag === 'input' ? inputEl.type?.toLowerCase() : undefined;
    if (type === 'hidden') continue;

    const ariaLabel = el.getAttribute('aria-label')?.trim();
    const placeholder = el.getAttribute('placeholder')?.trim();
    const innerText = el.innerText?.replace(/\s+/g, ' ').trim();
    const value =
      tag === 'input' || tag === 'textarea' || tag === 'select'
        ? (el as HTMLInputElement | HTMLSelectElement).value
        : undefined;

    let label = ariaLabel || innerText || placeholder || value || el.getAttribute('name') || tag;
    if (tag === 'input' && (type === 'checkbox' || type === 'radio')) {
      const parentLabel = el.closest('label')?.innerText?.replace(/\s+/g, ' ').trim();
      if (parentLabel) label = parentLabel;
    }

    const refId = refCounter++;
    el.setAttribute('data-compass-ref', String(refId));

    let options: string[] | undefined;
    if (tag === 'select') {
      const selectEl = el as HTMLSelectElement;
      options = Array.from(selectEl.options)
        .map((opt) => opt.text.trim())
        .filter(Boolean)
        .slice(0, 12);
    }

    elements.push({
      refId,
      tag,
      role:
        tag === 'a'
          ? 'link'
          : tag === 'button' || el.getAttribute('role') === 'button'
            ? 'button'
            : tag,
      label: label.slice(0, 95),
      type,
      href: tag === 'a' ? (el as HTMLAnchorElement).getAttribute('href') || undefined : undefined,
      placeholder,
      value: value !== undefined ? String(value).slice(0, 60) : undefined,
      options,
      disabled: (el as HTMLButtonElement).disabled === true,
      checked: type === 'checkbox' || type === 'radio' ? inputEl.checked : undefined,
    });
  }

  const rawText = (container.innerText || '').replace(/\n{3,}/g, '\n\n').trim().slice(0, 6500);

  return {
    url,
    title,
    isExternal: false,
    text: rawText,
    elements,
  };
}

export interface VisualTargetRect {
  top: number;
  left: number;
  width: number;
  height: number;
}

export function getElementVisualRect(
  viewportEl: HTMLElement,
  refId: number
): VisualTargetRect | null {
  const target = viewportEl.querySelector<HTMLElement>(`[data-compass-ref="${refId}"]`);
  if (!target) return null;

  target.scrollIntoView({ behavior: 'smooth', block: 'center' });

  const vpRect = viewportEl.getBoundingClientRect();
  const elRect = target.getBoundingClientRect();

  return {
    top: elRect.top - vpRect.top,
    left: elRect.left - vpRect.left,
    width: elRect.width,
    height: elRect.height,
  };
}

function setReactInputValue(
  element: HTMLInputElement | HTMLTextAreaElement,
  value: string
) {
  const prototype =
    element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
  const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
  if (descriptor?.set) {
    descriptor.set.call(element, value);
  } else {
    element.value = value;
  }
  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

function setReactSelectValue(element: HTMLSelectElement, optionValue: string) {
  const lowerTarget = optionValue.toLowerCase();
  const match = Array.from(element.options).find(
    (opt) =>
      opt.value.toLowerCase() === lowerTarget ||
      opt.text.toLowerCase().includes(lowerTarget)
  );
  const nextVal = match ? match.value : optionValue;
  const descriptor = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
  if (descriptor?.set) {
    descriptor.set.call(element, nextVal);
  } else {
    element.value = nextVal;
  }
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

export function executePortalAction(
  container: HTMLElement,
  action:
    | { type: 'click'; refId: number }
    | { type: 'type'; refId: number; text: string; submitAfter?: boolean }
    | { type: 'select'; refId: number; optionValue: string }
    | { type: 'scroll'; direction: string }
): { ok: boolean; message: string } {
  if (action.type === 'scroll') {
    if (action.direction === 'top') {
      container.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (action.direction === 'bottom') {
      container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
    } else if (action.direction === 'up') {
      container.scrollBy({ top: -320, behavior: 'smooth' });
    } else {
      container.scrollBy({ top: 320, behavior: 'smooth' });
    }
    return { ok: true, message: `Scrolled ${action.direction}` };
  }

  const target = container.querySelector<HTMLElement>(`[data-compass-ref="${action.refId}"]`);
  if (!target) {
    return {
      ok: false,
      message: `Element refId=${action.refId} was not found on the current page.`,
    };
  }

  target.scrollIntoView({ behavior: 'smooth', block: 'center' });

  if (action.type === 'click') {
    target.focus();
    target.click();
    return {
      ok: true,
      message: `Tapped element [${action.refId}] (${target.innerText?.trim() || target.tagName})`,
    };
  }

  if (action.type === 'type') {
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
      target.focus();
      setReactInputValue(target, action.text);
      if (action.submitAfter) {
        const form = target.closest('form');
        if (form) {
          form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
        }
      }
      return {
        ok: true,
        message: `Typed "${action.text}" into [${action.refId}]`,
      };
    }
    return {
      ok: false,
      message: `Element [${action.refId}] is a ${target.tagName}, not a text input.`,
    };
  }

  if (action.type === 'select') {
    if (target instanceof HTMLSelectElement) {
      target.focus();
      setReactSelectValue(target, action.optionValue);
      return {
        ok: true,
        message: `Selected "${action.optionValue}" in [${action.refId}]`,
      };
    }
    return {
      ok: false,
      message: `Element [${action.refId}] is not a select dropdown.`,
    };
  }

  return { ok: false, message: 'Unsupported DOM action.' };
}
