import React, { useCallback, useEffect, useRef, useState } from 'react';
import { MessageSquare, X } from 'lucide-react';
import { AndroidCodeView } from './components/AndroidCodeView';
import { AndroidDeviceFrame } from './components/AndroidDeviceFrame';
import { AssistantPanel } from './components/AssistantPanel';
import { AutomationsView } from './components/AutomationsView';
import { HistoryView } from './components/HistoryView';
import { PRESET_ROUTINES } from './data/portalsData';
import type {
  AgentActionLog,
  AgentOverlayTarget,
  AssistantModelId,
  AutomationRoutine,
  BookmarkEntry,
  BrowserTab,
  ChatMessage,
  HistoryEntry,
  PageSnapshot,
} from './types/browser';
import {
  executePortalAction,
  extractDomSnapshotFromContainer,
  getElementVisualRect,
  type VisualTargetRect,
} from './utils/domBridge';

type WorkspaceView = 'browser' | 'automations' | 'history' | 'android-code';

const ACTIVE_MODEL_ID: AssistantModelId = 'baidu/ernie-5.5-flash-preview:free';

interface PendingApprovalState {
  contents: Array<Record<string, unknown>>;
  assistantMsgId: string;
  pendingCallId: string;
  pendingCallName: string;
  trailingSkippedCalls: Array<{ id: string; name: string }>;
  actionsSoFar: AgentActionLog[];
  stepCount: number;
}

function getPortalTitle(url: string): string {
  const lower = url.toLowerCase();
  if (lower.startsWith('compass://shop')) return 'ShopSphere — Storefront';
  if (lower.startsWith('compass://flights')) return 'Horizon Flights — Travel';
  if (lower.startsWith('compass://bank')) return 'Apex Personal Banking';
  if (lower.startsWith('compass://mail')) return 'Pulse Webmail';
  return 'Compass Browser — Home';
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const INITIAL_TAB: BrowserTab = {
  id: 'tab-1',
  url: 'compass://home',
  title: 'Compass Browser — Home',
  history: ['compass://home'],
  historyIndex: 0,
  isLoading: false,
  scrollY: 0,
};

export default function App() {
  const [activeView, setActiveView] = useState<WorkspaceView>('browser');
  const [tabs, setTabs] = useState<BrowserTab[]>([INITIAL_TAB]);
  const [activeTabId, setActiveTabId] = useState<string>(INITIAL_TAB.id);
  const [historyEntries, setHistoryEntries] = useState<HistoryEntry[]>([]);
  const [bookmarks, setBookmarks] = useState<BookmarkEntry[]>([
    { id: 'bm-1', url: 'compass://shop', title: 'ShopSphere Storefront', createdAt: Date.now() },
    { id: 'bm-2', url: 'compass://flights', title: 'Horizon Flights', createdAt: Date.now() },
  ]);
  const [routines, setRoutines] = useState<AutomationRoutine[]>(PRESET_ROUTINES);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isAgentRunning, setIsAgentRunning] = useState(false);
  const [currentStepLabel, setCurrentStepLabel] = useState<string | null>(null);
  const [overlayTarget, setOverlayTarget] = useState<AgentOverlayTarget | null>(null);
  const [visualRect, setVisualRect] = useState<VisualTargetRect | null>(null);
  const [liveSnapshot, setLiveSnapshot] = useState<PageSnapshot | undefined>(undefined);
  const [mobileSheetOpen, setMobileSheetOpen] = useState(false);

  const portalContainerRef = useRef<HTMLDivElement | null>(null);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const assistantInputRef = useRef<HTMLTextAreaElement | null>(null);

  const tabsRef = useRef<BrowserTab[]>(tabs);
  const activeTabIdRef = useRef<string>(activeTabId);
  const historyRef = useRef<HistoryEntry[]>(historyEntries);
  const bookmarksRef = useRef<BookmarkEntry[]>(bookmarks);
  const pendingIframeNavRef = useRef<((snap: PageSnapshot | undefined) => void) | null>(null);
  const stopRequestedRef = useRef<boolean>(false);
  const pendingApprovalRef = useRef<PendingApprovalState | null>(null);

  useEffect(() => {
    tabsRef.current = tabs;
  }, [tabs]);

  useEffect(() => {
    activeTabIdRef.current = activeTabId;
  }, [activeTabId]);

  useEffect(() => {
    historyRef.current = historyEntries;
  }, [historyEntries]);

  useEffect(() => {
    bookmarksRef.current = bookmarks;
  }, [bookmarks]);

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  const recordHistory = useCallback((url: string, title: string, initiatedBy: 'user' | 'agent') => {
    setHistoryEntries((prev) => {
      const next = [
        {
          id: `hist-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          url,
          title,
          visitedAt: Date.now(),
          initiatedBy,
        },
        ...prev.slice(0, 99),
      ];
      historyRef.current = next;
      return next;
    });
  }, []);

  const refreshLivePortalSnapshot = useCallback(() => {
    const tab = tabsRef.current.find((t) => t.id === activeTabIdRef.current);
    if (!tab) return undefined;
    if (tab.url.startsWith('compass://') && portalContainerRef.current) {
      const snap = extractDomSnapshotFromContainer(
        portalContainerRef.current,
        tab.url,
        getPortalTitle(tab.url)
      );
      setLiveSnapshot(snap);
      return snap;
    }
    setLiveSnapshot(tab.snapshot);
    return tab.snapshot;
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      refreshLivePortalSnapshot();
    }, 120);
    return () => clearTimeout(timer);
  }, [activeTab.url, activeTabId, refreshLivePortalSnapshot]);

  const navigateTab = useCallback(
    async (
      tabId: string,
      rawUrl: string,
      initiatedBy: 'user' | 'agent' = 'user',
      method: 'GET' | 'POST' = 'GET',
      formBody?: string
    ): Promise<PageSnapshot | undefined> => {
      const url = rawUrl.trim();
      const isInternal = url.startsWith('compass://');
      const initialTitle = isInternal ? getPortalTitle(url) : url;

      setTabs((prev) => {
        const next = prev.map((t) => {
          if (t.id !== tabId) return t;
          const slicedHistory = t.history.slice(0, t.historyIndex + 1);
          const shouldPush = slicedHistory[slicedHistory.length - 1] !== url;
          const nextHistory = shouldPush ? [...slicedHistory, url] : slicedHistory;
          return {
            ...t,
            url,
            title: initialTitle,
            history: nextHistory,
            historyIndex: nextHistory.length - 1,
            isLoading: !isInternal,
            snapshot: isInternal ? undefined : t.snapshot,
          };
        });
        tabsRef.current = next;
        return next;
      });

      if (isInternal) {
        recordHistory(url, initialTitle, initiatedBy);
        await sleep(90);
        return refreshLivePortalSnapshot();
      }

      try {
        const res = await fetch('/api/browser/fetch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url, method, formBody }),
        });
        const data = await res.json();

        if (!res.ok) {
          const errSnap: PageSnapshot = {
            url,
            title: 'Error Loading Page',
            isExternal: true,
            text: data.error || 'Failed to load external webpage.',
            elements: [],
            error: data.error || `HTTP ${res.status}`,
          };
          setTabs((prev) => {
            const next = prev.map((t) =>
              t.id === tabId ? { ...t, isLoading: false, title: errSnap.title, snapshot: errSnap } : t
            );
            tabsRef.current = next;
            return next;
          });
          setLiveSnapshot(errSnap);
          return errSnap;
        }

        const snap = data as PageSnapshot;
        setTabs((prev) => {
          const next = prev.map((t) =>
            t.id === tabId
              ? { ...t, url: snap.url, title: snap.title, isLoading: false, snapshot: snap }
              : t
          );
          tabsRef.current = next;
          return next;
        });
        setLiveSnapshot(snap);
        recordHistory(snap.url, snap.title, initiatedBy);
        return snap;
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Network error';
        const errSnap: PageSnapshot = {
          url,
          title: 'Connection Error',
          isExternal: true,
          text: msg,
          elements: [],
          error: msg,
        };
        setTabs((prev) => {
          const next = prev.map((t) =>
            t.id === tabId ? { ...t, isLoading: false, title: errSnap.title, snapshot: errSnap } : t
          );
          tabsRef.current = next;
          return next;
        });
        setLiveSnapshot(errSnap);
        return errSnap;
      }
    },
    [recordHistory, refreshLivePortalSnapshot]
  );

  // Listen for navigation events posted from external srcDoc iframes
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const data = event.data as {
        type?: string;
        url?: string;
        method?: 'GET' | 'POST';
        formBody?: string;
      } | null;
      if (!data || data.type !== 'compass-navigate' || !data.url) return;
      const initiatedBy = pendingIframeNavRef.current ? 'agent' : 'user';
      void navigateTab(
        activeTabIdRef.current,
        data.url,
        initiatedBy,
        data.method || 'GET',
        data.formBody
      ).then((snap) => {
        if (pendingIframeNavRef.current) {
          const resolveNav = pendingIframeNavRef.current;
          pendingIframeNavRef.current = null;
          resolveNav(snap);
        }
      });
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [navigateTab]);

  const handleGoBack = useCallback(async () => {
    const tab = tabsRef.current.find((t) => t.id === activeTabIdRef.current);
    if (!tab || tab.historyIndex <= 0) return;
    const prevIdx = tab.historyIndex - 1;
    const targetUrl = tab.history[prevIdx];
    setTabs((prev) => {
      const next = prev.map((t) =>
        t.id === tab.id ? { ...t, historyIndex: prevIdx, url: targetUrl } : t
      );
      tabsRef.current = next;
      return next;
    });
    if (!targetUrl.startsWith('compass://')) {
      await navigateTab(tab.id, targetUrl, 'user');
    } else {
      await sleep(180);
      refreshLivePortalSnapshot();
    }
  }, [navigateTab, refreshLivePortalSnapshot]);

  const handleGoForward = useCallback(async () => {
    const tab = tabsRef.current.find((t) => t.id === activeTabIdRef.current);
    if (!tab || tab.historyIndex >= tab.history.length - 1) return;
    const nextIdx = tab.historyIndex + 1;
    const targetUrl = tab.history[nextIdx];
    setTabs((prev) => {
      const next = prev.map((t) =>
        t.id === tab.id ? { ...t, historyIndex: nextIdx, url: targetUrl } : t
      );
      tabsRef.current = next;
      return next;
    });
    if (!targetUrl.startsWith('compass://')) {
      await navigateTab(tab.id, targetUrl, 'user');
    } else {
      await sleep(180);
      refreshLivePortalSnapshot();
    }
  }, [navigateTab, refreshLivePortalSnapshot]);

  const handleNewTab = useCallback(
    (url = 'compass://home') => {
      const id = `tab-${Date.now()}`;
      const newTab: BrowserTab = {
        id,
        url,
        title: url.startsWith('compass://') ? getPortalTitle(url) : url,
        history: [url],
        historyIndex: 0,
        isLoading: !url.startsWith('compass://'),
        scrollY: 0,
      };
      setTabs((prev) => {
        const next = [...prev, newTab];
        tabsRef.current = next;
        return next;
      });
      setActiveTabId(id);
      activeTabIdRef.current = id;
      if (!url.startsWith('compass://')) {
        void navigateTab(id, url, 'user');
      }
      return id;
    },
    [navigateTab]
  );

  const handleSwitchTab = useCallback((tabId: string) => {
    setActiveTabId(tabId);
    activeTabIdRef.current = tabId;
  }, []);

  const handleCloseTab = useCallback((tabId: string) => {
    setTabs((prev) => {
      if (prev.length <= 1) return prev;
      const next = prev.filter((t) => t.id !== tabId);
      tabsRef.current = next;
      if (activeTabIdRef.current === tabId) {
        const fallback = next[next.length - 1].id;
        setActiveTabId(fallback);
        activeTabIdRef.current = fallback;
      }
      return next;
    });
  }, []);

  const executeSingleToolCall = useCallback(
    async (
      callName: string,
      args: Record<string, unknown>
    ): Promise<Record<string, unknown>> => {
      const currentTab = tabsRef.current.find((t) => t.id === activeTabIdRef.current) || tabsRef.current[0];

      if (callName === 'navigate_to_url') {
        const url = String(args.url || 'compass://home');
        setOverlayTarget({ actionType: 'navigate', label: url, timestamp: Date.now() });
        const snap = await navigateTab(currentTab.id, url, 'agent');
        setOverlayTarget(null);
        return {
          ok: !snap?.error,
          url: snap?.url || url,
          title: snap?.title || url,
          error: snap?.error,
          pageText: snap?.text?.slice(0, 1400) || '',
          elements: (snap?.elements || []).slice(0, 45),
        };
      }

      if (callName === 'open_web_search') {
        const query = String(args.query || '');
        const engine = String(args.engine || 'duckduckgo').toLowerCase();
        const targetUrl =
          engine === 'wikipedia'
            ? `https://en.wikipedia.org/w/index.php?search=${encodeURIComponent(query)}`
            : `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}&kl=us-en`;
        setOverlayTarget({ actionType: 'navigate', label: `Search: ${query}`, timestamp: Date.now() });
        const snap = await navigateTab(currentTab.id, targetUrl, 'agent');
        setOverlayTarget(null);
        return {
          ok: !snap?.error,
          url: snap?.url || targetUrl,
          title: snap?.title || query,
          error: snap?.error,
          pageText: snap?.text?.slice(0, 1400) || '',
          elements: (snap?.elements || []).slice(0, 45),
        };
      }

      if (callName === 'click_element') {
        const refId = Number(args.ref_id);
        const desc = String(args.element_description || `element #${refId}`);

        if (currentTab.url.startsWith('compass://') && portalContainerRef.current) {
          const rect = getElementVisualRect(portalContainerRef.current, refId);
          setVisualRect(rect);
          setOverlayTarget({ refId, actionType: 'tap', label: desc, timestamp: Date.now() });
          await sleep(120);
          const result = executePortalAction(portalContainerRef.current, { type: 'click', refId });
          await sleep(100);
          setVisualRect(null);
          setOverlayTarget(null);
          const snap = refreshLivePortalSnapshot();
          return {
            ok: result.ok,
            actionResult: result.message,
            url: snap?.url || currentTab.url,
            title: snap?.title || currentTab.title,
            pageText: snap?.text?.slice(0, 1400) || '',
            elements: (snap?.elements || []).slice(0, 45),
          };
        }

        // External webpage
        const targetEl = currentTab.snapshot?.elements.find((e) => e.refId === refId);
        setOverlayTarget({ refId, actionType: 'tap', label: desc, timestamp: Date.now() });
        await sleep(100);
        if (targetEl?.href) {
          const snap = await navigateTab(currentTab.id, targetEl.href, 'agent');
          setOverlayTarget(null);
          return {
            ok: !snap?.error,
            actionResult: `Navigated to ${targetEl.href}`,
            url: snap?.url,
            title: snap?.title,
            pageText: snap?.text?.slice(0, 1400) || '',
            elements: (snap?.elements || []).slice(0, 45),
          };
        }
        iframeRef.current?.contentWindow?.postMessage(
          { type: 'compass-action', action: 'click', refId },
          '*'
        );
        await sleep(180);
        setOverlayTarget(null);
        return {
          ok: true,
          actionResult: `Tapped [${refId}] on external page`,
          url: currentTab.url,
          title: currentTab.title,
          pageText: currentTab.snapshot?.text?.slice(0, 1400) || '',
          elements: (currentTab.snapshot?.elements || []).slice(0, 45),
        };
      }

      if (callName === 'type_text') {
        const refId = Number(args.ref_id);
        const text = String(args.text || '');
        const submitAfter = Boolean(args.submit_after);

        if (currentTab.url.startsWith('compass://') && portalContainerRef.current) {
          const rect = getElementVisualRect(portalContainerRef.current, refId);
          setVisualRect(rect);
          setOverlayTarget({
            refId,
            actionType: 'type',
            label: `"${text}"`,
            timestamp: Date.now(),
          });
          await sleep(120);
          const result = executePortalAction(portalContainerRef.current, {
            type: 'type',
            refId,
            text,
            submitAfter,
          });
          await sleep(100);
          setVisualRect(null);
          setOverlayTarget(null);
          const snap = refreshLivePortalSnapshot();
          return {
            ok: result.ok,
            actionResult: result.message,
            url: snap?.url || currentTab.url,
            title: snap?.title || currentTab.title,
            pageText: snap?.text?.slice(0, 1400) || '',
            elements: (snap?.elements || []).slice(0, 45),
          };
        }

        setOverlayTarget({ refId, actionType: 'type', label: `"${text}"`, timestamp: Date.now() });
        const navWaitPromise = submitAfter
          ? new Promise<PageSnapshot | undefined>((resolve) => {
              pendingIframeNavRef.current = resolve;
              setTimeout(() => {
                if (pendingIframeNavRef.current === resolve) {
                  pendingIframeNavRef.current = null;
                  resolve(undefined);
                }
              }, 2500);
            })
          : null;

        iframeRef.current?.contentWindow?.postMessage(
          { type: 'compass-action', action: 'type', refId, text, submitAfter },
          '*'
        );

        const navSnap = navWaitPromise ? await navWaitPromise : undefined;
        if (!navWaitPromise) await sleep(180);
        setOverlayTarget(null);
        const latestTab = tabsRef.current.find((t) => t.id === activeTabIdRef.current);
        const snapToUse = navSnap || latestTab?.snapshot;
        return {
          ok: true,
          actionResult: `Entered "${text}" into [${refId}]`,
          url: snapToUse?.url || latestTab?.url,
          title: snapToUse?.title || latestTab?.title,
          pageText: snapToUse?.text?.slice(0, 1400) || '',
          elements: (snapToUse?.elements || []).slice(0, 45),
        };
      }

      if (callName === 'select_option') {
        const refId = Number(args.ref_id);
        const optionValue = String(args.option_value || '');

        if (currentTab.url.startsWith('compass://') && portalContainerRef.current) {
          const rect = getElementVisualRect(portalContainerRef.current, refId);
          setVisualRect(rect);
          setOverlayTarget({
            refId,
            actionType: 'tap',
            label: `Select "${optionValue}"`,
            timestamp: Date.now(),
          });
          await sleep(110);
          const result = executePortalAction(portalContainerRef.current, {
            type: 'select',
            refId,
            optionValue,
          });
          await sleep(90);
          setVisualRect(null);
          setOverlayTarget(null);
          const snap = refreshLivePortalSnapshot();
          return {
            ok: result.ok,
            actionResult: result.message,
            url: snap?.url || currentTab.url,
            title: snap?.title || currentTab.title,
            pageText: snap?.text?.slice(0, 1400) || '',
            elements: (snap?.elements || []).slice(0, 45),
          };
        }

        iframeRef.current?.contentWindow?.postMessage(
          { type: 'compass-action', action: 'select', refId, optionValue },
          '*'
        );
        await sleep(150);
        return { ok: true, actionResult: `Selected ${optionValue}` };
      }

      if (callName === 'scroll_page') {
        const direction = String(args.direction || 'down');
        setOverlayTarget({ actionType: 'scroll', label: `Scroll ${direction}`, timestamp: Date.now() });
        if (currentTab.url.startsWith('compass://') && portalContainerRef.current) {
          executePortalAction(portalContainerRef.current, { type: 'scroll', direction });
        } else {
          iframeRef.current?.contentWindow?.postMessage({ type: 'compass-scroll', direction }, '*');
        }
        await sleep(120);
        setOverlayTarget(null);
        const snap = refreshLivePortalSnapshot();
        return {
          ok: true,
          actionResult: `Scrolled ${direction}`,
          url: snap?.url,
          pageText: snap?.text?.slice(0, 1400) || '',
          elements: (snap?.elements || []).slice(0, 45),
        };
      }

      if (callName === 'manage_tabs') {
        const action = String(args.action || 'new');
        if (action === 'new') {
          const nextUrl = String(args.url || 'compass://home');
          const newId = handleNewTab(nextUrl);
          await sleep(350);
          if (!nextUrl.startsWith('compass://')) {
            const snap = await navigateTab(newId, nextUrl, 'agent');
            return {
              ok: true,
              activeTabId: newId,
              openTabs: tabsRef.current.map((t) => ({ id: t.id, title: t.title, url: t.url })),
              url: snap?.url,
              title: snap?.title,
              pageText: snap?.text?.slice(0, 2800) || '',
              elements: snap?.elements || [],
            };
          }
          const snap = refreshLivePortalSnapshot();
          return {
            ok: true,
            activeTabId: newId,
            openTabs: tabsRef.current.map((t) => ({ id: t.id, title: t.title, url: t.url })),
            url: snap?.url,
            title: snap?.title,
            pageText: snap?.text?.slice(0, 2800) || '',
            elements: snap?.elements || [],
          };
        }
        if (action === 'switch' && args.tab_id) {
          handleSwitchTab(String(args.tab_id));
          await sleep(250);
          const snap = refreshLivePortalSnapshot();
          return {
            ok: true,
            activeTabId: String(args.tab_id),
            url: snap?.url,
            title: snap?.title,
            pageText: snap?.text?.slice(0, 2800) || '',
            elements: snap?.elements || [],
          };
        }
        if (action === 'close' && args.tab_id) {
          handleCloseTab(String(args.tab_id));
          await sleep(200);
          return {
            ok: true,
            openTabs: tabsRef.current.map((t) => ({ id: t.id, title: t.title, url: t.url })),
          };
        }
        return { ok: false, error: 'Invalid manage_tabs action' };
      }

      if (callName === 'go_back') {
        await handleGoBack();
        const snap = refreshLivePortalSnapshot();
        return {
          ok: true,
          url: snap?.url,
          title: snap?.title,
          pageText: snap?.text?.slice(0, 3000) || '',
          elements: snap?.elements || [],
        };
      }

      if (callName === 'go_forward') {
        await handleGoForward();
        const snap = refreshLivePortalSnapshot();
        return {
          ok: true,
          url: snap?.url,
          title: snap?.title,
          pageText: snap?.text?.slice(0, 3000) || '',
          elements: snap?.elements || [],
        };
      }

      if (callName === 'reload_page') {
        setOverlayTarget({ actionType: 'navigate', label: `Reload ${currentTab.url}`, timestamp: Date.now() });
        const snap = await navigateTab(currentTab.id, currentTab.url, 'agent');
        setOverlayTarget(null);
        return {
          ok: !snap?.error,
          url: snap?.url || currentTab.url,
          title: snap?.title || currentTab.title,
          pageText: snap?.text?.slice(0, 3000) || '',
          elements: snap?.elements || [],
        };
      }

      if (callName === 'manage_bookmarks') {
        const action = String(args.action || 'list');
        const targetUrl = String(args.url || currentTab.url);
        const targetTitle = String(args.title || currentTab.title || targetUrl);

        if (action === 'add') {
          const entry: BookmarkEntry = {
            id: `bm-${Date.now()}`,
            url: targetUrl,
            title: targetTitle,
            createdAt: Date.now(),
          };
          setBookmarks((prev) => {
            const next = [entry, ...prev.filter((b) => b.url !== targetUrl)];
            bookmarksRef.current = next;
            return next;
          });
          return { ok: true, actionResult: `Bookmarked ${targetTitle} (${targetUrl})`, bookmarks: bookmarksRef.current };
        }
        if (action === 'remove') {
          setBookmarks((prev) => {
            const next = prev.filter((b) => b.url !== targetUrl);
            bookmarksRef.current = next;
            return next;
          });
          return { ok: true, actionResult: `Removed bookmark ${targetUrl}`, bookmarks: bookmarksRef.current };
        }
        return { ok: true, bookmarks: bookmarksRef.current };
      }

      if (callName === 'read_browsing_history') {
        const limit = Math.min(25, Math.max(1, Number(args.limit || 10)));
        return {
          ok: true,
          entries: historyRef.current.slice(0, limit).map((h) => ({
            url: h.url,
            title: h.title,
            initiatedBy: h.initiatedBy,
            visitedAt: new Date(h.visitedAt).toISOString(),
          })),
        };
      }

      return { ok: false, error: `Unknown tool: ${callName}` };
    },
    [
      handleCloseTab,
      handleGoBack,
      handleGoForward,
      handleNewTab,
      handleSwitchTab,
      navigateTab,
      refreshLivePortalSnapshot,
    ]
  );

  const runAgentLoop = useCallback(
    async (
      initialContents: Array<Record<string, unknown>>,
      assistantMsgId: string,
      initialActions: AgentActionLog[] = [],
      initialStep = 0
    ) => {
      const MAX_STEPS = 14;
      let stepCount = initialStep;
      let actionsSoFar = [...initialActions];
      const workingContents = [...initialContents];

      setIsAgentRunning(true);
      stopRequestedRef.current = false;

      try {
        while (stepCount < MAX_STEPS) {
          if (stopRequestedRef.current) {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsgId
                  ? {
                      ...m,
                      actions: actionsSoFar,
                      text: m.text || 'Task execution paused by user.',
                    }
                  : m
              )
            );
            break;
          }

          setCurrentStepLabel(`Planning step ${stepCount + 1}...`);

          const res = await fetch('/api/agent/step', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: workingContents,
              model: ACTIVE_MODEL_ID,
            }),
          });

          const data = await res.json();
          if (!res.ok) {
            throw new Error(data.error || `Server error (${res.status})`);
          }

          if (data.assistantContent) {
            workingContents.push(data.assistantContent as Record<string, unknown>);
          }

          const calls = (data.toolCalls || []) as Array<{
            id: string;
            name: string;
            args?: Record<string, unknown>;
          }>;

          // If Compass responds with plain text and no tool calls, task turn is complete
          if (calls.length === 0) {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsgId
                  ? {
                      ...m,
                      text: data.text || 'Completed.',
                      actions: actionsSoFar,
                    }
                  : m
              )
            );
            break;
          }

          const functionResponseParts: Array<Record<string, unknown>> = [];

          // Execute browser tool calls sequentially; pause cleanly on request_user_confirmation
          for (let idx = 0; idx < calls.length; idx++) {
            const call = calls[idx];

            if (call.name === 'request_user_confirmation') {
              const cArgs = call.args || {};
              stepCount += 1;
              const logEntry: AgentActionLog = {
                id: `act-${Date.now()}-${stepCount}`,
                step: stepCount,
                toolName: call.name,
                args: cArgs,
                status: 'paused',
                resultSummary: 'Waiting for user approval',
                timestamp: Date.now(),
              };
              actionsSoFar = [...actionsSoFar, logEntry];

              const trailingSkippedCalls = calls
                .slice(idx + 1)
                .map((c) => ({ id: c.id, name: c.name }));

              pendingApprovalRef.current = {
                contents: workingContents,
                assistantMsgId,
                pendingCallId: call.id,
                pendingCallName: call.name,
                trailingSkippedCalls,
                actionsSoFar,
                stepCount,
              };

              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantMsgId
                    ? {
                        ...m,
                        actions: actionsSoFar,
                        confirmation: {
                          id: `conf-${Date.now()}`,
                          actionSummary: String(cArgs.action_summary || 'Confirm Action'),
                          details: String(cArgs.details || 'Please review before continuing.'),
                          riskLevel: (String(cArgs.risk_level || 'medium') as 'low' | 'medium' | 'high'),
                          pendingCallId: call.id,
                          pendingCallName: call.name,
                        },
                      }
                    : m
                )
              );
              setCurrentStepLabel('Waiting for your confirmation...');
              return;
            }

            if (call.name === 'complete_task') {
              const summary = String(call.args?.summary || 'Task completed.');
              const findings = Array.isArray(call.args?.key_findings)
                ? (call.args?.key_findings as string[])
                : [];
              const finalText =
                findings.length > 0
                  ? `${summary}\n\n${findings.map((f) => `• ${f}`).join('\n')}`
                  : summary;

              stepCount += 1;
              actionsSoFar = [
                ...actionsSoFar,
                {
                  id: `act-${Date.now()}-${stepCount}`,
                  step: stepCount,
                  toolName: 'complete_task',
                  args: call.args || {},
                  status: 'completed',
                  resultSummary: 'Task completed',
                  timestamp: Date.now(),
                },
              ];

              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantMsgId
                    ? {
                        ...m,
                        text: finalText,
                        actions: actionsSoFar,
                      }
                    : m
                )
              );
              setIsAgentRunning(false);
              setCurrentStepLabel(null);
              return;
            }

            stepCount += 1;
            const callArgs = call.args || {};
            const actionId = `act-${Date.now()}-${stepCount}`;
            setCurrentStepLabel(`Step ${stepCount}: ${call.name.replace(/_/g, ' ')}`);

            actionsSoFar = [
              ...actionsSoFar,
              {
                id: actionId,
                step: stepCount,
                toolName: call.name,
                args: callArgs,
                status: 'running',
                timestamp: Date.now(),
              },
            ];

            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsgId ? { ...m, actions: actionsSoFar } : m
              )
            );

            const toolResult = await executeSingleToolCall(call.name, callArgs);
            const ok = toolResult.ok !== false;

            actionsSoFar = actionsSoFar.map((a) =>
              a.id === actionId
                ? {
                    ...a,
                    status: ok ? 'completed' : 'error',
                    resultSummary: String(
                      toolResult.actionResult || toolResult.error || toolResult.title || 'Done'
                    ),
                  }
                : a
            );

            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsgId ? { ...m, actions: actionsSoFar } : m
              )
            );

            functionResponseParts.push({
              functionResponse: {
                id: call.id,
                name: call.name,
                response: toolResult,
              },
            });
          }

          if (functionResponseParts.length > 0) {
            workingContents.push({
              role: 'user',
              parts: functionResponseParts,
            });
          }
        }

        if (stepCount >= MAX_STEPS) {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMsgId && !m.text
                ? {
                    ...m,
                    text: 'Reached the maximum autonomous step limit for this turn. You can review the browser state or ask me to continue.',
                    actions: actionsSoFar,
                  }
                : m
            )
          );
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unexpected agent error';
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  text: `Unable to complete task: ${msg}`,
                  actions: actionsSoFar,
                  isError: true,
                }
              : m
          )
        );
      } finally {
        setIsAgentRunning(false);
        setCurrentStepLabel(null);
        setVisualRect(null);
        setOverlayTarget(null);
      }
    },
    [executeSingleToolCall]
  );

  const handleSendPrompt = useCallback(
    async (userPrompt: string) => {
      if (isAgentRunning) return;

      const userMsgId = `msg-u-${Date.now()}`;
      const assistantMsgId = `msg-a-${Date.now() + 1}`;

      setMessages((prev) => [
        ...prev,
        { id: userMsgId, role: 'user', text: userPrompt, timestamp: Date.now() },
        { id: assistantMsgId, role: 'assistant', text: '', timestamp: Date.now(), actions: [] },
      ]);

      const currentSnap = refreshLivePortalSnapshot();
      const openTabsSummary = tabsRef.current.map((t) => ({
        id: t.id,
        title: t.title,
        url: t.url,
        active: t.id === activeTabIdRef.current,
      }));

      const contextMessage = `User Request: ${userPrompt}

Current Android Browser State:
- Open Tabs: ${JSON.stringify(openTabsSummary)}
- Active Tab URL: ${currentSnap?.url || activeTab.url}
- Active Tab Title: ${currentSnap?.title || activeTab.title}
- Visible Page Text (truncated): ${(currentSnap?.text || '').slice(0, 1200)}
- Interactive DOM Elements ([refId]): ${JSON.stringify((currentSnap?.elements || []).slice(0, 45))}`;

      const initialContents = [
        {
          role: 'user',
          parts: [{ text: contextMessage }],
        },
      ];

      await runAgentLoop(initialContents, assistantMsgId);
    },
    [activeTab.title, activeTab.url, isAgentRunning, refreshLivePortalSnapshot, runAgentLoop]
  );

  const handleConfirmAction = useCallback(
    async (messageId: string, approved: boolean) => {
      const pending = pendingApprovalRef.current;
      if (!pending || pending.assistantMsgId !== messageId) return;
      pendingApprovalRef.current = null;

      const updatedActions = pending.actionsSoFar.map((a) =>
        a.status === 'paused'
          ? {
              ...a,
              status: approved ? ('completed' as const) : ('error' as const),
              resultSummary: approved ? 'Approved by user' : 'Declined by user',
            }
          : a
      );

      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId
            ? {
                ...m,
                confirmationDecision: approved ? 'approved' : 'rejected',
                actions: updatedActions,
              }
            : m
        )
      );

      const responseParts: Array<Record<string, unknown>> = [
        {
          functionResponse: {
            id: pending.pendingCallId,
            name: pending.pendingCallName,
            response: {
              approved,
              userDecision: approved
                ? 'User approved this action. Proceed with clicking the final confirm/pay/submit button and then call complete_task.'
                : 'User declined this action. Do NOT submit or pay; stop gracefully and call complete_task explaining the action was cancelled.',
            },
          },
        },
        ...pending.trailingSkippedCalls.map((skipped) => ({
          functionResponse: {
            id: skipped.id,
            name: skipped.name,
            response: {
              skipped: true,
              reason: 'Execution paused for user confirmation.',
            },
          },
        })),
      ];

      const nextContents: Array<Record<string, unknown>> = [
        ...pending.contents,
        {
          role: 'user',
          parts: responseParts,
        },
      ];

      await runAgentLoop(nextContents, messageId, updatedActions, pending.stepCount);
    },
    [runAgentLoop]
  );

  const handleStopAgent = useCallback(() => {
    stopRequestedRef.current = true;
    pendingApprovalRef.current = null;
    setIsAgentRunning(false);
    setCurrentStepLabel(null);
    setVisualRect(null);
    setOverlayTarget(null);
  }, []);

  const handleSaveRoutine = useCallback((prompt: string) => {
    const title = prompt.length > 46 ? `${prompt.slice(0, 46).trim()}...` : prompt;
    setRoutines((prev) => [
      {
        id: `custom-${Date.now()}`,
        title,
        description: prompt,
        prompt,
        startUrl: activeTabIdRef.current
          ? tabsRef.current.find((t) => t.id === activeTabIdRef.current)?.url || 'compass://home'
          : 'compass://home',
        category: 'Custom',
      },
      ...prev,
    ]);
  }, []);

  const handleRunRoutine = useCallback(
    async (routine: AutomationRoutine) => {
      setRoutines((prev) =>
        prev.map((r) => (r.id === routine.id ? { ...r, lastRunAt: Date.now() } : r))
      );
      setActiveView('browser');
      await navigateTab(activeTabIdRef.current, routine.startUrl, 'agent');
      await sleep(250);
      void handleSendPrompt(routine.prompt);
    },
    [handleSendPrompt, navigateTab]
  );

  const handleNewTask = () => {
    handleStopAgent();
    setMessages([]);
    setActiveView('browser');
    setMobileSheetOpen(true);
    setTimeout(() => assistantInputRef.current?.focus(), 100);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F7F9] text-slate-900">
      {/* 3-Zone Top Bar Contract */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveView('browser');
            }}
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            Compass Browser
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            {[
              { id: 'browser', label: 'Browser' },
              { id: 'automations', label: 'Automations' },
              { id: 'history', label: 'History' },
              { id: 'android-code', label: 'Android Code' },
            ].map((item) => {
              const active = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveView(item.id as WorkspaceView)}
                  className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                    active
                      ? 'text-slate-900 border-[#1A56DB]'
                      : 'border-transparent hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleNewTask}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#1A56DB] rounded-lg hover:bg-[#1E40AF] transition-colors whitespace-nowrap shrink-0"
            >
              New Task
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1">
        <div className="md:hidden bg-white border-b border-slate-200 px-3 py-1.5 flex items-center gap-1 overflow-x-auto">
          {[
            { id: 'browser', label: 'Browser' },
            { id: 'automations', label: 'Automations' },
            { id: 'history', label: 'History' },
            { id: 'android-code', label: 'Android Code' },
          ].map((item) => {
            const active = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveView(item.id as WorkspaceView)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {activeView === 'browser' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 lg:py-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Left Column: Android 15 Browser Device Viewport */}
              <div className="lg:col-span-5 flex flex-col justify-start">
                <AndroidDeviceFrame
                  tabs={tabs}
                  activeTab={activeTab}
                  portalContainerRef={portalContainerRef}
                  iframeRef={iframeRef}
                  overlayTarget={overlayTarget}
                  visualRect={visualRect}
                  isAgentRunning={isAgentRunning}
                  liveSnapshot={liveSnapshot}
                  onNavigate={(url, by) => void navigateTab(activeTab.id, url, by)}
                  onGoBack={() => void handleGoBack()}
                  onGoForward={() => void handleGoForward()}
                  onReload={() => void navigateTab(activeTab.id, activeTab.url, 'user')}
                  onNewTab={(url) => handleNewTab(url)}
                  onSwitchTab={handleSwitchTab}
                  onCloseTab={handleCloseTab}
                  onOpenAssistantSheet={() => setMobileSheetOpen(true)}
                />
              </div>

              {/* Right Column (Desktop): Gemini Personal Assistant & Task Runner */}
              <div className="hidden lg:flex lg:col-span-7 flex-col h-[760px]">
                <AssistantPanel
                  messages={messages}
                  isRunning={isAgentRunning}
                  currentStepLabel={currentStepLabel}
                  inputRef={assistantInputRef}
                  onSendPrompt={(prompt) => void handleSendPrompt(prompt)}
                  onStopAgent={handleStopAgent}
                  onConfirmAction={(msgId, approved) => void handleConfirmAction(msgId, approved)}
                  onSaveRoutine={handleSaveRoutine}
                />
              </div>
            </div>

            {/* Mobile Sticky Trigger Bar (<= 15% viewport height) */}
            <div className="lg:hidden fixed bottom-3 left-4 right-4 z-30">
              <button
                type="button"
                onClick={() => setMobileSheetOpen(true)}
                className="w-full min-h-[48px] px-4 rounded-2xl bg-slate-900 text-white shadow-lg flex items-center justify-between text-sm font-medium"
              >
                <span className="flex items-center gap-2 truncate">
                  <MessageSquare className="w-4 h-4 text-[#60A5FA] shrink-0" />
                  <span className="truncate">
                    {isAgentRunning && currentStepLabel
                      ? currentStepLabel
                      : 'Ask Compass Assistant'}
                  </span>
                </span>
                <span className="text-xs text-slate-300 font-mono shrink-0">
                  {messages.length > 0 ? `${messages.length} msgs` : 'Open'}
                </span>
              </button>
            </div>

            {/* Mobile Bottom Sheet Drawer for Compass Assistant */}
            {mobileSheetOpen && (
              <div className="lg:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex flex-col justify-end">
                <div className="bg-white rounded-t-3xl h-[82vh] flex flex-col overflow-hidden">
                  <div className="px-4 pt-3 pb-2 flex items-center justify-between border-b border-slate-200">
                    <div className="w-10 h-1 rounded-full bg-slate-300 mx-auto absolute left-1/2 -translate-x-1/2 top-2" />
                    <span className="font-display text-sm font-semibold text-slate-900">
                      Compass Assistant
                    </span>
                    <button
                      type="button"
                      onClick={() => setMobileSheetOpen(false)}
                      aria-label="Close assistant drawer"
                      className="min-h-[36px] min-w-[36px] rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex-1 overflow-hidden p-2">
                    <AssistantPanel
                      messages={messages}
                      isRunning={isAgentRunning}
                      currentStepLabel={currentStepLabel}
                      inputRef={assistantInputRef}
                      onSendPrompt={(prompt) => void handleSendPrompt(prompt)}
                      onStopAgent={handleStopAgent}
                      onConfirmAction={(msgId, approved) =>
                        void handleConfirmAction(msgId, approved)
                      }
                      onSaveRoutine={handleSaveRoutine}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeView === 'automations' && (
          <AutomationsView
            routines={routines}
            onRunRoutine={(r) => void handleRunRoutine(r)}
            onDeleteRoutine={(id) =>
              setRoutines((prev) => prev.filter((r) => r.id !== id))
            }
          />
        )}

        {activeView === 'history' && (
          <HistoryView
            entries={historyEntries}
            onOpenUrl={(url) => {
              setActiveView('browser');
              void navigateTab(activeTab.id, url, 'user');
            }}
            onClearHistory={() => setHistoryEntries([])}
          />
        )}

        {activeView === 'android-code' && <AndroidCodeView />}
      </main>
    </div>
  );
}
