import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { AlertCircle, ClipboardPaste, Link2, Loader2, Search, ShieldCheck, X } from 'lucide-react';
import { ApiEndpointsSection } from './components/ApiEndpointsSection';
import { Header } from './components/Header';
import { QualityTable } from './components/QualityTable';
import { SessionHistory } from './components/SessionHistory';
import { VideoOverviewCard } from './components/VideoOverviewCard';
import type {
  CaptchaChallengeResponse,
  DownloadCategory,
  DownloadOption,
  ExtractorSource,
  HistoryEntry,
  PrepareDownloadResponse,
  VideoAnalysisResult,
} from './types';
import { sanitizeClientFilename } from './utils/formatters';

const SAMPLE_LINKS = [
  {
    label: 'Rick Astley — Never Gonna Give You Up (4K)',
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  },
];

export default function App() {
  const inputRef = useRef<HTMLInputElement>(null);

  const [urlInput, setUrlInput] = useState('');
  const [sourceMode, setSourceMode] = useState<ExtractorSource>('auto');
  const [analyzing, setAnalyzing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [captchaChallenge, setCaptchaChallenge] = useState<CaptchaChallengeResponse | null>(null);
  const [captchaInput, setCaptchaInput] = useState('');
  const [verifyingCaptcha, setVerifyingCaptcha] = useState(false);
  const [analysis, setAnalysis] = useState<VideoAnalysisResult | null>(null);
  const [customTitle, setCustomTitle] = useState('');
  const [activeCategory, setActiveCategory] = useState<DownloadCategory>('video-audio');
  const [preparingId, setPreparingId] = useState<string | null>(null);
  const [downloadStage, setDownloadStage] = useState<string | null>(null);
  const [completedIds, setCompletedIds] = useState<Record<string, boolean>>({});
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const applyAnalysisSuccess = (result: VideoAnalysisResult) => {
    setCaptchaChallenge(null);
    setCaptchaInput('');
    setAnalysis(result);
    setCustomTitle(result.sanitizedTitle);

    if (result.options.some((o) => o.category === 'video-audio')) {
      setActiveCategory('video-audio');
    } else {
      setActiveCategory('audio');
    }

    setHistory((prev) => {
      const filtered = prev.filter((item) => item.videoId !== result.videoId);
      return [
        {
          videoId: result.videoId,
          sourceUrl: result.sourceUrl,
          title: result.title,
          author: result.author,
          durationSeconds: result.durationSeconds,
          thumbnailUrl: result.thumbnailUrl,
          analyzedAt: result.analyzedAt,
        },
        ...filtered,
      ].slice(0, 10);
    });
  };

  const analyzeUrl = async (targetUrl: string, overrideSource?: ExtractorSource) => {
    const trimmed = targetUrl.trim();
    if (!trimmed) {
      setErrorMessage('Paste a video link to inspect available download qualities.');
      inputRef.current?.focus();
      return;
    }

    setAnalyzing(true);
    setErrorMessage(null);
    setCaptchaChallenge(null);
    setCompletedIds({});

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: trimmed,
          source: overrideSource ?? sourceMode,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || 'Could not analyze this video URL.');
      }

      if (data && data.captchaRequired === true) {
        setCaptchaChallenge(data as CaptchaChallengeResponse);
        setCaptchaInput('');
        return;
      }

      applyAnalysisSuccess(data as VideoAnalysisResult);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unexpected error analyzing video link.';
      setErrorMessage(message);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCaptchaSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!captchaChallenge || !captchaInput.trim()) return;

    setVerifyingCaptcha(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/savefrom/captcha', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          value: captchaInput.trim(),
          hash: captchaChallenge.captchaHash,
          url: captchaChallenge.pendingUrl,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || 'Captcha verification failed.');
      }

      if (data && data.captchaRequired === true) {
        setCaptchaChallenge(data as CaptchaChallengeResponse);
        setCaptchaInput('');
        return;
      }

      applyAnalysisSuccess(data as VideoAnalysisResult);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Captcha verification failed.';
      setErrorMessage(message);
    } finally {
      setVerifyingCaptcha(false);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    void analyzeUrl(urlInput);
  };

  const handlePasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text && text.trim()) {
        setUrlInput(text.trim());
        void analyzeUrl(text.trim());
        return;
      }
    } catch {
      // Clipboard API requires permission; focus input as clean fallback
    }
    inputRef.current?.focus();
  };

  const handleDownloadOption = async (option: DownloadOption) => {
    if (!analysis || preparingId) return;

    setPreparingId(option.id);
    setDownloadStage(option.mode === 'merge' ? 'Muxing MP4...' : 'Preparing...');
    setErrorMessage(null);

    const safeTitle = sanitizeClientFilename(customTitle, analysis.sanitizedTitle);

    try {
      const prepResponse = await fetch('/api/prepare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: analysis.token,
          optionId: option.id,
          filename: safeTitle,
        }),
      });

      const prepData = await prepResponse.json();
      if (!prepResponse.ok) {
        throw new Error(prepData?.error || 'Failed to prepare media stream for download.');
      }

      const prepared = prepData as PrepareDownloadResponse;
      setDownloadStage('Downloading...');

      const fileResponse = await fetch(prepared.downloadUrl, {
        credentials: 'include',
      });

      if (!fileResponse.ok) {
        const errText = await fileResponse.text().catch(() => '');
        throw new Error(errText || `Download failed with HTTP ${fileResponse.status}.`);
      }

      const contentType = (fileResponse.headers.get('content-type') || '').toLowerCase();
      if (contentType.includes('text/html')) {
        throw new Error('Server returned an HTML response instead of the media file. Please re-analyze the link and try again.');
      }

      const totalBytes = Number(fileResponse.headers.get('content-length') || prepared.sizeBytes || 0);
      const chunks: BlobPart[] = [];
      let received = 0;

      if (fileResponse.body) {
        const reader = fileResponse.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            received += value.byteLength;
            if (totalBytes > 0) {
              const pct = Math.min(100, Math.round((received / totalBytes) * 100));
              setDownloadStage(`Downloading ${pct}%`);
            }
          }
        }
      } else {
        const buf = await fileResponse.arrayBuffer();
        chunks.push(new Uint8Array(buf));
      }

      const fallbackMime =
        option.container === 'mp3'
          ? 'audio/mpeg'
          : option.container === 'm4a'
            ? 'audio/mp4'
            : 'video/mp4';
      const blob = new Blob(chunks, { type: contentType || fallbackMime });
      const blobUrl = URL.createObjectURL(blob);

      const anchor = document.createElement('a');
      anchor.href = blobUrl;
      anchor.download = prepared.filename;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);

      setTimeout(() => URL.revokeObjectURL(blobUrl), 15000);
      setCompletedIds((prev) => ({ ...prev, [option.id]: true }));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Download failed.';
      setErrorMessage(message);
    } finally {
      setPreparingId(null);
      setDownloadStage(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <Header onPasteAction={handlePasteFromClipboard} />

      <main className="mx-auto w-full max-w-5xl flex-1 px-6 py-8 space-y-6">
        <section id="analyzer" className="rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="max-w-2xl space-y-1.5">
              <h1 className="text-2xl font-bold tracking-tight text-slate-900 [text-wrap:balance]">
                Video Quality Analyzer &amp; Downloader
              </h1>
              <p className="text-sm text-slate-600 leading-relaxed">
                Paste a video link to resolve high-definition MP4 qualities (480p–4K with audio) via API and download the file automatically renamed to the YouTube video title.
              </p>
            </div>

            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 self-start shrink-0" role="group" aria-label="Extractor API mode">
              <button
                type="button"
                onClick={() => setSourceMode('auto')}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  sourceMode === 'auto'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Auto API
              </button>
              <button
                type="button"
                onClick={() => setSourceMode('savefrom')}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  sourceMode === 'savefrom'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                SaveFrom API
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Link2
                className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />
              <input
                ref={inputRef}
                type="url"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                aria-label="Video URL"
                className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pl-10 pr-20 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none transition-colors"
              />
              <div className="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1">
                {urlInput && (
                  <button
                    type="button"
                    onClick={() => {
                      setUrlInput('');
                      inputRef.current?.focus();
                    }}
                    title="Clear input"
                    className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors cursor-pointer"
                  >
                    <X className="h-3.5 w-3.5" aria-hidden="true" />
                    <span className="sr-only">Clear input</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={handlePasteFromClipboard}
                  title="Paste from clipboard"
                  className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  <ClipboardPaste className="h-3.5 w-3.5" aria-hidden="true" />
                  <span className="sr-only">Paste from clipboard</span>
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={analyzing}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {analyzing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  <span>Fetching Qualities...</span>
                </>
              ) : (
                <>
                  <Search className="h-4 w-4" aria-hidden="true" />
                  <span>Get Qualities</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
            <span>Try sample:</span>
            {SAMPLE_LINKS.map((sample) => (
              <button
                key={sample.url}
                type="button"
                onClick={() => {
                  setUrlInput(sample.url);
                  void analyzeUrl(sample.url);
                }}
                className="font-medium text-blue-600 hover:text-blue-700 hover:underline cursor-pointer"
              >
                {sample.label}
              </button>
            ))}
          </div>
        </section>

        {errorMessage && (
          <div
            role="alert"
            className="flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-800"
          >
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
            <div className="flex-1">{errorMessage}</div>
          </div>
        )}

        {captchaChallenge && (
          <section className="rounded-xl border border-amber-200 bg-amber-50/70 p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                  <ShieldCheck className="h-4 w-4 text-amber-700" aria-hidden="true" />
                  <span>SaveFrom Captcha Verification</span>
                </div>
                <p className="text-xs text-slate-600">{captchaChallenge.message}</p>
              </div>
            </div>

            <form onSubmit={handleCaptchaSubmit} className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="overflow-hidden rounded-lg border border-slate-200 bg-white p-1 self-start">
                <img
                  src={captchaChallenge.captchaImageDataUrl}
                  alt="SaveFrom verification captcha"
                  className="h-12 w-auto object-contain"
                />
              </div>

              <input
                type="text"
                value={captchaInput}
                onChange={(e) => setCaptchaInput(e.target.value)}
                placeholder="Enter captcha characters"
                aria-label="Captcha code"
                className="w-full sm:w-56 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none"
              />

              <button
                type="submit"
                disabled={verifyingCaptcha || !captchaInput.trim()}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {verifyingCaptcha ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                    <span>Verifying...</span>
                  </>
                ) : (
                  <span>Verify &amp; Get Qualities</span>
                )}
              </button>
            </form>
          </section>
        )}

        {analyzing && (
          <div className="space-y-6" aria-busy="true" aria-label="Loading video formats">
            <div className="rounded-xl border border-slate-200 bg-white p-6">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
                <div className="md:col-span-5 aspect-video rounded-lg bg-slate-100 animate-pulse" />
                <div className="md:col-span-7 flex flex-col justify-between gap-4 py-1">
                  <div className="space-y-3">
                    <div className="h-6 w-4/5 rounded bg-slate-100 animate-pulse" />
                    <div className="h-4 w-1/2 rounded bg-slate-100 animate-pulse" />
                  </div>
                  <div className="space-y-2 border-t border-slate-100 pt-4">
                    <div className="h-3 w-40 rounded bg-slate-100 animate-pulse" />
                    <div className="h-9 w-full rounded-lg bg-slate-100 animate-pulse" />
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
              <div className="h-5 w-48 rounded bg-slate-100 animate-pulse" />
              <div className="h-11 w-full rounded bg-slate-100 animate-pulse" />
              <div className="h-11 w-full rounded bg-slate-100 animate-pulse" />
              <div className="h-11 w-full rounded bg-slate-100 animate-pulse" />
            </div>
          </div>
        )}

        {!analyzing && analysis && (
          <>
            <VideoOverviewCard
              analysis={analysis}
              customTitle={customTitle}
              onCustomTitleChange={setCustomTitle}
            />

            <QualityTable
              options={analysis.options}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
              preparingId={preparingId}
              downloadStage={downloadStage}
              completedIds={completedIds}
              onDownload={handleDownloadOption}
            />
          </>
        )}

        {!analyzing && !analysis && !captchaChallenge && (
          <section className="rounded-xl border border-slate-200 bg-white p-6">
            <h2 className="text-sm font-semibold text-slate-900">How the API pipeline works</h2>
            <div className="mt-4 grid grid-cols-1 gap-6 sm:grid-cols-3">
              <div className="space-y-1">
                <p className="font-mono text-xs font-medium text-slate-400">01</p>
                <p className="text-sm font-semibold text-slate-900">Resolve video metadata</p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Submits your link to <code className="font-mono">/api/analyze</code> (YouTube Innertube + SaveFrom.net fallback) to retrieve the exact title and available MP4 qualities.
                </p>
              </div>
              <div className="space-y-1">
                <p className="font-mono text-xs font-medium text-slate-400">02</p>
                <p className="text-sm font-semibold text-slate-900">Lossless MP4 + Audio</p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Choose from 4K, 1440p, 1080p, 720p, or 480p MP4 with audio — stream-copied via FFmpeg without re-encoding or quality loss.
                </p>
              </div>
              <div className="space-y-1">
                <p className="font-mono text-xs font-medium text-slate-400">03</p>
                <p className="text-sm font-semibold text-slate-900">Auto-rename on download</p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Fetches the verified binary stream via <code className="font-mono">/api/file</code> and saves it directly as <code className="font-mono">&lt;YouTube Video Title&gt;.mp4</code>.
                </p>
              </div>
            </div>
          </section>
        )}

        <SessionHistory
          entries={history}
          onSelect={(url) => {
            setUrlInput(url);
            void analyzeUrl(url);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onClear={() => setHistory([])}
        />

        <ApiEndpointsSection />
      </main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4 text-xs text-slate-500">
          <span>MediaPull</span>
          <span>API-driven video quality analyzer &amp; title renamer</span>
        </div>
      </footer>
    </div>
  );
}
