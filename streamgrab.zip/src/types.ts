export type DownloadCategory = 'video-audio' | 'audio' | 'video-only';

export type DeliveryMode = 'direct' | 'merge' | 'audio-direct' | 'audio-mp3';

export type ExtractorSource = 'auto' | 'savefrom';

export interface DownloadOption {
  id: string;
  category: DownloadCategory;
  qualityLabel: string;
  resolutionNote: string;
  container: 'mp4' | 'm4a' | 'mp3' | 'webm';
  codecSummary: string;
  fps?: number;
  estimatedBytes: number | null;
  hasAudio: boolean;
  hasVideo: boolean;
  mode: DeliveryMode;
  recommended?: boolean;
}

export interface VideoAnalysisResult {
  token: string;
  videoId: string;
  sourceUrl: string;
  title: string;
  sanitizedTitle: string;
  author: string;
  durationSeconds: number;
  viewCount: number | null;
  thumbnailUrl: string;
  extractor: string;
  options: DownloadOption[];
  analyzedAt: string;
}

export interface CaptchaChallengeResponse {
  captchaRequired: true;
  captchaImageDataUrl: string;
  captchaHash: string;
  pendingUrl: string;
  message: string;
}

export interface PrepareDownloadResponse {
  downloadId: string;
  downloadUrl: string;
  filename: string;
  sizeBytes: number | null;
}

export interface HistoryEntry {
  videoId: string;
  sourceUrl: string;
  title: string;
  author: string;
  durationSeconds: number;
  thumbnailUrl: string;
  analyzedAt: string;
}
