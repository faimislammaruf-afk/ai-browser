import { ArrowUpRight, Trash2 } from 'lucide-react';
import type { HistoryEntry } from '../types';
import { formatDuration } from '../utils/formatters';

interface SessionHistoryProps {
  entries: HistoryEntry[];
  onSelect: (url: string) => void;
  onClear: () => void;
}

export function SessionHistory({ entries, onSelect, onClear }: SessionHistoryProps) {
  return (
    <section id="history" className="rounded-xl border border-slate-200 bg-white overflow-hidden">
      <div className="flex items-center justify-between gap-4 border-b border-slate-200 px-6 py-4">
        <div>
          <h3 className="text-base font-semibold text-slate-900">Recent Links</h3>
          <p className="text-xs text-slate-500">
            Videos analyzed during this session ({entries.length})
          </p>
        </div>

        {entries.length > 0 && (
          <button
            type="button"
            onClick={onClear}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
            Clear
          </button>
        )}
      </div>

      {entries.length === 0 ? (
        <div className="px-6 py-8 text-sm text-slate-500">
          Analyzed video links will appear here so you can reload their qualities anytime.
        </div>
      ) : (
        <ul className="divide-y divide-slate-100">
          {entries.map((entry) => (
            <li
              key={`${entry.videoId}-${entry.analyzedAt}`}
              className="flex items-center justify-between gap-4 px-6 py-3 hover:bg-slate-50/80 transition-colors"
            >
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-900">{entry.title}</p>
                <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-500 tabular-nums">
                  <span className="truncate">{entry.author}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{formatDuration(entry.durationSeconds)}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-400">{entry.videoId}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onSelect(entry.sourceUrl)}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Load</span>
                <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
