interface HeaderProps {
  onPasteAction: () => void;
}

export function Header({ onPasteAction }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-8 px-6 py-3.5">
        <a
          href="#analyzer"
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-600"
        >
          MediaPull
        </a>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600" aria-label="Primary">
          <a
            href="#analyzer"
            className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
          >
            Analyzer
          </a>
          <a
            href="#qualities"
            className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
          >
            Qualities
          </a>
          <a
            href="#history"
            className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
          >
            History
          </a>
          <a
            href="#api"
            className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
          >
            API
          </a>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onPasteAction}
            className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
          >
            Paste Link
          </button>
        </div>
      </div>
    </header>
  );
}
