import { useState } from 'react';
import { Check, Copy } from 'lucide-react';

export function ApiEndpointsSection() {
  const [copied, setCopied] = useState(false);

  const curlExample = `curl -s -X POST http://localhost:3000/api/analyze \\
  -H "Content-Type: application/json" \\
  -d '{"url":"https://www.youtube.com/watch?v=dQw4w9WgXcQ"}'`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(curlExample);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard write unavailable in non-secure context
    }
  };

  return (
    <section id="api" className="rounded-xl border border-slate-200 bg-white overflow-hidden">
      <div className="flex flex-col gap-3 border-b border-slate-200 px-6 py-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-base font-semibold text-slate-900">REST API Workflow</h3>
          <p className="text-xs text-slate-500">
            Every step — link inspection, stream muxing, and title-renamed file delivery — runs through these endpoints
          </p>
        </div>

        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 self-start sm:self-auto rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          {copied ? (
            <>
              <Check className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
              <span>Copied cURL</span>
            </>
          ) : (
            <>
              <Copy className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Copy cURL</span>
            </>
          )}
        </button>
      </div>

      <div className="divide-y divide-slate-100 text-sm">
        <div className="grid grid-cols-1 gap-2 px-6 py-3.5 sm:grid-cols-12 sm:items-center">
          <div className="sm:col-span-4 font-mono text-xs font-semibold text-slate-900">
            POST /api/analyze
          </div>
          <div className="sm:col-span-8 text-xs text-slate-600">
            Accepts <code className="font-mono text-slate-800">{'{ url }'}</code>, resolves video metadata, title, and all available stream qualities.
          </div>
        </div>

        <div className="grid grid-cols-1 gap-2 px-6 py-3.5 sm:grid-cols-12 sm:items-center">
          <div className="sm:col-span-4 font-mono text-xs font-semibold text-slate-900">
            POST /api/prepare
          </div>
          <div className="sm:col-span-8 text-xs text-slate-600">
            Accepts <code className="font-mono text-slate-800">{'{ token, optionId, filename }'}</code>, merges HD video + audio when needed, and returns a download URL.
          </div>
        </div>

        <div className="grid grid-cols-1 gap-2 px-6 py-3.5 sm:grid-cols-12 sm:items-center">
          <div className="sm:col-span-4 font-mono text-xs font-semibold text-slate-900">
            GET /api/file/:downloadId
          </div>
          <div className="sm:col-span-8 text-xs text-slate-600">
            Streams the media file with <code className="font-mono text-slate-800">Content-Disposition</code> set to the sanitized YouTube video title.
          </div>
        </div>
      </div>
    </section>
  );
}
