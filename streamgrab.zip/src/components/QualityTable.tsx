import { Check, Download, Loader2 } from 'lucide-react';
import type { DownloadCategory, DownloadOption } from '../types';
import { formatBytes } from '../utils/formatters';

interface QualityTableProps {
  options: DownloadOption[];
  activeCategory: DownloadCategory;
  onCategoryChange: (category: DownloadCategory) => void;
  preparingId: string | null;
  downloadStage: string | null;
  completedIds: Record<string, boolean>;
  onDownload: (option: DownloadOption) => void;
}

const CATEGORY_TABS: Array<{ id: DownloadCategory; label: string }> = [
  { id: 'video-audio', label: 'MP4 (Video + Audio)' },
  { id: 'audio', label: 'Audio Only' },
];

export function QualityTable({
  options,
  activeCategory,
  onCategoryChange,
  preparingId,
  downloadStage,
  completedIds,
  onDownload,
}: QualityTableProps) {
  const counts: Record<DownloadCategory, number> = {
    'video-audio': options.filter((o) => o.category === 'video-audio').length,
    audio: options.filter((o) => o.category === 'audio').length,
    'video-only': 0,
  };

  const filtered = options.filter((o) => o.category === activeCategory);

  return (
    <section id="qualities" className="rounded-xl border border-slate-200 bg-white overflow-hidden">
      <div className="flex flex-col gap-4 border-b border-slate-200 px-6 py-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-base font-semibold text-slate-900">Available Download Qualities</h3>
          <p className="text-xs text-slate-500">
            Lossless MP4 streams (480p to 4K) merged with original audio — zero quality drop
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 self-start sm:self-auto" role="tablist">
          {CATEGORY_TABS.map((tab) => {
            const isActive = activeCategory === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => onCategoryChange(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer tabular-nums ${
                  isActive
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label} ({counts[tab.id]})
              </button>
            );
          })}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="px-6 py-10 text-center text-sm text-slate-500">
          No streams available in this category for the current video.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/70 text-xs font-medium text-slate-500">
                <th className="py-2.5 pl-6 pr-4">Quality</th>
                <th className="py-2.5 px-4">Format &amp; Codec</th>
                <th className="py-2.5 px-4">Delivery</th>
                <th className="py-2.5 px-4 text-right">Est. Size</th>
                <th className="py-2.5 pl-4 pr-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filtered.map((opt) => {
                const isPreparing = preparingId === opt.id;
                const isDone = Boolean(completedIds[opt.id]);

                return (
                  <tr key={opt.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 pl-6 pr-4 align-middle">
                      <div className="flex items-baseline gap-2">
                        <span className="font-mono text-sm font-semibold text-slate-900 tabular-nums">
                          {opt.qualityLabel}
                        </span>
                        {opt.fps && opt.fps > 30 && (
                          <span className="font-mono text-xs text-slate-500 tabular-nums">
                            {opt.fps}fps
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500">
                        {opt.resolutionNote}
                        {opt.recommended ? ' · Recommended' : ''}
                      </div>
                    </td>

                    <td className="py-3 px-4 align-middle">
                      <div className="font-mono text-xs font-medium text-slate-800 uppercase">
                        {opt.container}
                      </div>
                      <div className="text-xs text-slate-500">{opt.codecSummary}</div>
                    </td>

                    <td className="py-3 px-4 align-middle text-xs text-slate-600">
                      {opt.mode === 'merge' && 'Lossless Mux (Video + Audio)'}
                      {opt.mode === 'direct' && 'Direct Stream'}
                      {opt.mode === 'audio-direct' && 'Direct Audio Stream'}
                      {opt.mode === 'audio-mp3' && 'API Transcode (192k MP3)'}
                    </td>

                    <td className="py-3 px-4 align-middle text-right font-mono text-xs text-slate-700 tabular-nums whitespace-nowrap">
                      {formatBytes(opt.estimatedBytes)}
                    </td>

                    <td className="py-3 pl-4 pr-6 align-middle text-right">
                      <button
                        type="button"
                        disabled={preparingId !== null}
                        onClick={() => onDownload(opt)}
                        className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed tabular-nums ${
                          opt.recommended
                            ? 'bg-blue-600 text-white hover:bg-blue-700'
                            : 'bg-slate-900 text-white hover:bg-slate-800'
                        }`}
                      >
                        {isPreparing ? (
                          <>
                            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                            <span>{downloadStage || (opt.mode === 'merge' ? 'Muxing...' : 'Preparing...')}</span>
                          </>
                        ) : isDone ? (
                          <>
                            <Check className="h-3.5 w-3.5" aria-hidden="true" />
                            <span>Downloaded</span>
                          </>
                        ) : (
                          <>
                            <Download className="h-3.5 w-3.5" aria-hidden="true" />
                            <span>Download .{opt.container}</span>
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
