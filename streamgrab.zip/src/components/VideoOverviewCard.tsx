import { useState } from 'react';
import { Film, RotateCcw, ExternalLink } from 'lucide-react';
import type { VideoAnalysisResult } from '../types';
import { formatDuration, formatViews, sanitizeClientFilename } from '../utils/formatters';

interface VideoOverviewCardProps {
  analysis: VideoAnalysisResult;
  customTitle: string;
  onCustomTitleChange: (nextTitle: string) => void;
}

export function VideoOverviewCard({
  analysis,
  customTitle,
  onCustomTitleChange,
}: VideoOverviewCardProps) {
  const [imgFailed, setImgFailed] = useState(false);
  const viewsText = formatViews(analysis.viewCount);
  const resolvedPreviewName = sanitizeClientFilename(customTitle, analysis.sanitizedTitle);
  const isEdited = customTitle !== analysis.sanitizedTitle;

  return (
    <section className="rounded-xl border border-slate-200 bg-white p-6">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-12 items-stretch">
        <div className="md:col-span-5">
          <div className="relative aspect-video w-full overflow-hidden rounded-lg border border-slate-200 bg-slate-100">
            {!imgFailed && analysis.thumbnailUrl ? (
              <img
                src={analysis.thumbnailUrl}
                alt={analysis.title}
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-slate-100 to-slate-200 p-4 text-center">
                <Film className="h-7 w-7 text-slate-400" aria-hidden="true" />
                <span className="line-clamp-2 text-xs font-medium text-slate-600">
                  {analysis.title}
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="md:col-span-7 flex flex-col justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-start justify-between gap-4">
              <h2 className="text-xl font-semibold tracking-tight text-slate-900 leading-snug [text-wrap:balance]">
                {analysis.title}
              </h2>
              <a
                href={analysis.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                title="Open original video"
                className="shrink-0 rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors"
              >
                <ExternalLink className="h-4 w-4" aria-hidden="true" />
                <span className="sr-only">Open original video</span>
              </a>
            </div>

            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 tabular-nums">
              <span className="font-medium text-slate-700">{analysis.author}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">{formatDuration(analysis.durationSeconds)}</span>
              {viewsText && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{viewsText}</span>
                </>
              )}
              <span aria-hidden="true">·</span>
              <span className="font-mono text-slate-400">{analysis.videoId}</span>
              <span aria-hidden="true">·</span>
              <span>{analysis.extractor}</span>
            </div>
          </div>

          <div className="space-y-2 border-t border-slate-100 pt-4">
            <div className="flex items-center justify-between gap-2">
              <label
                htmlFor="download-filename-input"
                className="text-xs font-medium text-slate-700"
              >
                Download filename (auto-named from video title)
              </label>
              {isEdited && (
                <button
                  type="button"
                  onClick={() => onCustomTitleChange(analysis.sanitizedTitle)}
                  className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <RotateCcw className="h-3 w-3" aria-hidden="true" />
                  Reset to title
                </button>
              )}
            </div>

            <input
              id="download-filename-input"
              type="text"
              value={customTitle}
              onChange={(e) => onCustomTitleChange(e.target.value)}
              placeholder={analysis.sanitizedTitle}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none transition-colors"
            />

            <p className="text-xs text-slate-500 truncate font-mono">
              Saved as: {resolvedPreviewName}.&lt;ext&gt;
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
