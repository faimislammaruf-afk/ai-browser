import express from 'express';
import type { Request, Response } from 'express';
import { execFile } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { promisify } from 'node:util';
import vm from 'node:vm';
import { Innertube, Log } from 'youtubei.js';
import type {
  CaptchaChallengeResponse,
  DownloadOption,
  ExtractorSource,
  PrepareDownloadResponse,
  VideoAnalysisResult,
} from './src/types.ts';

const execFileAsync = promisify(execFile);

const PORT = Number(process.env.PORT) || 3000;
const FFMPEG_PATH = '/usr/bin/ffmpeg';
const ANALYSIS_TTL_MS = 25 * 60 * 1000;
const PREPARED_FILE_TTL_MS = 10 * 60 * 1000;
const MAX_CACHE_ENTRIES = 100;
const CHUNK_SIZE_BYTES = 2 * 1024 * 1024; // 2 MB chunks bypass CDN single-stream throttling
const CHUNK_CONCURRENCY = 4;

const BROWSER_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

interface ServerFormatSpec {
  option: DownloadOption;
  videoUrl?: string;
  audioUrl?: string;
  videoBytes?: number | null;
  audioBytes?: number | null;
}

interface CachedAnalysis {
  result: VideoAnalysisResult;
  formatsById: Map<string, ServerFormatSpec>;
  createdAt: number;
}

interface PreparedFileEntry {
  kind: 'tempfile' | 'direct-proxy';
  filePath?: string;
  upstreamUrl?: string;
  filename: string;
  mimeType: string;
  sizeBytes: number | null;
  createdAt: number;
}

const analysisCache = new Map<string, CachedAnalysis>();
const preparedDownloads = new Map<string, PreparedFileEntry>();

let innertubePromise: Promise<Innertube> | null = null;
let saveFromWorkerToken: string | null = null;
let cachedSaveFromSigner: { sign: (url: string) => Promise<Record<string, unknown>>; loadedAt: number } | null = null;

async function getInnertube(): Promise<Innertube> {
  if (!innertubePromise) {
    Log.setLevel(Log.Level.NONE);
    innertubePromise = Innertube.create({ generate_session_locally: true }).catch((err) => {
      innertubePromise = null;
      throw err;
    });
  }
  return innertubePromise;
}

function isPrivateOrBlockedHost(hostname: string): boolean {
  const lower = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    lower === 'localhost' ||
    lower === '0.0.0.0' ||
    lower === '::1' ||
    lower.endsWith('.local') ||
    lower.endsWith('.internal')
  ) {
    return true;
  }

  const ipType = net.isIP(lower);
  if (ipType === 4) {
    const parts = lower.split('.').map(Number);
    if (parts[0] === 10 || parts[0] === 127 || parts[0] === 0) return true;
    if (parts[0] === 169 && parts[1] === 254) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    return true;
  }
  if (ipType === 6) {
    return true;
  }
  return false;
}

function normalizeAndValidateInputUrl(rawInput: string): URL | null {
  const trimmed = rawInput.trim();
  if (!trimmed || trimmed.length > 2048) return null;

  const withScheme = /^[a-zA-Z0-9_-]{11}$/.test(trimmed)
    ? `https://www.youtube.com/watch?v=${trimmed}`
    : trimmed.startsWith('http://') || trimmed.startsWith('https://')
      ? trimmed
      : `https://${trimmed}`;

  try {
    const parsed = new URL(withScheme);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
    if (isPrivateOrBlockedHost(parsed.hostname)) return null;
    return parsed;
  } catch {
    return null;
  }
}

function extractYouTubeVideoId(rawInput: string): string | null {
  const parsed = normalizeAndValidateInputUrl(rawInput);
  if (!parsed) return null;

  const host = parsed.hostname.toLowerCase();
  const allowedYouTubeHosts = new Set([
    'youtube.com',
    'www.youtube.com',
    'm.youtube.com',
    'music.youtube.com',
    'youtube-nocookie.com',
    'www.youtube-nocookie.com',
    'youtu.be',
    'www.youtu.be',
  ]);

  if (!allowedYouTubeHosts.has(host)) {
    return null;
  }

  let candidate: string | null = null;
  if (host === 'youtu.be' || host === 'www.youtu.be') {
    candidate = parsed.pathname.split('/').filter(Boolean)[0] || null;
  } else {
    const vParam = parsed.searchParams.get('v');
    if (vParam) {
      candidate = vParam;
    } else {
      const parts = parsed.pathname.split('/').filter(Boolean);
      if (
        parts.length >= 2 &&
        (parts[0] === 'shorts' || parts[0] === 'embed' || parts[0] === 'live' || parts[0] === 'v')
      ) {
        candidate = parts[1];
      }
    }
  }

  if (candidate && /^[a-zA-Z0-9_-]{11}$/.test(candidate)) {
    return candidate;
  }
  return null;
}

function isTrustedPublicDownloadUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return false;
    return !isPrivateOrBlockedHost(parsed.hostname);
  } catch {
    return false;
  }
}

function sanitizeFilenameBase(input: string, fallback: string): string {
  const cleaned = input
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .replace(/[<>:"/\\|?*]/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^[.\s]+|[.\s]+$/g, '')
    .slice(0, 120)
    .trim();

  return cleaned || fallback;
}

function buildContentDisposition(filename: string): string {
  const asciiSafe = filename
    .replace(/[^\x20-\x7e]/g, '_')
    .replace(/["\\;]/g, '_')
    .trim();
  const utf8Encoded = encodeURIComponent(filename)
    .replace(/['()*!]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  return `attachment; filename="${asciiSafe || 'download'}"; filename*=UTF-8''${utf8Encoded}`;
}

function pruneExpiredCaches(): void {
  const now = Date.now();
  for (const [key, entry] of analysisCache.entries()) {
    if (now - entry.createdAt > ANALYSIS_TTL_MS) {
      analysisCache.delete(key);
    }
  }
  while (analysisCache.size > MAX_CACHE_ENTRIES) {
    const oldestKey = analysisCache.keys().next().value;
    if (!oldestKey) break;
    analysisCache.delete(oldestKey);
  }

  for (const [id, entry] of preparedDownloads.entries()) {
    if (now - entry.createdAt > PREPARED_FILE_TTL_MS) {
      if (entry.filePath) {
        fs.promises.unlink(entry.filePath).catch(() => {});
      }
      preparedDownloads.delete(id);
    }
  }
}

setInterval(pruneExpiredCaches, 60 * 1000).unref();

interface RawAdaptiveFormat {
  itag?: number;
  url?: string;
  mime_type?: string;
  quality_label?: string;
  fps?: number;
  bitrate?: number;
  content_length?: number | string;
}

function parseQualityHeight(label: string | undefined): number {
  if (!label) return 0;
  const match = label.match(/(\d{3,4})p/i);
  return match ? Number(match[1]) : 0;
}

function getResolutionBadgeText(height: number): string {
  if (height >= 2160) return '4K Ultra HD';
  if (height >= 1440) return '2K QHD';
  if (height >= 1080) return 'Full HD';
  if (height >= 720) return 'HD';
  if (height >= 480) return 'SD';
  return 'Low';
}

function parseMimeCodec(mimeType: string | undefined): { container: 'mp4' | 'webm' | 'm4a'; codec: string } {
  const raw = mimeType || '';
  const isWebm = raw.includes('webm');
  const codecMatch = raw.match(/codecs="([^"]+)"/i);
  const codecRaw = codecMatch ? codecMatch[1] : '';

  let friendlyCodec = codecRaw;
  if (codecRaw.startsWith('avc1')) friendlyCodec = 'H.264';
  else if (codecRaw.startsWith('av01')) friendlyCodec = 'AV1';
  else if (codecRaw.startsWith('vp09') || codecRaw.startsWith('vp9')) friendlyCodec = 'VP9';
  else if (codecRaw.startsWith('mp4a')) friendlyCodec = 'AAC';
  else if (codecRaw.includes('opus')) friendlyCodec = 'Opus';

  if (raw.startsWith('audio/mp4')) {
    return { container: 'm4a', codec: friendlyCodec || 'AAC' };
  }
  return {
    container: isWebm ? 'webm' : 'mp4',
    codec: friendlyCodec || (isWebm ? 'VP9' : 'H.264'),
  };
}

function toByteNumber(value: number | string | undefined): number | null {
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (Number.isFinite(parsed) && parsed > 0) return parsed;
  }
  return null;
}

function codecPriority(mimeType: string | undefined): number {
  const raw = mimeType || '';
  if (raw.includes('avc1')) return 3;
  if (raw.includes('av01')) return 2;
  if (raw.includes('vp09') || raw.includes('vp9')) return 1;
  return 0;
}

async function fetchYouTubeOEmbed(videoId: string): Promise<{ title?: string; author?: string }> {
  try {
    const res = await fetch(
      `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
    );
    if (!res.ok) return {};
    const data = (await res.json()) as { title?: string; author_name?: string };
    return {
      title: data.title?.trim(),
      author: data.author_name?.trim(),
    };
  } catch {
    return {};
  }
}

async function analyzeWithYouTubeInnertube(videoId: string, sourceUrl: string): Promise<CachedAnalysis> {
  const yt = await getInnertube();

  const [iosRes, androidRes] = await Promise.allSettled([
    yt.getBasicInfo(videoId, { client: 'IOS' }),
    yt.getBasicInfo(videoId, { client: 'ANDROID' }),
  ]);

  const iosInfo = iosRes.status === 'fulfilled' ? iosRes.value : null;
  const androidInfo = androidRes.status === 'fulfilled' ? androidRes.value : null;
  const primaryInfo = iosInfo || androidInfo;

  if (!primaryInfo) {
    throw new Error('Could not retrieve video metadata from YouTube.');
  }

  const playability = primaryInfo.playability_status;
  if (playability && playability.status && playability.status !== 'OK') {
    throw new Error(playability.reason || `Video unavailable (${playability.status}).`);
  }

  let title = primaryInfo.basic_info?.title?.trim() || '';
  let author = primaryInfo.basic_info?.author?.trim() || 'YouTube Creator';
  const durationSeconds = Number(primaryInfo.basic_info?.duration || 0);
  const viewCount =
    typeof primaryInfo.basic_info?.view_count === 'number' ? primaryInfo.basic_info.view_count : null;

  const thumbs = primaryInfo.basic_info?.thumbnail;
  let thumbnailUrl = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
  if (Array.isArray(thumbs) && thumbs.length > 0) {
    const sorted = [...thumbs].sort((a, b) => (b.width || 0) - (a.width || 0));
    if (sorted[0]?.url && sorted[0].url.startsWith('https://')) {
      thumbnailUrl = sorted[0].url;
    }
  }

  if (!title) {
    const oembed = await fetchYouTubeOEmbed(videoId);
    if (oembed.title) title = oembed.title;
    if (oembed.author) author = oembed.author;
  }

  if (!title) {
    title = `YouTube Video ${videoId}`;
  }

  const sanitizedTitle = sanitizeFilenameBase(title, `youtube_${videoId}`);
  const formatsById = new Map<string, ServerFormatSpec>();
  const options: DownloadOption[] = [];

  const iosAdaptive = (iosInfo?.streaming_data?.adaptive_formats || []) as unknown as RawAdaptiveFormat[];
  const androidMuxed = (androidInfo?.streaming_data?.formats || []) as unknown as RawAdaptiveFormat[];

  const m4aAudioTracks = iosAdaptive
    .filter((f) => f.mime_type?.startsWith('audio/mp4') && f.url && isTrustedPublicDownloadUrl(f.url))
    .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));

  const bestAudio = m4aAudioTracks[0] || null;
  const bestAudioBytes = toByteNumber(bestAudio?.content_length);

  // 1. Direct muxed MP4 streams (>= 480p only)
  const muxedKeys = new Set<string>();
  for (const fmt of androidMuxed) {
    if (!fmt.url || !isTrustedPublicDownloadUrl(fmt.url)) continue;
    const height = parseQualityHeight(fmt.quality_label);
    if (!height || height < 480) continue;
    const qualityLabel = fmt.quality_label || `${height}p`;
    const id = `muxed-${fmt.itag || qualityLabel}`;
    if (muxedKeys.has(qualityLabel)) continue;
    muxedKeys.add(qualityLabel);

    const { codec } = parseMimeCodec(fmt.mime_type);
    const videoBytes = toByteNumber(fmt.content_length);
    const option: DownloadOption = {
      id,
      category: 'video-audio',
      qualityLabel,
      resolutionNote: `${getResolutionBadgeText(height)} · Instant direct`,
      container: 'mp4',
      codecSummary: `${codec} + AAC`,
      fps: fmt.fps,
      estimatedBytes: videoBytes,
      hasAudio: true,
      hasVideo: true,
      mode: 'direct',
    };
    options.push(option);
    formatsById.set(id, { option, videoUrl: fmt.url, videoBytes });
  }

  // 2. Adaptive MP4 streams (>= 480p) losslessly muxed with best M4A audio (zero quality drop)
  const videoStreams = iosAdaptive.filter(
    (f) => f.mime_type?.startsWith('video/') && f.url && isTrustedPublicDownloadUrl(f.url)
  );

  const bestByHeight = new Map<number, RawAdaptiveFormat>();
  for (const v of videoStreams) {
    const height = parseQualityHeight(v.quality_label);
    if (!height || height < 480) continue;
    if (!v.mime_type?.includes('video/mp4')) continue;

    const existing = bestByHeight.get(height);
    if (!existing) {
      bestByHeight.set(height, v);
      continue;
    }

    const existingScore = codecPriority(existing.mime_type) * 1000 + (existing.fps || 30);
    const candidateScore = codecPriority(v.mime_type) * 1000 + (v.fps || 30);
    if (candidateScore > existingScore || (candidateScore === existingScore && (v.bitrate || 0) > (existing.bitrate || 0))) {
      bestByHeight.set(height, v);
    }
  }

  const sortedHeights = [...bestByHeight.keys()].sort((a, b) => b - a);
  if (bestAudio?.url) {
    for (const height of sortedHeights) {
      const v = bestByHeight.get(height)!;
      const qualityLabel = v.quality_label || `${height}p`;
      if (muxedKeys.has(qualityLabel)) continue;

      const { codec } = parseMimeCodec(v.mime_type);
      const videoBytes = toByteNumber(v.content_length);
      const combinedBytes =
        videoBytes !== null && bestAudioBytes !== null ? videoBytes + bestAudioBytes : videoBytes;
      const id = `merge-${v.itag || height}`;
      const recommended = height === 1080 || (height === 720 && !bestByHeight.has(1080));

      const option: DownloadOption = {
        id,
        category: 'video-audio',
        qualityLabel,
        resolutionNote: `${getResolutionBadgeText(height)} · Lossless mux`,
        container: 'mp4',
        codecSummary: `${codec} + AAC`,
        fps: v.fps,
        estimatedBytes: combinedBytes,
        hasAudio: true,
        hasVideo: true,
        mode: 'merge',
        recommended,
      };
      options.push(option);
      formatsById.set(id, {
        option,
        videoUrl: v.url,
        audioUrl: bestAudio.url,
        videoBytes,
        audioBytes: bestAudioBytes,
      });
    }
  }

  options.sort((a, b) => parseQualityHeight(b.qualityLabel) - parseQualityHeight(a.qualityLabel));

  // 3. Audio-only options
  if (bestAudio?.url) {
    const m4aId = `audio-m4a-${bestAudio.itag || 'best'}`;
    const m4aOption: DownloadOption = {
      id: m4aId,
      category: 'audio',
      qualityLabel: 'M4A Audio',
      resolutionNote: 'Original AAC stream',
      container: 'm4a',
      codecSummary: 'AAC · ~128 kbps',
      estimatedBytes: bestAudioBytes,
      hasAudio: true,
      hasVideo: false,
      mode: 'audio-direct',
      recommended: true,
    };
    options.push(m4aOption);
    formatsById.set(m4aId, { option: m4aOption, audioUrl: bestAudio.url, audioBytes: bestAudioBytes });

    const mp3Id = 'audio-mp3-192';
    const estimatedMp3Bytes = durationSeconds > 0 ? Math.round((durationSeconds * 192 * 1000) / 8) : null;
    const mp3Option: DownloadOption = {
      id: mp3Id,
      category: 'audio',
      qualityLabel: 'MP3 Audio',
      resolutionNote: 'Converted 192 kbps',
      container: 'mp3',
      codecSummary: 'MP3 · 192 kbps',
      estimatedBytes: estimatedMp3Bytes,
      hasAudio: true,
      hasVideo: false,
      mode: 'audio-mp3',
    };
    options.push(mp3Option);
    formatsById.set(mp3Id, { option: mp3Option, audioUrl: bestAudio.url, audioBytes: bestAudioBytes });
  }

  if (options.length === 0) {
    throw new Error('No MP4 streams (480p or higher) were returned for this video.');
  }

  const token = crypto.randomUUID();
  const result: VideoAnalysisResult = {
    token,
    videoId,
    sourceUrl,
    title,
    sanitizedTitle,
    author,
    durationSeconds,
    viewCount,
    thumbnailUrl,
    extractor: 'YouTube Innertube API',
    options,
    analyzedAt: new Date().toISOString(),
  };

  const cached: CachedAnalysis = {
    result,
    formatsById,
    createdAt: Date.now(),
  };

  pruneExpiredCaches();
  analysisCache.set(token, cached);
  return cached;
}

/* -------------------------------------------------------------------------- */
/*  SaveFrom.net (en1.savefrom.net / worker.savefrom.net) API Integration     */
/* -------------------------------------------------------------------------- */

async function getSaveFromSigner(): Promise<(url: string) => Promise<Record<string, unknown>>> {
  const now = Date.now();
  if (cachedSaveFromSigner && now - cachedSaveFromSigner.loadedAt < 30 * 60 * 1000) {
    return cachedSaveFromSigner.sign;
  }

  const pageRes = await fetch('https://en1.savefrom.net/', {
    headers: { 'User-Agent': BROWSER_UA },
  });
  if (!pageRes.ok) {
    throw new Error(`SaveFrom homepage returned HTTP ${pageRes.status}.`);
  }
  const html = await pageRes.text();
  const runtimeMatch = html.match(/src="(\/build\/js\/runtime\.js[^"]+)"/);
  const vendorMatch = html.match(/src="(\/build\/js\/vendor\.js[^"]+)"/);

  let builderUrl = 'https://en1.savefrom.net/build/js/workerRequestBuilder.js?h=355900a2.js';
  if (runtimeMatch) {
    const rtCode = await (
      await fetch(`https://en1.savefrom.net${runtimeMatch[1]}`, { headers: { 'User-Agent': BROWSER_UA } })
    ).text();
    const hashMatch = rtCode.match(/5229:"([a-f0-9]+)"/);
    if (hashMatch) {
      builderUrl = `https://en1.savefrom.net/build/js/workerRequestBuilder.js?h=${hashMatch[1]}.js`;
    }
  }

  const vendorUrl = vendorMatch
    ? `https://en1.savefrom.net${vendorMatch[1]}`
    : 'https://en1.savefrom.net/build/js/vendor.js?h=5d98a027.js';

  const [vendorCode, builderCode] = await Promise.all([
    fetch(vendorUrl, { headers: { 'User-Agent': BROWSER_UA } }).then((r) => r.text()),
    fetch(builderUrl, { headers: { 'User-Agent': BROWSER_UA } }).then((r) => r.text()),
  ]);

  const patchedBuilder = builderCode.replace(
    'for(let E in c[L][s])',
    'if(c[L]&&c[L][s])for(let E in c[L][s])'
  );

  const modMap: Record<string | number, (m: { exports: Record<string, unknown> }, e: Record<string, unknown>, r: unknown) => void> = {};
  const loc = {
    href: 'https://en1.savefrom.net/',
    hostname: 'en1.savefrom.net',
    host: 'en1.savefrom.net',
    origin: 'https://en1.savefrom.net',
    protocol: 'https:',
    pathname: '/',
  };

  const sandboxFetch = (u: string, opts: RequestInit = {}) => {
    const resolved = typeof u === 'string' && u.startsWith('/') ? `https://en1.savefrom.net${u}` : u;
    return fetch(resolved, {
      ...opts,
      headers: {
        ...((opts.headers as Record<string, string>) || {}),
        'User-Agent': BROWSER_UA,
        Referer: 'https://en1.savefrom.net/',
      },
    });
  };

  const sandbox: Record<string, unknown> = {
    self: null,
    window: null,
    navigator: { userAgent: BROWSER_UA },
    location: loc,
    document: { domain: 'en1.savefrom.net', location: loc, URL: 'https://en1.savefrom.net/' },
    crypto: globalThis.crypto,
    TextEncoder,
    TextDecoder,
    URL,
    URLSearchParams,
    AbortController,
    Uint8Array,
    ArrayBuffer,
    DataView,
    atob,
    btoa,
    fetch: sandboxFetch,
    console,
    setTimeout,
    clearTimeout,
  };
  sandbox.self = sandbox;
  sandbox.window = sandbox;
  sandbox.webpackChunksavefrom_net = {
    push: (chunk: [unknown, Record<string | number, never>]) => {
      Object.assign(modMap, chunk[1]);
    },
  };

  vm.runInNewContext(vendorCode, sandbox);
  vm.runInNewContext(patchedBuilder, sandbox);

  const cache: Record<string | number, { exports: Record<string, unknown> }> = {};
  type ReqFn = ((id: string | number) => Record<string, unknown>) & {
    o: (o: object, p: PropertyKey) => boolean;
    d: (e: object, d: Record<string, () => unknown>) => void;
    r: (e: object) => void;
    n: (m: { __esModule?: boolean; default?: unknown }) => () => unknown;
    g: unknown;
  };

  const req = ((id: string | number) => {
    if (cache[id]) return cache[id].exports;
    const fn = modMap[id];
    if (!fn) return {};
    const m = (cache[id] = { exports: {} });
    fn(m, m.exports, req);
    return m.exports;
  }) as ReqFn;

  req.o = (o, p) => Object.prototype.hasOwnProperty.call(o, p);
  req.d = (e, d) => {
    for (const k of Object.keys(d)) {
      if (req.o(d, k) && !req.o(e, k)) {
        Object.defineProperty(e, k, { enumerable: true, get: d[k] });
      }
    }
  };
  req.r = (e) => {
    Object.defineProperty(e, '__esModule', { value: true });
  };
  req.n = (m) => {
    const getter = m && m.__esModule ? () => m.default : () => m;
    req.d(getter, { a: getter });
    return getter;
  };
  req.g = sandbox;

  const mod3245 = req(3245);
  const signPromise = mod3245.default as Promise<(url: string) => Promise<Record<string, unknown>>>;
  const signFn = await signPromise;
  if (typeof signFn !== 'function') {
    throw new Error('Could not initialize SaveFrom request signer.');
  }

  cachedSaveFromSigner = { sign: signFn, loadedAt: now };
  return signFn;
}

async function fetchSaveFromCaptcha(pendingUrl: string, message: string): Promise<CaptchaChallengeResponse> {
  const capRes = await fetch('https://worker.savefrom.net/api/captcha?sf-nomad=1', {
    headers: {
      'User-Agent': BROWSER_UA,
      Origin: 'https://en1.savefrom.net',
      Referer: 'https://en1.savefrom.net/',
    },
  });
  if (!capRes.ok) {
    throw new Error(`SaveFrom captcha endpoint returned HTTP ${capRes.status}.`);
  }
  const capJson = (await capRes.json()) as { captcha?: string; hash?: string };
  if (!capJson.captcha || !capJson.hash) {
    throw new Error('SaveFrom returned an incomplete captcha challenge.');
  }

  const imgUrl = `https://worker.savefrom.net/captcha?${new URLSearchParams({
    captcha: capJson.captcha,
    'sf-nomad': '1',
  }).toString()}`;
  const imgRes = await fetch(imgUrl, {
    headers: {
      'User-Agent': BROWSER_UA,
      Referer: 'https://en1.savefrom.net/',
    },
  });
  if (!imgRes.ok) {
    throw new Error(`Could not fetch SaveFrom captcha image (HTTP ${imgRes.status}).`);
  }
  const contentType = imgRes.headers.get('content-type') || 'image/png';
  const safeType = /^image\/(png|jpeg|gif|webp)/i.test(contentType) ? contentType.split(';')[0] : 'image/png';
  const buf = Buffer.from(await imgRes.arrayBuffer());
  const captchaImageDataUrl = `data:${safeType};base64,${buf.toString('base64')}`;

  return {
    captchaRequired: true,
    captchaImageDataUrl,
    captchaHash: capJson.hash,
    pendingUrl,
    message,
  };
}

interface SaveFromUrlItem {
  url?: string;
  ext?: string;
  type?: string;
  name?: string;
  subname?: string;
  quality?: string | number;
  filesize?: number;
  no_audio?: boolean;
  audio?: boolean;
  attr?: { class?: string; title?: string };
}

interface SaveFromShowPayload {
  id?: string;
  hosting?: string;
  thumb?: string;
  meta?: {
    title?: string;
    duration?: string;
    source?: string;
  };
  url?: SaveFromUrlItem[];
}

function parseSaveFromDuration(dur: string | undefined): number {
  if (!dur) return 0;
  const parts = dur.split(':').map(Number);
  if (parts.some((n) => Number.isNaN(n))) return 0;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return parts[0] || 0;
}

function parseSaveFromJsResponse(jsText: string): SaveFromShowPayload | null {
  const markers = ['videoResult.show(', 'audioResult.show('];
  for (const marker of markers) {
    const idx = jsText.indexOf(marker);
    if (idx === -1) continue;
    const start = jsText.indexOf('{', idx + marker.length);
    if (start === -1) continue;
    let depth = 0;
    let inString = false;
    let escape = false;
    let quoteChar = '';
    for (let i = start; i < jsText.length; i++) {
      const ch = jsText[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (inString) {
        if (ch === '\\') escape = true;
        else if (ch === quoteChar) inString = false;
        continue;
      }
      if (ch === '"' || ch === "'") {
        inString = true;
        quoteChar = ch;
      } else if (ch === '{') {
        depth++;
      } else if (ch === '}') {
        depth--;
        if (depth === 0) {
          const jsonSlice = jsText.slice(start, i + 1);
          try {
            return JSON.parse(jsonSlice) as SaveFromShowPayload;
          } catch {
            return null;
          }
        }
      }
    }
  }
  return null;
}

async function analyzeWithSaveFrom(
  targetUrl: string,
  videoIdHint: string | null
): Promise<CachedAnalysis | CaptchaChallengeResponse> {
  const sign = await getSaveFromSigner();
  const signedFields = await sign(targetUrl);

  const formParams = new URLSearchParams();
  formParams.set('sf_url', targetUrl);
  formParams.set('sf_submit', '');
  formParams.set('new', '2');
  formParams.set('lang', 'en');
  formParams.set('app', '');
  formParams.set('sf-nomad', '1');
  for (const [k, v] of Object.entries(signedFields)) {
    if (v !== undefined && v !== null) {
      formParams.set(k, String(v));
    }
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/x-www-form-urlencoded',
    'User-Agent': BROWSER_UA,
    Origin: 'https://en1.savefrom.net',
    Referer: 'https://en1.savefrom.net/',
  };
  if (saveFromWorkerToken) {
    headers['x-token'] = saveFromWorkerToken;
  }

  const res = await fetch('https://worker.savefrom.net/savefrom.php', {
    method: 'POST',
    headers,
    body: formParams.toString(),
  });

  const bodyText = await res.text();
  if (res.status === 422 || bodyText.includes('Captcha required')) {
    saveFromWorkerToken = null;
    return fetchSaveFromCaptcha(
      targetUrl,
      'SaveFrom.net requires a quick captcha verification before returning download links.'
    );
  }

  const payload = parseSaveFromJsResponse(bodyText);
  if (!payload || !Array.isArray(payload.url) || payload.url.length === 0) {
    const errMatch = bodyText.match(/"html":"([^"]+)"/);
    const cleanErr = errMatch ? errMatch[1].replace(/<[^>]+>/g, '') : 'SaveFrom did not return downloadable formats for this link.';
    throw new Error(cleanErr);
  }

  const resolvedId = payload.id || videoIdHint || crypto.createHash('sha256').update(targetUrl).digest('hex').slice(0, 11);
  let title = payload.meta?.title?.trim() || '';
  let author = payload.hosting || 'Video';

  if (!title && videoIdHint) {
    const oembed = await fetchYouTubeOEmbed(videoIdHint);
    if (oembed.title) title = oembed.title;
    if (oembed.author) author = oembed.author;
  } else if (videoIdHint) {
    const oembed = await fetchYouTubeOEmbed(videoIdHint);
    if (oembed.author) author = oembed.author;
  }

  if (!title) {
    title = `Video ${resolvedId}`;
  }

  const sanitizedTitle = sanitizeFilenameBase(title, `video_${resolvedId}`);
  const durationSeconds = parseSaveFromDuration(payload.meta?.duration);
  const thumbnailUrl =
    payload.thumb && payload.thumb.startsWith('https://')
      ? payload.thumb
      : videoIdHint
        ? `https://i.ytimg.com/vi/${videoIdHint}/hqdefault.jpg`
        : '';

  const formatsById = new Map<string, ServerFormatSpec>();
  const options: DownloadOption[] = [];

  const sfAudioCandidate = payload.url.find((item) => {
    if (!item.url || !isTrustedPublicDownloadUrl(item.url)) return false;
    const rawExt = (item.ext || item.type || '').toLowerCase();
    return rawExt === 'm4a' || item.audio === true;
  });

  payload.url.forEach((item, index) => {
    if (!item.url || !isTrustedPublicDownloadUrl(item.url)) return;
    const rawExt = (item.ext || item.type || 'mp4').toLowerCase();
    const container: 'mp4' | 'm4a' | 'mp3' | 'webm' =
      rawExt === 'm4a' || rawExt === 'mp3' || rawExt === 'webm' ? rawExt : 'mp4';

    const noAudio =
      item.no_audio === true ||
      item.attr?.class === 'no-audio' ||
      String(item.subname || '').toLowerCase().includes('no audio');
    const isAudioOnly = container === 'm4a' || container === 'mp3' || item.audio === true;

    const qualityStr = String(item.subname || item.quality || item.name || (isAudioOnly ? 'Audio' : 'Standard')).trim();
    const qualityLabel = /^\d{3,4}$/.test(qualityStr) ? `${qualityStr}p` : qualityStr;
    const height = parseQualityHeight(qualityLabel);

    if (!isAudioOnly) {
      if (container !== 'mp4') return;
      if (height > 0 && height < 480) return;
      if (noAudio && !sfAudioCandidate?.url) return;
    }

    const canMergeAudio = !isAudioOnly && noAudio && Boolean(sfAudioCandidate?.url);
    const id = `sf-${index}-${container}-${qualityLabel.replace(/[^a-z0-9]/gi, '')}`;
    const sizeBytes = typeof item.filesize === 'number' && item.filesize > 0 ? item.filesize : null;

    const option: DownloadOption = {
      id,
      category: isAudioOnly ? 'audio' : 'video-audio',
      qualityLabel,
      resolutionNote: isAudioOnly
        ? 'SaveFrom Audio Stream'
        : `${getResolutionBadgeText(height)}${canMergeAudio ? ' · Lossless mux' : ''}`,
      container,
      codecSummary: isAudioOnly ? container.toUpperCase() : 'MP4 · Video + Audio',
      estimatedBytes: sizeBytes,
      hasAudio: true,
      hasVideo: !isAudioOnly,
      mode: isAudioOnly ? 'audio-direct' : canMergeAudio ? 'merge' : 'direct',
      recommended: !isAudioOnly && (height === 1080 || height === 720),
    };

    options.push(option);
    formatsById.set(id, {
      option,
      videoUrl: isAudioOnly ? undefined : item.url,
      audioUrl: isAudioOnly ? item.url : canMergeAudio ? sfAudioCandidate?.url : undefined,
      videoBytes: isAudioOnly ? null : sizeBytes,
      audioBytes: isAudioOnly ? sizeBytes : null,
    });
  });

  if (options.length === 0) {
    throw new Error('SaveFrom returned no MP4 streams (480p or higher).');
  }

  const token = crypto.randomUUID();
  const result: VideoAnalysisResult = {
    token,
    videoId: resolvedId,
    sourceUrl: targetUrl,
    title,
    sanitizedTitle,
    author,
    durationSeconds,
    viewCount: null,
    thumbnailUrl,
    extractor: 'SaveFrom.net Worker API (en1.savefrom.net)',
    options,
    analyzedAt: new Date().toISOString(),
  };

  const cached: CachedAnalysis = {
    result,
    formatsById,
    createdAt: Date.now(),
  };
  pruneExpiredCaches();
  analysisCache.set(token, cached);
  return cached;
}

/* -------------------------------------------------------------------------- */
/*  Range-Chunked Downloader + Local FFmpeg Muxing                            */
/* -------------------------------------------------------------------------- */

async function downloadUrlToTempFile(url: string, knownBytes: number | null, outPath: string): Promise<void> {
  if (!isTrustedPublicDownloadUrl(url)) {
    throw new Error('Blocked untrusted upstream download URL.');
  }

  let totalBytes = knownBytes && knownBytes > 0 ? knownBytes : null;
  if (!totalBytes) {
    try {
      const headRes = await fetch(url, {
        method: 'HEAD',
        headers: { 'User-Agent': BROWSER_UA },
      });
      const len = Number(headRes.headers.get('content-length') || 0);
      if (Number.isFinite(len) && len > 0) totalBytes = len;
    } catch {
      // Fall back to direct streaming if HEAD is rejected
    }
  }

  if (!totalBytes || totalBytes <= CHUNK_SIZE_BYTES) {
    const res = await fetch(url, { headers: { 'User-Agent': BROWSER_UA } });
    if (!res.ok || !res.body) {
      throw new Error(`Upstream stream returned HTTP ${res.status}.`);
    }
    await pipeline(Readable.fromWeb(res.body as never), fs.createWriteStream(outPath));
    return;
  }

  const ranges: Array<{ start: number; end: number }> = [];
  for (let start = 0; start < totalBytes; start += CHUNK_SIZE_BYTES) {
    const end = Math.min(start + CHUNK_SIZE_BYTES - 1, totalBytes - 1);
    ranges.push({ start, end });
  }

  const buffers = new Array<Buffer>(ranges.length);
  let cursor = 0;

  async function worker(): Promise<void> {
    while (cursor < ranges.length) {
      const idx = cursor++;
      const { start, end } = ranges[idx];
      const res = await fetch(url, {
        headers: {
          'User-Agent': BROWSER_UA,
          Range: `bytes=${start}-${end}`,
        },
      });
      if (!res.ok && res.status !== 206) {
        throw new Error(`Chunk ${idx} failed with HTTP ${res.status}.`);
      }
      buffers[idx] = Buffer.from(await res.arrayBuffer());
    }
  }

  const workers = Array.from({ length: Math.min(CHUNK_CONCURRENCY, ranges.length) }, () => worker());
  await Promise.all(workers);

  const ws = fs.createWriteStream(outPath);
  for (const buf of buffers) {
    if (!ws.write(buf)) {
      await new Promise<void>((resolve) => ws.once('drain', resolve));
    }
  }
  await new Promise<void>((resolve, reject) => {
    ws.on('finish', resolve);
    ws.on('error', reject);
    ws.end();
  });
}

async function prepareDownloadFile(
  spec: ServerFormatSpec,
  customTitleInput: string | undefined,
  defaultSanitizedTitle: string
): Promise<PrepareDownloadResponse> {
  const baseName = customTitleInput
    ? sanitizeFilenameBase(customTitleInput, defaultSanitizedTitle)
    : defaultSanitizedTitle;
  const ext = spec.option.container;
  const filename = `${baseName}.${ext}`;

  const mimeMap: Record<string, string> = {
    mp4: 'video/mp4',
    m4a: 'audio/mp4',
    mp3: 'audio/mpeg',
    webm: 'video/webm',
  };
  const mimeType = mimeMap[ext] || 'application/octet-stream';
  const downloadId = crypto.randomUUID();

  if (spec.option.mode === 'direct' || spec.option.mode === 'audio-direct') {
    const upstreamUrl = spec.option.mode === 'audio-direct' ? spec.audioUrl : spec.videoUrl;
    if (!upstreamUrl || !isTrustedPublicDownloadUrl(upstreamUrl)) {
      throw new Error('Upstream media stream URL is missing or invalid.');
    }
    preparedDownloads.set(downloadId, {
      kind: 'direct-proxy',
      upstreamUrl,
      filename,
      mimeType,
      sizeBytes: spec.option.estimatedBytes,
      createdAt: Date.now(),
    });
    return {
      downloadId,
      downloadUrl: `/api/file/${downloadId}`,
      filename,
      sizeBytes: spec.option.estimatedBytes,
    };
  }

  const tmpBase = path.resolve(os.tmpdir());
  const tmpVideoPath = path.resolve(tmpBase, `mediapull-v-${downloadId}.mp4`);
  const tmpAudioPath = path.resolve(tmpBase, `mediapull-a-${downloadId}.m4a`);
  const outPath = path.resolve(tmpBase, `mediapull-out-${downloadId}.${ext}`);

  if (
    !tmpVideoPath.startsWith(tmpBase + path.sep) ||
    !tmpAudioPath.startsWith(tmpBase + path.sep) ||
    !outPath.startsWith(tmpBase + path.sep)
  ) {
    throw new Error('Invalid temporary file path.');
  }

  try {
    if (spec.option.mode === 'merge') {
      if (
        !spec.videoUrl ||
        !spec.audioUrl ||
        !isTrustedPublicDownloadUrl(spec.videoUrl) ||
        !isTrustedPublicDownloadUrl(spec.audioUrl)
      ) {
        throw new Error('Video or audio stream URL is unavailable for merging.');
      }

      await Promise.all([
        downloadUrlToTempFile(spec.videoUrl, spec.videoBytes ?? null, tmpVideoPath),
        downloadUrlToTempFile(spec.audioUrl, spec.audioBytes ?? null, tmpAudioPath),
      ]);

      await execFileAsync(
        FFMPEG_PATH,
        [
          '-y',
          '-loglevel',
          'error',
          '-i',
          tmpVideoPath,
          '-i',
          tmpAudioPath,
          '-c:v',
          'copy',
          '-c:a',
          'copy',
          '-movflags',
          '+faststart',
          '-f',
          'mp4',
          outPath,
        ],
        { shell: false, timeout: 120000, maxBuffer: 2 * 1024 * 1024 }
      );
    } else if (spec.option.mode === 'audio-mp3') {
      if (!spec.audioUrl || !isTrustedPublicDownloadUrl(spec.audioUrl)) {
        throw new Error('Audio stream URL is unavailable.');
      }

      await downloadUrlToTempFile(spec.audioUrl, spec.audioBytes ?? null, tmpAudioPath);

      await execFileAsync(
        FFMPEG_PATH,
        [
          '-y',
          '-loglevel',
          'error',
          '-i',
          tmpAudioPath,
          '-vn',
          '-c:a',
          'libmp3lame',
          '-b:a',
          '192k',
          '-f',
          'mp3',
          outPath,
        ],
        { shell: false, timeout: 120000, maxBuffer: 2 * 1024 * 1024 }
      );
    }

    const stat = await fs.promises.stat(outPath);
    preparedDownloads.set(downloadId, {
      kind: 'tempfile',
      filePath: outPath,
      filename,
      mimeType,
      sizeBytes: stat.size,
      createdAt: Date.now(),
    });

    return {
      downloadId,
      downloadUrl: `/api/file/${downloadId}`,
      filename,
      sizeBytes: stat.size,
    };
  } catch (err) {
    fs.promises.unlink(outPath).catch(() => {});
    throw err;
  } finally {
    fs.promises.unlink(tmpVideoPath).catch(() => {});
    fs.promises.unlink(tmpAudioPath).catch(() => {});
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.post('/api/analyze', async (req: Request, res: Response) => {
    try {
      const rawUrl = typeof req.body?.url === 'string' ? req.body.url : '';
      const sourcePref: ExtractorSource = req.body?.source === 'savefrom' ? 'savefrom' : 'auto';
      const parsedUrl = normalizeAndValidateInputUrl(rawUrl);
      if (!parsedUrl) {
        res.status(400).json({ error: 'Please enter a valid public video URL.' });
        return;
      }

      const videoId = extractYouTubeVideoId(rawUrl);
      const canonicalUrl = videoId ? `https://www.youtube.com/watch?v=${videoId}` : parsedUrl.toString();

      if (sourcePref === 'savefrom' || !videoId) {
        const sfOutcome = await analyzeWithSaveFrom(canonicalUrl, videoId);
        if ('captchaRequired' in sfOutcome) {
          res.status(200).json(sfOutcome);
          return;
        }
        res.json(sfOutcome.result);
        return;
      }

      try {
        const ytCached = await analyzeWithYouTubeInnertube(videoId, canonicalUrl);
        res.json(ytCached.result);
        return;
      } catch (ytErr) {
        // Automatic fallback to SaveFrom.net API if YouTube blocks datacenter IP
        try {
          const sfOutcome = await analyzeWithSaveFrom(canonicalUrl, videoId);
          if ('captchaRequired' in sfOutcome) {
            res.status(200).json(sfOutcome);
            return;
          }
          res.json(sfOutcome.result);
          return;
        } catch {
          throw ytErr;
        }
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to analyze video link.';
      res.status(502).json({ error: message });
    }
  });

  app.post('/api/savefrom/captcha', async (req: Request, res: Response) => {
    try {
      const value = typeof req.body?.value === 'string' ? req.body.value.trim() : '';
      const hash = typeof req.body?.hash === 'string' ? req.body.hash.trim() : '';
      const rawUrl = typeof req.body?.url === 'string' ? req.body.url.trim() : '';

      if (!value || !hash || !rawUrl) {
        res.status(400).json({ error: 'Missing captcha value, hash, or video URL.' });
        return;
      }

      const parsedUrl = normalizeAndValidateInputUrl(rawUrl);
      if (!parsedUrl) {
        res.status(400).json({ error: 'Invalid video URL.' });
        return;
      }

      const verifyParams = new URLSearchParams({
        value,
        hash,
        'sf-nomad': '1',
      });
      const verifyRes = await fetch('https://worker.savefrom.net/api/captcha', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': BROWSER_UA,
          Origin: 'https://en1.savefrom.net',
          Referer: 'https://en1.savefrom.net/',
        },
        body: verifyParams.toString(),
      });

      const verifyJson = (await verifyRes.json()) as { result?: string };
      if (!verifyRes.ok || !verifyJson.result) {
        const fresh = await fetchSaveFromCaptcha(
          parsedUrl.toString(),
          'Captcha verification did not match. Please try the new code.'
        );
        res.status(200).json(fresh);
        return;
      }

      saveFromWorkerToken = verifyJson.result;
      const videoId = extractYouTubeVideoId(rawUrl);
      const sfOutcome = await analyzeWithSaveFrom(parsedUrl.toString(), videoId);
      if ('captchaRequired' in sfOutcome) {
        res.status(200).json(sfOutcome);
        return;
      }
      res.json(sfOutcome.result);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Captcha verification failed.';
      res.status(502).json({ error: message });
    }
  });

  app.post('/api/prepare', async (req: Request, res: Response) => {
    try {
      const token = typeof req.body?.token === 'string' ? req.body.token : '';
      const optionId = typeof req.body?.optionId === 'string' ? req.body.optionId : '';
      const customFilename = typeof req.body?.filename === 'string' ? req.body.filename : undefined;

      if (!token || !optionId) {
        res.status(400).json({ error: 'Missing token or optionId.' });
        return;
      }

      const cached = analysisCache.get(token);
      if (!cached || Date.now() - cached.createdAt > ANALYSIS_TTL_MS) {
        if (cached) analysisCache.delete(token);
        res.status(410).json({ error: 'Session expired. Please analyze the video link again.' });
        return;
      }

      const spec = cached.formatsById.get(optionId);
      if (!spec) {
        res.status(404).json({ error: 'Requested quality option was not found.' });
        return;
      }

      const prepared = await prepareDownloadFile(spec, customFilename, cached.result.sanitizedTitle);
      res.json(prepared);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to prepare media download.';
      res.status(500).json({ error: message });
    }
  });

  app.get('/api/file/:downloadId', async (req: Request, res: Response) => {
    const rawId = req.params.downloadId;
    const downloadId = Array.isArray(rawId) ? rawId[0] : rawId;
    if (!downloadId || !/^[a-f0-9-]{36}$/i.test(downloadId)) {
      res.status(400).json({ error: 'Invalid download identifier.' });
      return;
    }

    const entry = preparedDownloads.get(downloadId);
    if (!entry) {
      res.status(404).json({ error: 'Download link expired or already consumed.' });
      return;
    }

    res.setHeader('Content-Type', entry.mimeType);
    res.setHeader('Content-Disposition', buildContentDisposition(entry.filename));
    res.setHeader('Cache-Control', 'no-store');

    if (entry.kind === 'tempfile' && entry.filePath) {
      const tmpBase = path.resolve(os.tmpdir());
      const resolved = path.resolve(entry.filePath);
      if (!resolved.startsWith(tmpBase + path.sep) || !fs.existsSync(resolved)) {
        preparedDownloads.delete(downloadId);
        res.status(404).json({ error: 'Prepared file no longer exists.' });
        return;
      }

      if (entry.sizeBytes) {
        res.setHeader('Content-Length', String(entry.sizeBytes));
      }

      if (req.method === 'HEAD') {
        res.status(200).end();
        return;
      }

      const stream = fs.createReadStream(resolved);
      const cleanup = () => {
        preparedDownloads.delete(downloadId);
        fs.promises.unlink(resolved).catch(() => {});
      };

      res.on('finish', cleanup);
      stream.on('error', () => {
        cleanup();
        if (!res.headersSent) {
          res.status(500).end();
        }
      });
      stream.pipe(res);
      return;
    }

    if (entry.kind === 'direct-proxy' && entry.upstreamUrl) {
      if (!isTrustedPublicDownloadUrl(entry.upstreamUrl)) {
        res.status(403).json({ error: 'Blocked upstream host.' });
        return;
      }

      const controller = new AbortController();
      req.on('close', () => controller.abort());

      try {
        let totalBytes = entry.sizeBytes && entry.sizeBytes > 0 ? entry.sizeBytes : null;
        if (!totalBytes) {
          const headRes = await fetch(entry.upstreamUrl, {
            method: 'HEAD',
            signal: controller.signal,
            headers: { 'User-Agent': BROWSER_UA },
          });
          const hLen = Number(headRes.headers.get('content-length') || 0);
          if (Number.isFinite(hLen) && hLen > 0) totalBytes = hLen;
        }

        if (totalBytes && totalBytes > CHUNK_SIZE_BYTES) {
          res.setHeader('Content-Length', String(totalBytes));
          for (let start = 0; start < totalBytes; start += CHUNK_SIZE_BYTES) {
            if (controller.signal.aborted) break;
            const end = Math.min(start + CHUNK_SIZE_BYTES - 1, totalBytes - 1);
            const chunkRes = await fetch(entry.upstreamUrl, {
              signal: controller.signal,
              headers: {
                'User-Agent': BROWSER_UA,
                Range: `bytes=${start}-${end}`,
              },
            });
            if (!chunkRes.ok && chunkRes.status !== 206) {
              throw new Error(`Upstream range stream returned HTTP ${chunkRes.status}.`);
            }
            const buf = Buffer.from(await chunkRes.arrayBuffer());
            if (!res.write(buf)) {
              await new Promise<void>((resolve) => res.once('drain', resolve));
            }
          }
          if (!controller.signal.aborted) res.end();
          return;
        }

        const upstream = await fetch(entry.upstreamUrl, {
          signal: controller.signal,
          headers: { 'User-Agent': BROWSER_UA },
        });
        if (!upstream.ok || !upstream.body) {
          res.status(502).json({ error: `Upstream stream returned HTTP ${upstream.status}.` });
          return;
        }
        const lenHeader = upstream.headers.get('content-length');
        if (lenHeader) res.setHeader('Content-Length', lenHeader);
        await pipeline(Readable.fromWeb(upstream.body as never), res);
      } catch (err) {
        if (!controller.signal.aborted && !res.headersSent) {
          const message = err instanceof Error ? err.message : 'Upstream streaming failed.';
          res.status(502).json({ error: message });
        }
      }
      return;
    }

    res.status(404).json({ error: 'Download target unavailable.' });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MediaPull server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
