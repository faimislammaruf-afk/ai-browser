package com.example

import com.example.data.WebAdFilter
import com.example.service.BackgroundPlaybackManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TubeFloatUnitTest {

    @Test
    fun `zero-latency web ad filter blocks ad hosts and paths while bypassing video CDNs and botguard`() {
        assertTrue(WebAdFilter.isAdRequest("https://googleads.g.doubleclick.net/pagead/id", "googleads.g.doubleclick.net"))
        assertTrue(WebAdFilter.isAdRequest("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js", "pagead2.googlesyndication.com"))
        assertTrue(WebAdFilter.isAdRequest("https://ads.youtube.com/api/stats/ads", "ads.youtube.com"))
        assertTrue(WebAdFilter.isAdRequest("https://m.youtube.com/api/stats/ads?v=123", "m.youtube.com"))
        assertTrue(WebAdFilter.isAdRequest("https://m.youtube.com/get_midroll_info?v=123", "m.youtube.com"))
        assertTrue(WebAdFilter.isAdRequest("https://m.youtube.com/youtubei/v1/player/ad_break", "m.youtube.com"))

        // Video chunks, thumbnails, playback tracking, BotGuard, and auth must stay allowed
        assertFalse(WebAdFilter.isAdRequest("https://rr1---sn-abcd.googlevideo.com/videoplayback?pagead=0", "rr1---sn-abcd.googlevideo.com"))
        assertFalse(WebAdFilter.isAdRequest("https://i.ytimg.com/vi/abc123/hqdefault.jpg", "i.ytimg.com"))
        assertFalse(WebAdFilter.isAdRequest("https://jnn-pa.googleapis.com/\$rpc/google.internal.waa.v1.Waa/GenerateIT", "jnn-pa.googleapis.com"))
        assertFalse(WebAdFilter.isAdRequest("https://m.youtube.com/ptracking?pltype=content", "m.youtube.com"))
        assertFalse(WebAdFilter.isAdRequest("https://m.youtube.com/watch?v=abc123", "m.youtube.com"))
    }

    @Test
    fun `background playback manager tracks playing state and metadata transitions`() {
        BackgroundPlaybackManager.userPausedFromNotification = true
        BackgroundPlaybackManager.updatePlaybackState(playing = true, title = "Sample Track", artist = "Creator")
        assertTrue(BackgroundPlaybackManager.isPlaying)
        assertFalse(BackgroundPlaybackManager.userPausedFromNotification)
        assertEquals("Sample Track", BackgroundPlaybackManager.currentTitle)
        assertEquals("Creator", BackgroundPlaybackManager.currentArtist)

        BackgroundPlaybackManager.setAppBackgroundState(true)
        assertTrue(BackgroundPlaybackManager.isAppInBackground)

        BackgroundPlaybackManager.updatePlaybackState(playing = false, title = "", artist = "")
        assertFalse(BackgroundPlaybackManager.isPlaying)
        assertEquals("Sample Track", BackgroundPlaybackManager.currentTitle)
        BackgroundPlaybackManager.setAppBackgroundState(false)
    }
}
