package com.example.data

object WebAdFilter {

    private val fastPassHosts = arrayOf(
        "googlevideo.com",
        "ytimg.com",
        "ggpht.com",
        "gstatic.com",
        "fonts.googleapis.com",
        "jnn-pa.googleapis.com",
        "accounts.google.com",
        "apis.google.com"
    )

    private val blockedHosts = arrayOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "ads.youtube.com",
        "imasdk.googleapis.com",
        "2mdn.net",
        "moatads.com",
        "adsystem.com"
    )

    private val blockedPathMarkers = arrayOf(
        "/pagead/",
        "/api/stats/ads",
        "/get_midroll_info",
        "/youtubei/v1/player/ad_break"
    )

    /**
     * Zero-latency in-memory URL filter for WebViewClient.shouldInterceptRequest.
     * Fast-passes video segments, BotGuard/auth, and CDN hosts with zero overhead.
     */
    fun isAdRequest(fullUrl: String?, host: String?): Boolean {
        val h = host?.lowercase().orEmpty()
        for (passHost in fastPassHosts) {
            if (h == passHost || h.endsWith(".$passHost")) {
                return false
            }
        }
        for (adHost in blockedHosts) {
            if (h == adHost || h.endsWith(".$adHost")) {
                return true
            }
        }
        val url = fullUrl?.lowercase().orEmpty()
        if (url.isEmpty()) return false
        for (marker in blockedPathMarkers) {
            if (url.contains(marker)) {
                return true
            }
        }
        return false
    }

    fun isJsonAdEndpoint(fullUrl: String?): Boolean {
        val url = fullUrl?.lowercase().orEmpty()
        return url.contains("/youtubei/v1/player/ad_break") || url.contains("/get_midroll_info")
    }
}
