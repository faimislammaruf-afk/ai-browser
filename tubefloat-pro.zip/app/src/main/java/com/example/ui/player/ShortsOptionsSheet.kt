package com.example.ui.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Subject
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.Feedback
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.OpenInFull
import androidx.compose.material.icons.outlined.RemoveCircleOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ShortsOptionsState(
    val title: String = "",
    val channel: String = "",
    val description: String = "",
    val captionsStatus: String = "Unavailable",
    val qualityLabel: String = "Auto",
    val playbackRate: Float = 1.0f,
    val isClearScreen: Boolean = false
)

enum class ShortsOptionAction {
    DESCRIPTION,
    CLEAR_SCREEN,
    CAPTIONS,
    QUALITY,
    NOT_INTERESTED,
    DONT_RECOMMEND_CHANNEL,
    REPORT,
    SEND_FEEDBACK
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShortsOptionsBottomSheet(
    state: ShortsOptionsState,
    onDismiss: () -> Unit,
    onAction: (ShortsOptionAction) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF212121),
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        modifier = Modifier.testTag("shorts_options_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp)
        ) {
            ShortsOptionRow(
                icon = Icons.AutoMirrored.Outlined.Subject,
                label = "Description",
                testTag = "shorts_opt_description",
                onClick = { onAction(ShortsOptionAction.DESCRIPTION) }
            )
            ShortsOptionRow(
                icon = Icons.Outlined.OpenInFull,
                label = if (state.isClearScreen) "Show Controls" else "Clear Screen",
                testTag = "shorts_opt_clear_screen",
                onClick = { onAction(ShortsOptionAction.CLEAR_SCREEN) }
            )
            ShortsOptionRow(
                icon = Icons.Outlined.ClosedCaption,
                label = "Captions",
                trailingText = state.captionsStatus,
                enabled = state.captionsStatus != "Unavailable",
                showChevron = true,
                testTag = "shorts_opt_captions",
                onClick = { onAction(ShortsOptionAction.CAPTIONS) }
            )
            ShortsOptionRow(
                icon = Icons.Outlined.Tune,
                label = "Quality",
                trailingText = if (state.playbackRate != 1.0f) {
                    "${state.qualityLabel} • ${state.playbackRate}x"
                } else {
                    state.qualityLabel
                },
                showChevron = true,
                testTag = "shorts_opt_quality",
                onClick = { onAction(ShortsOptionAction.QUALITY) }
            )
            ShortsOptionRow(
                icon = Icons.Outlined.Block,
                label = "Not interested",
                testTag = "shorts_opt_not_interested",
                onClick = { onAction(ShortsOptionAction.NOT_INTERESTED) }
            )
            ShortsOptionRow(
                icon = Icons.Outlined.RemoveCircleOutline,
                label = "Don't recommend this channel",
                testTag = "shorts_opt_dont_recommend",
                onClick = { onAction(ShortsOptionAction.DONT_RECOMMEND_CHANNEL) }
            )
            ShortsOptionRow(
                icon = Icons.Outlined.Flag,
                label = "Report",
                testTag = "shorts_opt_report",
                onClick = { onAction(ShortsOptionAction.REPORT) }
            )
            ShortsOptionRow(
                icon = Icons.Outlined.Feedback,
                label = "Send feedback",
                testTag = "shorts_opt_feedback",
                onClick = { onAction(ShortsOptionAction.SEND_FEEDBACK) }
            )
        }
    }
}

@Composable
private fun ShortsOptionRow(
    icon: ImageVector,
    label: String,
    trailingText: String? = null,
    enabled: Boolean = true,
    showChevron: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    val contentAlpha = if (enabled) 1f else 0.45f
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color.White.copy(alpha = contentAlpha),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(18.dp))
        Text(
            text = label,
            color = Color.White.copy(alpha = contentAlpha),
            fontSize = 16.sp,
            fontWeight = FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        if (!trailingText.isNullOrBlank()) {
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = trailingText,
                color = Color.White.copy(alpha = if (enabled) 0.65f else 0.45f),
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (showChevron) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Outlined.ChevronRight,
                contentDescription = null,
                tint = Color.White.copy(alpha = if (enabled) 0.65f else 0.45f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun ShortsDescriptionDialog(
    state: ShortsOptionsState,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF212121),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFE0E0E0),
        title = {
            Text(
                text = "Description",
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (state.title.isNotBlank()) {
                    Text(
                        text = state.title,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }
                if (state.channel.isNotBlank()) {
                    Text(
                        text = state.channel,
                        color = Color(0xFFAAAAAA),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
                Text(
                    text = state.description.ifBlank { "No additional description available for this Short." },
                    color = Color(0xFFCCCCCC),
                    fontSize = 14.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = MaterialTheme.colorScheme.primary)
            }
        }
    )
}

@Composable
fun ShortsQualityAndSpeedDialog(
    currentQuality: String,
    currentRate: Float,
    onDismiss: () -> Unit,
    onSelectSpeed: (Float) -> Unit
) {
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF212121),
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = {
            Text("Stream & Playback", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    color = Color(0xFF2C2C2C),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Active stream resolution", color = Color(0xFFAAAAAA), fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(currentQuality, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text("Playback speed", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                speeds.forEach { rate ->
                    val selected = rate == currentRate
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectSpeed(rate)
                                onDismiss()
                            }
                            .padding(vertical = 10.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (rate == 1.0f) "Normal (1.0x)" else "${rate}x",
                            color = if (selected) MaterialTheme.colorScheme.primary else Color.White,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 15.sp
                        )
                        if (selected) {
                            Text("Active", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = MaterialTheme.colorScheme.primary)
            }
        }
    )
}

@Composable
fun ShortsSearchDialog(
    onDismiss: () -> Unit,
    onSubmitQuery: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF212121),
        titleContentColor = Color.White,
        title = {
            Text("Search YouTube", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        },
        text = {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search videos or Shorts") },
                leadingIcon = {
                    Icon(Icons.Outlined.Search, contentDescription = null)
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        if (query.isNotBlank()) {
                            onSubmitQuery(query.trim())
                        }
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("shorts_search_input")
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (query.isNotBlank()) {
                        onSubmitQuery(query.trim())
                    }
                }
            ) {
                Text("Search", color = MaterialTheme.colorScheme.primary)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFFAAAAAA))
            }
        }
    )
}
