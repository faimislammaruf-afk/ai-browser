package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Smooth YouTube-style dark theater opening animation displayed briefly on cold start
 * while the WebView initializes underneath.
 */
@Composable
fun LaunchAnimationOverlay(
    isPageReady: Boolean,
    onFinished: () -> Unit
) {
    var visible by remember { mutableStateOf(true) }
    var minDurationPassed by remember { mutableStateOf(false) }

    val logoScale = remember { Animatable(0.66f) }
    val logoAlpha = remember { Animatable(0f) }
    val ringScale = remember { Animatable(0.82f) }
    val ringAlpha = remember { Animatable(0f) }
    val labelAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch {
            logoAlpha.animateTo(1f, tween(durationMillis = 240, easing = FastOutSlowInEasing))
        }
        launch {
            logoScale.animateTo(
                targetValue = 1.0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            delay(140L)
            ringAlpha.animateTo(0.55f, tween(durationMillis = 220))
            ringScale.animateTo(1.38f, tween(durationMillis = 520, easing = FastOutSlowInEasing))
            ringAlpha.animateTo(0f, tween(durationMillis = 260))
        }
        launch {
            delay(180L)
            labelAlpha.animateTo(1f, tween(durationMillis = 260))
        }

        delay(820L)
        minDurationPassed = true

        // Hard cap so slow networks never stall on the launch animation
        delay(700L)
        if (visible) {
            visible = false
            delay(260L)
            onFinished()
        }
    }

    LaunchedEffect(isPageReady, minDurationPassed) {
        if (isPageReady && minDurationPassed && visible) {
            visible = false
            delay(260L)
            onFinished()
        }
    }

    AnimatedVisibility(
        visible = visible,
        exit = fadeOut(animationSpec = tween(260)) + scaleOut(
            targetScale = 1.12f,
            animationSpec = tween(260, easing = FastOutSlowInEasing)
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F0F0F))
                .testTag("launch_animation_overlay"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier.size(124.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .scale(ringScale.value)
                            .alpha(ringAlpha.value)
                    ) {
                        drawRoundRect(
                            color = Color(0xFFFF1744),
                            topLeft = Offset(size.width * 0.1f, size.height * 0.22f),
                            size = Size(size.width * 0.8f, size.height * 0.56f),
                            cornerRadius = CornerRadius(size.width * 0.18f, size.width * 0.18f),
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }

                    Canvas(
                        modifier = Modifier
                            .size(96.dp)
                            .scale(logoScale.value)
                            .alpha(logoAlpha.value)
                    ) {
                        val w = size.width
                        val h = size.height
                        val pillW = w * 0.88f
                        val pillH = h * 0.62f
                        val left = (w - pillW) / 2f
                        val top = (h - pillH) / 2f

                        drawRoundRect(
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFFFF0033), Color(0xFFD50028)),
                                start = Offset(left, top),
                                end = Offset(left + pillW, top + pillH)
                            ),
                            topLeft = Offset(left, top),
                            size = Size(pillW, pillH),
                            cornerRadius = CornerRadius(pillH * 0.28f, pillH * 0.28f)
                        )

                        val triLeft = w * 0.42f
                        val triRight = w * 0.64f
                        val triTop = h * 0.36f
                        val triBottom = h * 0.64f
                        val triPath = Path().apply {
                            moveTo(triLeft, triTop)
                            lineTo(triRight, h * 0.5f)
                            lineTo(triLeft, triBottom)
                            close()
                        }
                        drawPath(path = triPath, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "TubeFloat",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.4.sp,
                    modifier = Modifier.alpha(labelAlpha.value)
                )
            }
        }
    }
}
