package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF090C12)
val ObsidianSurface = Color(0xFF101520)
val ObsidianCard = Color(0xFF161D2B)
val ObsidianElevated = Color(0xFF1E2738)

val CyanElectric = Color(0xFF00E5FF)
val CyanSoft = Color(0xFF80F2FF)
val CoralAccent = Color(0xFFFF2E54)
val EmeraldShield = Color(0xFF00E676)

val InkPrimary = Color(0xFFF3F6FC)
val InkSecondary = Color(0xFF9AA7BD)
val OutlineSubtle = Color(0xFF283347)
