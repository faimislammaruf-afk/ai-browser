package com.example.ui.player

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.WebAdFilter
import com.example.service.BackgroundPlaybackManager
import com.example.ui.components.LaunchAnimationOverlay
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import kotlin.math.abs
import kotlin.math.roundToInt

private class PullRefreshWebView(context: Context) : WebView(context) {
    var canTriggerPullToRefresh: () -> Boolean = { true }
    var keepAudioAliveInBackground: () -> Boolean = { false }
    var onPullOffsetChanged: (Float) -> Unit = {}
    var onPullTriggered: () -> Unit = {}

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var startX = 0f
    private var startY = 0f
    private var isPulling = false
    private var currentPullPx = 0f
    private val maxPullPx = 220f * resources.displayMetrics.density
    private val triggerThresholdPx = 110f * resources.displayMetrics.density

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.VISIBLE && keepAudioAliveInBackground() && isAttachedToWindow) {
            super.onWindowVisibilityChanged(View.VISIBLE)
            return
        }
        super.onWindowVisibilityChanged(visibility)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                isPulling = false
                currentPullPx = 0f
            }
            MotionEvent.ACTION_MOVE -> {
                val dy = event.y - startY
                val dx = abs(event.x - startX)
                val atTop = scrollY <= 0 && !canScrollVertically(-1)
                if (!isPulling && atTop && dy > touchSlop && dy > dx * 1.4f && canTriggerPullToRefresh()) {
                    isPulling = true
                    val cancelEvent = MotionEvent.obtain(event).apply {
                        action = MotionEvent.ACTION_CANCEL
                    }
                    super.onTouchEvent(cancelEvent)
                    cancelEvent.recycle()
                }
                if (isPulling) {
                    currentPullPx = ((dy - touchSlop) * 0.52f).coerceIn(0f, maxPullPx)
                    onPullOffsetChanged(currentPullPx)
                    if (currentPullPx <= 0f) {
                        isPulling = false
                    }
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isPulling) {
                    val shouldRefresh = event.actionMasked == MotionEvent.ACTION_UP &&
                        currentPullPx >= triggerThresholdPx
                    isPulling = false
                    currentPullPx = 0f
                    onPullOffsetChanged(0f)
                    if (shouldRefresh) {
                        onPullTriggered()
                    }
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }
}

private class TubeFloatJsBridge(
    private val onPlaybackChanged: (Boolean, String, String) -> Unit,
    private val onShortsOptions: (String) -> Unit,
    private val onShortsBack: () -> Unit,
    private val onShortsSearch: () -> Unit
) {
    @JavascriptInterface
    fun onPlaybackStateChanged(isPlaying: Boolean, title: String, artist: String) {
        onPlaybackChanged(isPlaying, title, artist)
    }

    @JavascriptInterface
    fun onShortsOptionsRequested(metaJson: String) {
        onShortsOptions(metaJson)
    }

    @JavascriptInterface
    fun onShortsBackFallback() {
        onShortsBack()
    }

    @JavascriptInterface
    fun onShortsSearchFallback() {
        onShortsSearch()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeWebViewScreen(
    initialUrl: String = "https://m.youtube.com"
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val density = LocalDensity.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var webViewRef by remember { mutableStateOf<PullRefreshWebView?>(null) }
    var webViewRecoveryKey by remember { mutableIntStateOf(0) }
    var lastLoadedUrl by remember { mutableStateOf(initialUrl) }
    var isLoading by remember { mutableStateOf(true) }
    var hasInitialPagePainted by remember { mutableStateOf(false) }
    var showLaunchAnimation by remember { mutableStateOf(true) }
    var isRefreshing by remember { mutableStateOf(false) }
    var pullOffsetPx by remember { mutableFloatStateOf(0f) }

    var customFullscreenView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    var shortsOptionsState by remember { mutableStateOf<ShortsOptionsState?>(null) }
    var showDescriptionDialog by remember { mutableStateOf<ShortsOptionsState?>(null) }
    var showQualityDialog by remember { mutableStateOf<ShortsOptionsState?>(null) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var isClearScreen by remember { mutableStateOf(false) }

    val triggerThresholdPx = with(density) { 110.dp.toPx() }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* Service continues cleanly even if notification permission is declined */ }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(isRefreshing) {
        if (isRefreshing) {
            delay(8000L)
            isRefreshing = false
        }
    }

    DisposableEffect(webViewRef) {
        BackgroundPlaybackManager.onCommandPlay = {
            webViewRef?.evaluateJavascript("window.__tubeFloatBgCommand && window.__tubeFloatBgCommand('play');", null)
        }
        BackgroundPlaybackManager.onCommandPause = {
            webViewRef?.evaluateJavascript("window.__tubeFloatBgCommand && window.__tubeFloatBgCommand('pause');", null)
        }
        BackgroundPlaybackManager.onCommandNext = {
            webViewRef?.evaluateJavascript("window.__tubeFloatBgCommand && window.__tubeFloatBgCommand('next');", null)
        }
        BackgroundPlaybackManager.onCommandPrevious = {
            webViewRef?.evaluateJavascript("window.__tubeFloatBgCommand && window.__tubeFloatBgCommand('prev');", null)
        }
        onDispose {
            BackgroundPlaybackManager.clearCallbacks()
        }
    }

    DisposableEffect(lifecycleOwner, webViewRef) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    BackgroundPlaybackManager.setAppBackgroundState(false)
                    webViewRef?.onResume()
                    webViewRef?.evaluateJavascript(
                        "window.__tubeFloatEnterForeground && window.__tubeFloatEnterForeground();",
                        null
                    )
                    BackgroundPlaybackManager.stopService(context)
                }
                Lifecycle.Event.ON_PAUSE -> {
                    try {
                        CookieManager.getInstance().flush()
                    } catch (_: Exception) {}

                    if (BackgroundPlaybackManager.isPlaying && !BackgroundPlaybackManager.userPausedFromNotification) {
                        BackgroundPlaybackManager.setAppBackgroundState(true)
                        // Start ForegroundService during active pause transition (required on Android 12+)
                        BackgroundPlaybackManager.startOrUpdateService(context)
                        webViewRef?.evaluateJavascript(
                            "window.__tubeFloatEnterBackground && window.__tubeFloatEnterBackground();",
                            null
                        )
                        // Guard against Chromium surface detachment pausing media right after pause
                        mainHandler.postDelayed({
                            if (BackgroundPlaybackManager.isAppInBackground && !BackgroundPlaybackManager.userPausedFromNotification) {
                                webViewRef?.evaluateJavascript(
                                    "window.__tubeFloatBgCommand && window.__tubeFloatBgCommand('play');",
                                    null
                                )
                            }
                        }, 260L)
                    } else {
                        BackgroundPlaybackManager.setAppBackgroundState(false)
                        webViewRef?.onPause()
                        BackgroundPlaybackManager.stopService(context)
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    fun setSystemBarsFullscreen(fullscreen: Boolean) {
        val activity = context as? Activity ?: return
        val window = activity.window
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (fullscreen) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    LaunchedEffect(customFullscreenView != null) {
        setSystemBarsFullscreen(customFullscreenView != null)
    }

    val canInterceptBack = isClearScreen ||
        shortsOptionsState != null ||
        customFullscreenView != null ||
        webViewRef?.canGoBack() == true ||
        lastLoadedUrl.contains("/shorts")

    BackHandler(enabled = canInterceptBack) {
        when {
            shortsOptionsState != null -> shortsOptionsState = null
            isClearScreen -> {
                isClearScreen = false
                webViewRef?.evaluateJavascript(
                    "document.documentElement.classList.remove('tubefloat-clear-screen');",
                    null
                )
            }
            customFullscreenView != null -> {
                customViewCallback?.onCustomViewHidden()
                customFullscreenView = null
                customViewCallback = null
            }
            webViewRef?.canGoBack() == true -> webViewRef?.goBack()
            lastLoadedUrl.contains("/shorts") -> webViewRef?.loadUrl("https://m.youtube.com/")
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F0F0F))) {
        key(webViewRecoveryKey) {
            AndroidView(
                factory = { ctx ->
                    PullRefreshWebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                        }

                        val cookieManager = CookieManager.getInstance()
                        cookieManager.setAcceptCookie(true)
                        cookieManager.setAcceptThirdPartyCookies(this, true)

                        keepAudioAliveInBackground = {
                            BackgroundPlaybackManager.isPlaying || BackgroundPlaybackManager.isAppInBackground
                        }
                        canTriggerPullToRefresh = {
                            customFullscreenView == null &&
                                !isRefreshing &&
                                !lastLoadedUrl.contains("/shorts")
                        }
                        onPullOffsetChanged = { offset ->
                            pullOffsetPx = offset
                        }
                        onPullTriggered = {
                            isRefreshing = true
                            reload()
                        }

                        val jsBridge = TubeFloatJsBridge(
                            onPlaybackChanged = { playing, title, artist ->
                                BackgroundPlaybackManager.updatePlaybackState(playing, title, artist)
                            },
                            onShortsOptions = { metaJson ->
                                mainHandler.post {
                                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                    shortsOptionsState = parseShortsMetaJson(metaJson, isClearScreen)
                                }
                            },
                            onShortsBack = {
                                mainHandler.post {
                                    if (canGoBack()) {
                                        goBack()
                                    } else {
                                        loadUrl("https://m.youtube.com/")
                                    }
                                }
                            },
                            onShortsSearch = {
                                mainHandler.post {
                                    showSearchDialog = true
                                }
                            }
                        )
                        addJavascriptInterface(jsBridge, "TubeFloatBridge")

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            cacheMode = WebSettings.LOAD_DEFAULT
                            mediaPlaybackRequiresUserGesture = false
                            loadsImagesAutomatically = true
                            allowFileAccess = false
                            allowContentAccess = true
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            javaScriptCanOpenWindowsAutomatically = true
                            setSupportMultipleWindows(false)
                        }

                        webViewClient = object : WebViewClient() {
                            override fun onRenderProcessGone(
                                view: WebView?,
                                detail: RenderProcessGoneDetail?
                            ): Boolean {
                                mainHandler.post {
                                    customFullscreenView = null
                                    customViewCallback = null
                                    isRefreshing = false
                                    pullOffsetPx = 0f
                                    webViewRef = null
                                    webViewRecoveryKey++
                                }
                                return true
                            }

                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val uri = request?.url ?: return null
                                val urlStr = uri.toString()
                                if (WebAdFilter.isAdRequest(urlStr, uri.host)) {
                                    return if (WebAdFilter.isJsonAdEndpoint(urlStr)) {
                                        WebResourceResponse(
                                            "application/json",
                                            "utf-8",
                                            ByteArrayInputStream("{}".toByteArray())
                                        )
                                    } else {
                                        WebResourceResponse(
                                            "text/plain",
                                            "utf-8",
                                            ByteArrayInputStream(ByteArray(0))
                                        )
                                    }
                                }
                                return null
                            }

                            override fun onPageStarted(
                                view: WebView?,
                                url: String?,
                                favicon: android.graphics.Bitmap?
                            ) {
                                super.onPageStarted(view, url, favicon)
                                isLoading = true
                                val u = url.orEmpty()
                                if (u.isNotBlank()) lastLoadedUrl = u
                                view?.evaluateJavascript(YouTubeScripts.EARLY_BACKGROUND_HOOK_SCRIPT, null)
                            }

                            override fun onPageCommitVisible(view: WebView?, url: String?) {
                                super.onPageCommitVisible(view, url)
                                hasInitialPagePainted = true
                                view?.evaluateJavascript(YouTubeScripts.EARLY_BACKGROUND_HOOK_SCRIPT, null)
                                view?.evaluateJavascript(YouTubeScripts.MAIN_PLAYER_AND_SHORTS_SCRIPT, null)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                isLoading = false
                                hasInitialPagePainted = true
                                isRefreshing = false
                                val u = url.orEmpty()
                                if (u.isNotBlank()) lastLoadedUrl = u
                                view?.evaluateJavascript(YouTubeScripts.EARLY_BACKGROUND_HOOK_SCRIPT, null)
                                view?.evaluateJavascript(YouTubeScripts.MAIN_PLAYER_AND_SHORTS_SCRIPT, null)
                                try {
                                    CookieManager.getInstance().flush()
                                } catch (_: Exception) {}
                            }

                            override fun doUpdateVisitedHistory(
                                view: WebView?,
                                url: String?,
                                isReload: Boolean
                            ) {
                                super.doUpdateVisitedHistory(view, url, isReload)
                                val u = url.orEmpty()
                                if (u.isNotBlank()) lastLoadedUrl = u
                                if (!u.contains("/shorts") && isClearScreen) {
                                    isClearScreen = false
                                    view?.evaluateJavascript(
                                        "document.documentElement.classList.remove('tubefloat-clear-screen');",
                                        null
                                    )
                                }
                                view?.evaluateJavascript(YouTubeScripts.EARLY_BACKGROUND_HOOK_SCRIPT, null)
                                view?.evaluateJavascript(YouTubeScripts.MAIN_PLAYER_AND_SHORTS_SCRIPT, null)
                            }

                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean {
                                val url = request?.url?.toString() ?: return false
                                val lower = url.lowercase()
                                if (lower.startsWith("intent://") ||
                                    lower.startsWith("vnd.youtube:") ||
                                    lower.startsWith("market://") ||
                                    lower.contains("play.google.com/store/apps/details?id=com.google.android.youtube")
                                ) {
                                    return true
                                }
                                if (lower.startsWith("http://") || lower.startsWith("https://")) {
                                    return false
                                }
                                return try {
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                    true
                                } catch (_: Exception) {
                                    true
                                }
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                                if (view == null) return
                                if (customFullscreenView != null) {
                                    callback?.onCustomViewHidden()
                                    return
                                }
                                customFullscreenView = view
                                customViewCallback = callback
                            }

                            override fun onHideCustomView() {
                                customFullscreenView = null
                                customViewCallback?.onCustomViewHidden()
                                customViewCallback = null
                            }
                        }

                        loadUrl(lastLoadedUrl)
                        webViewRef = this
                    }
                },
                onRelease = { wv ->
                    wv.stopLoading()
                    wv.destroy()
                    if (webViewRef == wv) {
                        webViewRef = null
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("youtube_webview")
                    .then(
                        if (customFullscreenView == null) {
                            Modifier.windowInsetsPadding(WindowInsets.systemBars)
                        } else {
                            Modifier
                        }
                    )
            )
        }

        if (isLoading && !isRefreshing && !showLaunchAnimation && customFullscreenView == null) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .align(Alignment.TopCenter)
            )
        }

        // Subtle pill when Clear Screen mode is enabled on Shorts
        if (isClearScreen && lastLoadedUrl.contains("/shorts")) {
            Surface(
                onClick = {
                    isClearScreen = false
                    webViewRef?.evaluateJavascript(
                        "document.documentElement.classList.remove('tubefloat-clear-screen');",
                        null
                    )
                },
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = 0.55f),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(top = 12.dp, end = 12.dp)
                    .testTag("restore_shorts_ui_chip")
            ) {
                Text(
                    text = "Show controls",
                    color = Color.White,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                )
            }
        }

        // Pull-to-Refresh pill indicator
        val showPullIndicator = (pullOffsetPx > 6f || isRefreshing) && customFullscreenView == null
        val pullProgress = (pullOffsetPx / triggerThresholdPx).coerceIn(0f, 1f)
        val indicatorOffsetY by animateFloatAsState(
            targetValue = if (isRefreshing) {
                with(density) { 20.dp.toPx() }
            } else {
                (pullOffsetPx * 0.55f - with(density) { 24.dp.toPx() })
                    .coerceIn(0f, with(density) { 72.dp.toPx() })
            },
            label = "pull_indicator_y"
        )

        AnimatedVisibility(
            visible = showPullIndicator,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBars)
                .offset { IntOffset(0, indicatorOffsetY.roundToInt()) }
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .padding(top = 8.dp)
                    .size(44.dp)
                    .testTag("pull_to_refresh_indicator")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (isRefreshing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Pull to refresh",
                            tint = if (pullProgress >= 1f) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier
                                .size(22.dp)
                                .alpha(0.45f + pullProgress * 0.55f)
                                .rotate(pullProgress * 270f)
                        )
                    }
                }
            }
        }

        customFullscreenView?.let { fsView ->
            AndroidView(
                factory = { ctx ->
                    FrameLayout(ctx).apply {
                        (fsView.parent as? ViewGroup)?.removeView(fsView)
                        addView(
                            fsView,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            )
        }

        shortsOptionsState?.let { currentState ->
            ShortsOptionsBottomSheet(
                state = currentState,
                onDismiss = { shortsOptionsState = null },
                onAction = { action ->
                    shortsOptionsState = null
                    when (action) {
                        ShortsOptionAction.DESCRIPTION -> {
                            showDescriptionDialog = currentState
                        }
                        ShortsOptionAction.CLEAR_SCREEN -> {
                            val nextClear = !isClearScreen
                            isClearScreen = nextClear
                            webViewRef?.evaluateJavascript(
                                "window.__tubeFloatShortsAction && window.__tubeFloatShortsAction('clear_screen');",
                                null
                            )
                        }
                        ShortsOptionAction.CAPTIONS -> {
                            webViewRef?.evaluateJavascript(
                                "window.__tubeFloatShortsAction && window.__tubeFloatShortsAction('captions');",
                                null
                            )
                            Toast.makeText(context, "Toggled captions", Toast.LENGTH_SHORT).show()
                        }
                        ShortsOptionAction.QUALITY -> {
                            showQualityDialog = currentState
                        }
                        ShortsOptionAction.NOT_INTERESTED -> {
                            webViewRef?.evaluateJavascript(
                                "window.__tubeFloatShortsAction && window.__tubeFloatShortsAction('not_interested');",
                                null
                            )
                            Toast.makeText(context, "Skipped • Not interested", Toast.LENGTH_SHORT).show()
                        }
                        ShortsOptionAction.DONT_RECOMMEND_CHANNEL -> {
                            webViewRef?.evaluateJavascript(
                                "window.__tubeFloatShortsAction && window.__tubeFloatShortsAction('dont_recommend');",
                                null
                            )
                            Toast.makeText(context, "Channel hidden for this session", Toast.LENGTH_SHORT).show()
                        }
                        ShortsOptionAction.REPORT -> {
                            webViewRef?.evaluateJavascript(
                                "window.__tubeFloatShortsAction && window.__tubeFloatShortsAction('report');",
                                null
                            )
                        }
                        ShortsOptionAction.SEND_FEEDBACK -> {
                            showFeedbackDialog = true
                        }
                    }
                }
            )
        }

        showDescriptionDialog?.let { descState ->
            ShortsDescriptionDialog(
                state = descState,
                onDismiss = { showDescriptionDialog = null }
            )
        }

        showQualityDialog?.let { qualState ->
            ShortsQualityAndSpeedDialog(
                currentQuality = qualState.qualityLabel,
                currentRate = qualState.playbackRate,
                onDismiss = { showQualityDialog = null },
                onSelectSpeed = { rate ->
                    webViewRef?.evaluateJavascript(
                        "window.__tubeFloatShortsAction && window.__tubeFloatShortsAction('speed', '$rate');",
                        null
                    )
                    Toast.makeText(context, "Playback speed: ${rate}x", Toast.LENGTH_SHORT).show()
                }
            )
        }

        if (showSearchDialog) {
            ShortsSearchDialog(
                onDismiss = { showSearchDialog = false },
                onSubmitQuery = { query ->
                    showSearchDialog = false
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    webViewRef?.loadUrl("https://m.youtube.com/results?search_query=$encoded")
                }
            )
        }

        if (showFeedbackDialog) {
            var feedbackText by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showFeedbackDialog = false },
                containerColor = Color(0xFF212121),
                titleContentColor = Color.White,
                title = { Text("Send feedback") },
                text = {
                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        placeholder = { Text("Describe the issue with this Short") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showFeedbackDialog = false
                            Toast.makeText(context, "Feedback noted", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("Submit", color = MaterialTheme.colorScheme.primary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showFeedbackDialog = false }) {
                        Text("Cancel", color = Color(0xFFAAAAAA))
                    }
                }
            )
        }

        if (showLaunchAnimation) {
            LaunchAnimationOverlay(
                isPageReady = hasInitialPagePainted,
                onFinished = { showLaunchAnimation = false }
            )
        }
    }
}

private fun parseShortsMetaJson(json: String, currentClearScreen: Boolean): ShortsOptionsState {
    return try {
        val obj = JSONObject(json)
        ShortsOptionsState(
            title = obj.optString("title", ""),
            channel = obj.optString("channel", ""),
            description = obj.optString("description", ""),
            captionsStatus = obj.optString("captionsStatus", "Unavailable"),
            qualityLabel = obj.optString("qualityLabel", "Auto"),
            playbackRate = obj.optDouble("playbackRate", 1.0).toFloat(),
            isClearScreen = obj.optBoolean("isClearScreen", currentClearScreen)
        )
    } catch (_: Exception) {
        ShortsOptionsState(isClearScreen = currentClearScreen)
    }
}
