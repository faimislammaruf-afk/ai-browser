package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CyanElectric,
    onPrimary = Color(0xFF002026),
    primaryContainer = Color(0xFF003842),
    onPrimaryContainer = CyanSoft,
    secondary = EmeraldShield,
    onSecondary = Color(0xFF00210E),
    tertiary = CoralAccent,
    onTertiary = Color.White,
    background = ObsidianBg,
    onBackground = InkPrimary,
    surface = ObsidianSurface,
    onSurface = InkPrimary,
    surfaceContainer = ObsidianCard,
    surfaceContainerHigh = ObsidianCard,
    surfaceContainerHighest = ObsidianElevated,
    onSurfaceVariant = InkSecondary,
    outline = OutlineSubtle
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF006876),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFA0F0FF),
    onPrimaryContainer = Color(0xFF001F25),
    secondary = Color(0xFF006E38),
    tertiary = CoralAccent,
    background = Color(0xFFF6F8FC),
    onBackground = Color(0xFF121721),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF121721),
    surfaceContainerHigh = Color(0xFFECF1F8),
    surfaceContainerHighest = Color(0xFFE2E8F2),
    onSurfaceVariant = Color(0xFF546175)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
