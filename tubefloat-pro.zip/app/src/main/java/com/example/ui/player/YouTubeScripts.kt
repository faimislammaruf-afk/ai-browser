package com.example.ui.player

/**
 * Modular JavaScript helpers injected into m.youtube.com for:
 * 1) Background audio continuity (Page Visibility override + auto-resume guard)
 * 2) Zero-jank ad and "Open in YouTube app" promo suppression
 * 3) Shorts top bar fixes (Back, Search, 3-dot) and long-press options sheet
 */
object YouTubeScripts {

    /**
     * Injected early at onPageStarted and re-verified on onPageFinished so YouTube's
     * visibility listeners never pause audio when the user backgrounds TubeFloat.
     */
    val EARLY_BACKGROUND_HOOK_SCRIPT: String = """
        (function() {
            try {
                if (window.__tubeFloatVisibilityPatched) return;
                window.__tubeFloatVisibilityPatched = true;
                window.__tubeFloatInBackground = false;
                window.__tubeFloatWasPlayingBeforeBg = false;
                window.__tubeFloatUserPaused = false;
                window.__tubeFloatResumeAttempts = 0;

                var overrideProp = function(obj, prop, getter) {
                    try {
                        Object.defineProperty(obj, prop, {
                            get: getter,
                            configurable: true
                        });
                    } catch (e) {}
                };

                overrideProp(document, 'hidden', function() { return false; });
                overrideProp(document, 'webkitHidden', function() { return false; });
                overrideProp(document, 'visibilityState', function() { return 'visible'; });
                overrideProp(document, 'webkitVisibilityState', function() { return 'visible'; });

                var origHasFocus = document.hasFocus ? document.hasFocus.bind(document) : function() { return true; };
                document.hasFocus = function() {
                    if (window.__tubeFloatInBackground) return true;
                    try { return origHasFocus(); } catch (e) { return true; }
                };

                var stopIfBackground = function(e) {
                    if (window.__tubeFloatInBackground) {
                        e.stopImmediatePropagation();
                    }
                };
                window.addEventListener('visibilitychange', stopIfBackground, true);
                document.addEventListener('visibilitychange', stopIfBackground, true);
                window.addEventListener('webkitvisibilitychange', stopIfBackground, true);
                document.addEventListener('webkitvisibilitychange', stopIfBackground, true);
                window.addEventListener('pagehide', stopIfBackground, true);
            } catch (e) {}
        })();
    """.trimIndent()

    val MAIN_PLAYER_AND_SHORTS_SCRIPT: String = """
        (function() {
            function isShortsRoute() {
                return (location.pathname || '').indexOf('/shorts') === 0;
            }

            function getActiveVideo() {
                if (isShortsRoute()) {
                    var activeShort = document.querySelector('ytm-reel-video-renderer[is-active], reel-video-renderer[is-active]');
                    if (activeShort) {
                        var sv = activeShort.querySelector('video');
                        if (sv) return sv;
                    }
                }
                var vids = document.querySelectorAll('video');
                for (var i = 0; i < vids.length; i++) {
                    if (!vids[i].paused && vids[i].readyState > 0) return vids[i];
                }
                return vids.length > 0 ? vids[0] : null;
            }

            function getCurrentMediaMeta() {
                var title = '';
                var artist = '';
                try {
                    if (isShortsRoute()) {
                        var activeShort = document.querySelector('ytm-reel-video-renderer[is-active], reel-video-renderer[is-active]');
                        if (activeShort) {
                            var tEl = activeShort.querySelector('h2, .reel-player-header-renderer h2, yt-formatted-string, .ytm-shorts-lockup-view-model-title, [class*="title"]');
                            var cEl = activeShort.querySelector('a[href*="/@"], a[href*="/channel/"], .ytm-reel-channel-bar-view-model a, ytm-reel-channel-bar-renderer a');
                            title = tEl ? (tEl.textContent || '').trim() : '';
                            artist = cEl ? (cEl.textContent || '').trim() : '';
                        }
                    } else {
                        var hEl = document.querySelector('h2.slim-video-information-title, .slim-video-information-title, h1.ytd-watch-metadata, ytm-slim-video-metadata-section-renderer h2');
                        var aEl = document.querySelector('.slim-owner-channel-name, ytm-slim-owner-renderer a, #channel-name a');
                        title = hEl ? (hEl.textContent || '').trim() : '';
                        artist = aEl ? (aEl.textContent || '').trim() : '';
                    }
                    if (!title) {
                        title = (document.title || '').replace(/\s*-\s*YouTube\s*$/i, '').trim();
                    }
                } catch (e) {}
                return { title: title, artist: artist };
            }

            function notifyPlaybackState() {
                try {
                    if (!window.TubeFloatBridge || !window.TubeFloatBridge.onPlaybackStateChanged) return;
                    var v = getActiveVideo();
                    var playing = !!(v && !v.paused && !v.ended);
                    var meta = getCurrentMediaMeta();
                    window.TubeFloatBridge.onPlaybackStateChanged(playing, meta.title || '', meta.artist || '');
                } catch (e) {}
            }

            function attachVideoListeners() {
                try {
                    var videos = document.querySelectorAll('video');
                    videos.forEach(function(v) {
                        if (v.dataset && v.dataset.tfBound === '1') return;
                        if (v.dataset) v.dataset.tfBound = '1';

                        v.addEventListener('play', function() {
                            window.__tubeFloatUserPaused = false;
                            notifyPlaybackState();
                        });
                        v.addEventListener('playing', function() {
                            window.__tubeFloatUserPaused = false;
                            notifyPlaybackState();
                        });
                        v.addEventListener('pause', function() {
                            if (window.__tubeFloatInBackground &&
                                window.__tubeFloatWasPlayingBeforeBg &&
                                !window.__tubeFloatUserPaused &&
                                !v.ended &&
                                window.__tubeFloatResumeAttempts < 6) {
                                window.__tubeFloatResumeAttempts++;
                                setTimeout(function() {
                                    try {
                                        if (window.__tubeFloatInBackground && !window.__tubeFloatUserPaused && v.paused && !v.ended) {
                                            var p = v.play();
                                            if (p && p.catch) p.catch(function() {});
                                        }
                                    } catch (e) {}
                                }, 80);
                                return;
                            }
                            notifyPlaybackState();
                        });
                        v.addEventListener('ended', notifyPlaybackState);
                        v.addEventListener('loadedmetadata', notifyPlaybackState);
                    });
                } catch (e) {}
            }

            window.__tubeFloatEnterBackground = function() {
                var v = getActiveVideo();
                window.__tubeFloatInBackground = true;
                window.__tubeFloatResumeAttempts = 0;
                window.__tubeFloatWasPlayingBeforeBg = !!(v && !v.paused && !v.ended);
                if (window.__tubeFloatWasPlayingBeforeBg && v) {
                    setTimeout(function() {
                        try {
                            if (window.__tubeFloatInBackground && !window.__tubeFloatUserPaused && v.paused && !v.ended) {
                                var p = v.play();
                                if (p && p.catch) p.catch(function() {});
                            }
                        } catch (e) {}
                    }, 180);
                }
            };

            window.__tubeFloatEnterForeground = function() {
                window.__tubeFloatInBackground = false;
                window.__tubeFloatWasPlayingBeforeBg = false;
                window.__tubeFloatResumeAttempts = 0;
                notifyPlaybackState();
            };

            window.__tubeFloatBgCommand = function(cmd) {
                var v = getActiveVideo();
                if (cmd === 'play') {
                    window.__tubeFloatUserPaused = false;
                    if (v) {
                        try {
                            var p = v.play();
                            if (p && p.catch) p.catch(function() {});
                        } catch (e) {}
                    }
                    setTimeout(notifyPlaybackState, 100);
                } else if (cmd === 'pause') {
                    window.__tubeFloatUserPaused = true;
                    window.__tubeFloatWasPlayingBeforeBg = false;
                    if (v) {
                        try { v.pause(); } catch (e) {}
                    }
                    setTimeout(notifyPlaybackState, 80);
                } else if (cmd === 'next') {
                    if (isShortsRoute()) {
                        var nextShort = document.querySelector('#navigation-button-down button, button[aria-label="Next video"]');
                        if (nextShort) nextShort.click();
                    } else {
                        var nextBtn = document.querySelector('.ytp-next-button, button[aria-label*="Next" i], a.ytp-next-button');
                        if (nextBtn) nextBtn.click();
                    }
                    setTimeout(notifyPlaybackState, 400);
                } else if (cmd === 'prev') {
                    if (isShortsRoute()) {
                        var prevShort = document.querySelector('#navigation-button-up button, button[aria-label="Previous video"]');
                        if (prevShort) prevShort.click();
                    } else {
                        var prevBtn = document.querySelector('.ytp-prev-button, button[aria-label*="Previous" i]');
                        if (prevBtn) prevBtn.click();
                        else if (v) v.currentTime = 0;
                    }
                    setTimeout(notifyPlaybackState, 400);
                }
            };

            function injectCss() {
                if (document.getElementById('tubefloat-adfree-css')) return;
                var style = document.createElement('style');
                style.id = 'tubefloat-adfree-css';
                style.textContent =
                    '.video-ads, .ytp-ad-module, .ytp-ad-player-overlay, .ytp-ad-overlay-container, ' +
                    '.ytp-ad-action-interstitial, ytm-promoted-sparkles-web-renderer, ytd-promoted-sparkles-web-renderer, ' +
                    'ytm-ad-slot-renderer, ytd-ad-slot-renderer, ad-slot-renderer, ytm-companion-slot, ' +
                    '#player-ads, ytm-statement-banner-renderer, ytm-in-feed-ad-layout-renderer, ' +
                    '.sparkles-light-cta, ytm-promoted-video-renderer, ytm-brand-video-shelf-renderer, ' +
                    'ytm-mealbar-promo-renderer, yt-mealbar-promo-renderer, ytm-upsell-dialog-renderer, ' +
                    'yt-upsell-dialog-renderer, ytm-open-app-button, ytm-promo-banner-renderer, ' +
                    'button[aria-label*="Open App" i], a[href*="app_promo"], ' +
                    'a[href*="play.google.com/store/apps/details?id=com.google.android.youtube"] ' +
                    '{ display: none !important; height: 0 !important; opacity: 0 !important; pointer-events: none !important; } ' +
                    /* Prevent Android WebView text-selection highlight when click-and-holding Shorts/Reels */ ' +
                    'ytm-reel-video-renderer, reel-video-renderer, ytm-shorts-player-controls, ' +
                    '.reel-player-overlay-main-content, .reel-player-overlay-actions, ' +
                    '.ytp-caption-segment, ytm-reel-player-header-renderer, reel-player-header-renderer ' +
                    '{ -webkit-user-select: none !important; user-select: none !important; -webkit-touch-callout: none !important; } ' +
                    /* Ensure Shorts top header buttons (Back, Search, More) are always clickable above overlays */ ' +
                    'ytm-reel-player-header-renderer, reel-player-header-renderer, .reel-player-header, ' +
                    'ytm-reel-player-header-renderer button, ytm-reel-player-header-renderer a, ' +
                    'reel-player-header-renderer button, reel-player-header-renderer a ' +
                    '{ pointer-events: auto !important; z-index: 9999 !important; } ' +
                    /* Clear Screen toggle for Shorts */ ' +
                    'html.tubefloat-clear-screen .reel-player-overlay-main-content, ' +
                    'html.tubefloat-clear-screen .reel-player-overlay-actions, ' +
                    'html.tubefloat-clear-screen ytm-reel-player-header-renderer, ' +
                    'html.tubefloat-clear-screen reel-player-header-renderer, ' +
                    'html.tubefloat-clear-screen ytm-pivot-bar-renderer, ' +
                    'html.tubefloat-clear-screen .reel-player-header, ' +
                    'html.tubefloat-clear-screen ytm-reel-channel-bar-renderer ' +
                    '{ opacity: 0 !important; pointer-events: none !important; transition: opacity 0.18s ease; }';
                (document.head || document.documentElement).appendChild(style);
            }

            function dismissAppPromoPopups() {
                document.querySelectorAll(
                    'ytm-mealbar-promo-renderer, yt-mealbar-promo-renderer, ytm-upsell-dialog-renderer, ' +
                    'yt-upsell-dialog-renderer, ytm-promo-banner-renderer, ytm-open-app-button'
                ).forEach(function(el) { el.remove(); });

                var dialogs = document.querySelectorAll(
                    'tp-yt-paper-dialog, ytm-bottom-sheet-renderer, ytm-dialog-renderer, yt-dialog-view-model, [role="dialog"], [aria-modal="true"]'
                );
                var dismissedAny = false;
                for (var i = 0; i < dialogs.length; i++) {
                    var dlg = dialogs[i];
                    // Never strip interactive menus, search bars, or video quality/caption pickers
                    if (dlg.querySelector('input[type="search"], input[name="search_query"], ytm-searchbox')) {
                        continue;
                    }
                    var text = (dlg.textContent || '').toLowerCase();
                    if (text.indexOf('playback speed') !== -1 ||
                        text.indexOf('not interested') !== -1 ||
                        text.indexOf('don\'t recommend') !== -1 ||
                        text.indexOf('clear screen') !== -1 ||
                        (text.indexOf('quality') !== -1 && text.indexOf('captions') !== -1)) {
                        continue;
                    }

                    var isAppPromo =
                        text.indexOf('use youtube in the youtube app') !== -1 ||
                        text.indexOf('watch in the youtube app') !== -1 ||
                        text.indexOf('open in the youtube app') !== -1 ||
                        text.indexOf('get the youtube app') !== -1 ||
                        text.indexOf('switch to the youtube app') !== -1 ||
                        !!dlg.querySelector('a[href*="play.google.com/store/apps/details?id=com.google.android.youtube"], a[href^="intent://"]');

                    if (isAppPromo) {
                        var btns = dlg.querySelectorAll('button, [role="button"], a');
                        for (var j = 0; j < btns.length; j++) {
                            var bTxt = (btns[j].textContent || btns[j].getAttribute('aria-label') || '').toLowerCase();
                            if (bTxt.indexOf('not now') !== -1 ||
                                bTxt.indexOf('no thanks') !== -1 ||
                                bTxt.indexOf('stay on web') !== -1 ||
                                bTxt.indexOf('continue on web') !== -1 ||
                                bTxt.indexOf('dismiss') !== -1 ||
                                bTxt.indexOf('cancel') !== -1 ||
                                bTxt.indexOf('close') !== -1) {
                                try { btns[j].click(); } catch (e) {}
                                break;
                            }
                        }
                        dlg.style.display = 'none';
                        dlg.remove();
                        dismissedAny = true;
                    }
                }

                if (dismissedAny) {
                    document.querySelectorAll('tp-yt-iron-overlay-backdrop, .ytm-dialog-backdrop').forEach(function(bd) {
                        bd.style.display = 'none';
                        bd.remove();
                    });
                    if (document.body) document.body.style.overflow = '';
                    if (document.documentElement) document.documentElement.style.overflow = '';
                }
            }

            window.__tubeFloatBlockedChannels = window.__tubeFloatBlockedChannels || {};

            function cleanYouTubeAds() {
                injectCss();
                attachVideoListeners();
                dismissAppPromoPopups();

                var feedAdSelectors = [
                    'ytm-promoted-sparkles-web-renderer', 'ytd-promoted-sparkles-web-renderer',
                    'ytm-ad-slot-renderer', 'ytd-ad-slot-renderer', 'ad-slot-renderer',
                    'ytm-companion-slot', 'ytm-statement-banner-renderer',
                    'ytm-in-feed-ad-layout-renderer', 'ytm-promoted-video-renderer',
                    'ytm-brand-video-shelf-renderer'
                ];
                for (var i = 0; i < feedAdSelectors.length; i++) {
                    document.querySelectorAll(feedAdSelectors[i]).forEach(function(el) {
                        el.remove();
                    });
                }

                var skipBtn = document.querySelector(
                    '.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, button[aria-label*="Skip ad" i], button[aria-label*="Skip" i].ytp-ad-button'
                );
                if (skipBtn) skipBtn.click();

                var video = getActiveVideo();
                var adShowing = document.querySelector('.ad-showing, .ytp-ad-player-overlay-instream-info');
                if (video) {
                    if (adShowing) {
                        try {
                            if (!video.muted) {
                                window.__tubeFloatMutedForAd = true;
                                video.muted = true;
                            }
                            if (video.duration && isFinite(video.duration) && video.duration > 0) {
                                video.currentTime = video.duration;
                            }
                        } catch (e) {}
                    } else if (window.__tubeFloatMutedForAd) {
                        window.__tubeFloatMutedForAd = false;
                        try { video.muted = false; } catch (e) {}
                    }
                }

                if (isShortsRoute()) {
                    var activeShort = document.querySelector('ytm-reel-video-renderer[is-active], reel-video-renderer[is-active]');
                    if (activeShort) {
                        var hasAdBadge = activeShort.querySelector('ytm-ad-slot-renderer, ad-badge-view-model, [aria-label="Sponsored"]');
                        var channelEl = activeShort.querySelector('a[href*="/@"], a[href*="/channel/"], ytm-reel-channel-bar-renderer a');
                        var channelName = channelEl ? (channelEl.textContent || '').trim().toLowerCase() : '';
                        var isBlockedChannel = channelName && !!window.__tubeFloatBlockedChannels[channelName];
                        if (hasAdBadge || isBlockedChannel) {
                            var sv = activeShort.querySelector('video');
                            if (sv) sv.muted = true;
                            activeShort.style.display = 'none';
                            var nextBtn = document.querySelector('#navigation-button-down button, button[aria-label="Next video"]');
                            if (nextBtn) nextBtn.click();
                            else window.scrollBy(0, window.innerHeight);
                        }
                    }
                }
            }

            function collectShortsMeta() {
                var meta = getCurrentMediaMeta();
                var activeShort = document.querySelector('ytm-reel-video-renderer[is-active], reel-video-renderer[is-active]') || document;
                var video = getActiveVideo();

                var descEl = activeShort.querySelector('.reel-player-overlay-main-content h2, .ytm-shorts-lockup-view-model-title, #overlay .title');
                var fullDesc = descEl ? (descEl.textContent || '').trim() : meta.title;

                var ccBtn = activeShort.querySelector('button[aria-label*="Caption" i], button[aria-label*="Subtitles" i]');
                var captionsStatus = 'Unavailable';
                if (ccBtn) {
                    var pressed = ccBtn.getAttribute('aria-pressed');
                    captionsStatus = pressed === 'true' ? 'On' : 'Off';
                } else if (video && video.textTracks && video.textTracks.length > 0) {
                    var anyShowing = false;
                    for (var i = 0; i < video.textTracks.length; i++) {
                        if (video.textTracks[i].mode === 'showing') anyShowing = true;
                    }
                    captionsStatus = anyShowing ? 'On' : 'Off';
                }

                var qualityLabel = 'Auto';
                if (video && video.videoHeight > 0) {
                    var h = video.videoHeight;
                    var w = video.videoWidth || 0;
                    var res = Math.min(h, w) > 0 && w > h ? h : Math.min(h, w || h);
                    if (res >= 1000) qualityLabel = 'Auto (1080p)';
                    else if (res >= 700) qualityLabel = 'Auto (720p)';
                    else if (res >= 460) qualityLabel = 'Auto (480p)';
                    else if (res >= 340) qualityLabel = 'Auto (360p)';
                    else qualityLabel = 'Auto (' + res + 'p)';
                }

                var rate = video && video.playbackRate ? video.playbackRate : 1.0;
                var isClear = document.documentElement.classList.contains('tubefloat-clear-screen');

                return JSON.stringify({
                    title: meta.title || '',
                    channel: meta.channel || meta.artist || '',
                    description: fullDesc || meta.title || '',
                    captionsStatus: captionsStatus,
                    qualityLabel: qualityLabel,
                    playbackRate: rate,
                    isClearScreen: isClear
                });
            }

            function openShortsOptionsFromJs() {
                if (window.TubeFloatBridge && window.TubeFloatBridge.onShortsOptionsRequested) {
                    window.TubeFloatBridge.onShortsOptionsRequested(collectShortsMeta());
                }
            }

            window.__tubeFloatShortsAction = function(action, arg) {
                var activeShort = document.querySelector('ytm-reel-video-renderer[is-active], reel-video-renderer[is-active]') || document;
                var video = getActiveVideo();
                if (action === 'clear_screen') {
                    var nowClear = document.documentElement.classList.toggle('tubefloat-clear-screen');
                    return nowClear;
                } else if (action === 'captions') {
                    var ccBtn = activeShort.querySelector('button[aria-label*="Caption" i], button[aria-label*="Subtitles" i]');
                    if (ccBtn) {
                        ccBtn.click();
                        return true;
                    }
                    if (video && video.textTracks && video.textTracks.length > 0) {
                        var currentlyShowing = video.textTracks[0].mode === 'showing';
                        for (var i = 0; i < video.textTracks.length; i++) {
                            video.textTracks[i].mode = currentlyShowing ? 'disabled' : 'showing';
                        }
                        return true;
                    }
                } else if (action === 'speed') {
                    var rate = parseFloat(arg);
                    if (video && isFinite(rate) && rate > 0) {
                        video.playbackRate = rate;
                    }
                } else if (action === 'not_interested') {
                    var nextBtn = document.querySelector('#navigation-button-down button, button[aria-label="Next video"]');
                    if (nextBtn) nextBtn.click();
                    else window.scrollBy(0, window.innerHeight);
                } else if (action === 'dont_recommend') {
                    var meta = getCurrentMediaMeta();
                    var ch = (meta.artist || '').trim().toLowerCase();
                    if (ch) window.__tubeFloatBlockedChannels[ch] = true;
                    var nextBtn2 = document.querySelector('#navigation-button-down button, button[aria-label="Next video"]');
                    if (nextBtn2) nextBtn2.click();
                    else window.scrollBy(0, window.innerHeight);
                } else if (action === 'report') {
                    var m = (location.pathname || '').match(/\/shorts\/([a-zA-Z0-9_-]+)/);
                    if (m && m[1]) {
                        location.assign('https://m.youtube.com/watch?v=' + m[1]);
                    }
                }
                return false;
            };

            function installShortsInteractions() {
                if (window.__tubeFloatShortsInteractionsInstalled) return;
                window.__tubeFloatShortsInteractionsInstalled = true;

                // 1) Fix the 3 top Shorts header buttons (Back, Search, 3-dot Menu)
                document.addEventListener('click', function(e) {
                    if (window.__tubeFloatSuppressNextClick) {
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        window.__tubeFloatSuppressNextClick = false;
                        return;
                    }
                    if (!isShortsRoute()) return;

                    var target = e.target;
                    if (!target || !target.closest) return;
                    var btn = target.closest('button, a, [role="button"], yt-icon-button');
                    if (!btn) return;

                    var rect = btn.getBoundingClientRect ? btn.getBoundingClientRect() : null;
                    var inTopHeader = !!btn.closest('ytm-reel-player-header-renderer, reel-player-header-renderer, .reel-player-header, ytm-mobile-topbar-renderer') ||
                        (rect && rect.top >= 0 && rect.top <= 130 && rect.height <= 90);
                    if (!inTopHeader) return;

                    var label = ((btn.getAttribute('aria-label') || '') + ' ' + (btn.getAttribute('title') || '')).toLowerCase().trim();
                    var isBack = label.indexOf('back') !== -1 || label.indexOf('navigate') !== -1 ||
                        (!label && rect && rect.left < 110 && rect.width > 0 && rect.width < 110);
                    var isSearch = label.indexOf('search') !== -1 ||
                        (!label && rect && rect.right > window.innerWidth - 130 && rect.right <= window.innerWidth - 52);
                    var isMore = label.indexOf('more') !== -1 || label.indexOf('menu') !== -1 || label.indexOf('option') !== -1 || label.indexOf('action') !== -1 ||
                        (!label && rect && rect.right > window.innerWidth - 56);

                    if (isBack) {
                        var beforeHref = location.href;
                        setTimeout(function() {
                            if (location.href === beforeHref && isShortsRoute()) {
                                if (window.TubeFloatBridge && window.TubeFloatBridge.onShortsBackFallback) {
                                    window.TubeFloatBridge.onShortsBackFallback();
                                } else if (window.history.length > 1) {
                                    window.history.back();
                                } else {
                                    location.assign('https://m.youtube.com/');
                                }
                            }
                        }, 140);
                    } else if (isSearch) {
                        var beforeSearchHref = location.href;
                        setTimeout(function() {
                            var searchOpened = !!document.querySelector('input[type="search"]:focus, input[name="search_query"]:focus, ytm-searchbox input') ||
                                location.href !== beforeSearchHref;
                            if (!searchOpened && window.TubeFloatBridge && window.TubeFloatBridge.onShortsSearchFallback) {
                                window.TubeFloatBridge.onShortsSearchFallback();
                            }
                        }, 180);
                    } else if (isMore) {
                        setTimeout(function() {
                            var nativeSheet = document.querySelector('ytm-bottom-sheet-renderer, tp-yt-paper-dialog[aria-hidden="false"], ytm-menu-popup-renderer');
                            var hasVisibleItems = nativeSheet && nativeSheet.offsetHeight > 40;
                            if (!hasVisibleItems) {
                                openShortsOptionsFromJs();
                            }
                        }, 140);
                    }
                }, true);

                // 2) Long-press ("click and hold") anywhere on Shorts video to open Shorts Options Sheet
                var longPressTimer = null;
                var startX = 0;
                var startY = 0;
                var longPressActive = false;

                function cancelLongPress() {
                    if (longPressTimer) {
                        clearTimeout(longPressTimer);
                        longPressTimer = null;
                    }
                }

                document.addEventListener('touchstart', function(e) {
                    cancelLongPress();
                    longPressActive = false;
                    if (!isShortsRoute()) return;
                    if (!e.touches || e.touches.length !== 1) return;

                    var t = e.target;
                    if (t && t.closest) {
                        if (t.closest('button, a, input, textarea, [role="button"], ytm-reel-player-header-renderer, .reel-player-overlay-actions')) {
                            return;
                        }
                    }

                    startX = e.touches[0].clientX;
                    startY = e.touches[0].clientY;
                    longPressTimer = setTimeout(function() {
                        longPressTimer = null;
                        longPressActive = true;
                        window.__tubeFloatSuppressNextClick = true;
                        setTimeout(function() { window.__tubeFloatSuppressNextClick = false; }, 550);
                        openShortsOptionsFromJs();
                    }, 420);
                }, { passive: true, capture: true });

                document.addEventListener('touchmove', function(e) {
                    if (!longPressTimer || !e.touches || e.touches.length !== 1) return;
                    var dx = Math.abs(e.touches[0].clientX - startX);
                    var dy = Math.abs(e.touches[0].clientY - startY);
                    if (dx > 12 || dy > 12) {
                        cancelLongPress();
                    }
                }, { passive: true, capture: true });

                document.addEventListener('touchend', function(e) {
                    cancelLongPress();
                    if (longPressActive) {
                        longPressActive = false;
                    } else if (isShortsRoute() && document.documentElement.classList.contains('tubefloat-clear-screen')) {
                        // Tapping screen while Clear Screen is active cleanly restores controls if user taps top area
                        if (e.changedTouches && e.changedTouches[0] && e.changedTouches[0].clientY < 130) {
                            document.documentElement.classList.remove('tubefloat-clear-screen');
                        }
                    }
                }, { passive: true, capture: true });

                document.addEventListener('touchcancel', cancelLongPress, { passive: true, capture: true });
            }

            if (!window.__tubeFloatAdFreeInstalled) {
                window.__tubeFloatAdFreeInstalled = true;
                var pendingClean = false;
                var scheduleClean = function() {
                    if (pendingClean) return;
                    pendingClean = true;
                    setTimeout(function() {
                        pendingClean = false;
                        cleanYouTubeAds();
                    }, 180);
                };
                var obs = new MutationObserver(scheduleClean);
                obs.observe(document.documentElement || document.body, { childList: true, subtree: true });
                window.addEventListener('yt-navigate-finish', function() {
                    cleanYouTubeAds();
                    setTimeout(notifyPlaybackState, 250);
                });
                window.addEventListener('popstate', cleanYouTubeAds);
                setInterval(cleanYouTubeAds, 600);
                setInterval(notifyPlaybackState, 1500);
            }

            installShortsInteractions();
            cleanYouTubeAds();
            notifyPlaybackState();
        })();
    """.trimIndent()
}
