package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R

class BackgroundAudioService : Service() {

    private lateinit var notificationManager: NotificationManager
    private lateinit var audioManager: AudioManager
    private var mediaSession: MediaSession? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var pausedByFocusLoss = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                pausedByFocusLoss = false
                BackgroundPlaybackManager.userPausedFromNotification = true
                mainHandler.post { BackgroundPlaybackManager.onCommandPause?.invoke() }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (BackgroundPlaybackManager.isPlaying) {
                    pausedByFocusLoss = true
                    mainHandler.post { BackgroundPlaybackManager.onCommandPause?.invoke() }
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                if (pausedByFocusLoss) {
                    pausedByFocusLoss = false
                    BackgroundPlaybackManager.userPausedFromNotification = false
                    mainHandler.post { BackgroundPlaybackManager.onCommandPlay?.invoke() }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        ensureNotificationChannel()
        initMediaSession()
        acquireWakeLock()
        requestAudioFocus()
        BackgroundPlaybackManager.isServiceActive = true
        BackgroundPlaybackManager.onServiceStateUpdated = {
            mainHandler.post { refreshNotificationAndSession() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                BackgroundPlaybackManager.userPausedFromNotification = false
                requestAudioFocus()
                BackgroundPlaybackManager.onCommandPlay?.invoke()
                BackgroundPlaybackManager.updatePlaybackState(
                    playing = true,
                    title = BackgroundPlaybackManager.currentTitle,
                    artist = BackgroundPlaybackManager.currentArtist
                )
            }
            ACTION_PAUSE -> {
                BackgroundPlaybackManager.userPausedFromNotification = true
                BackgroundPlaybackManager.onCommandPause?.invoke()
                BackgroundPlaybackManager.updatePlaybackState(
                    playing = false,
                    title = BackgroundPlaybackManager.currentTitle,
                    artist = BackgroundPlaybackManager.currentArtist
                )
            }
            ACTION_NEXT -> {
                BackgroundPlaybackManager.onCommandNext?.invoke()
            }
            ACTION_STOP -> {
                BackgroundPlaybackManager.userPausedFromNotification = true
                BackgroundPlaybackManager.onCommandPause?.invoke()
                BackgroundPlaybackManager.isServiceActive = false
                stopForegroundCompat()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> Unit
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        updateMediaSessionState()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        BackgroundPlaybackManager.isServiceActive = false
        BackgroundPlaybackManager.onServiceStateUpdated = null
        abandonAudioFocus()
        releaseWakeLock()
        mediaSession?.isActive = false
        mediaSession?.release()
        mediaSession = null
        stopForegroundCompat()
        super.onDestroy()
    }

    private fun initMediaSession() {
        mediaSession = MediaSession(this, "TubeFloatMediaSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    BackgroundPlaybackManager.userPausedFromNotification = false
                    requestAudioFocus()
                    mainHandler.post { BackgroundPlaybackManager.onCommandPlay?.invoke() }
                }

                override fun onPause() {
                    BackgroundPlaybackManager.userPausedFromNotification = true
                    mainHandler.post { BackgroundPlaybackManager.onCommandPause?.invoke() }
                }

                override fun onSkipToNext() {
                    mainHandler.post { BackgroundPlaybackManager.onCommandNext?.invoke() }
                }

                override fun onSkipToPrevious() {
                    mainHandler.post { BackgroundPlaybackManager.onCommandPrevious?.invoke() }
                }

                override fun onStop() {
                    BackgroundPlaybackManager.userPausedFromNotification = true
                    mainHandler.post { BackgroundPlaybackManager.onCommandPause?.invoke() }
                    stopForegroundCompat()
                    stopSelf()
                }
            })
            isActive = true
        }
    }

    private fun refreshNotificationAndSession() {
        if (!BackgroundPlaybackManager.isServiceActive) return
        updateMediaSessionState()
        try {
            notificationManager.notify(NOTIFICATION_ID, buildNotification())
        } catch (_: Exception) {}
    }

    private fun updateMediaSessionState() {
        val session = mediaSession ?: return
        val isPlaying = BackgroundPlaybackManager.isPlaying
        val title = BackgroundPlaybackManager.currentTitle.ifBlank {
            getString(R.string.bg_audio_default_title)
        }
        val artist = BackgroundPlaybackManager.currentArtist.ifBlank {
            getString(R.string.bg_audio_default_artist)
        }

        val metadata = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
            .build()
        session.setMetadata(metadata)

        val stateCode = if (isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
        val state = PlaybackState.Builder()
            .setActions(
                PlaybackState.ACTION_PLAY or
                    PlaybackState.ACTION_PAUSE or
                    PlaybackState.ACTION_PLAY_PAUSE or
                    PlaybackState.ACTION_SKIP_TO_NEXT or
                    PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                    PlaybackState.ACTION_STOP
            )
            .setState(stateCode, PlaybackState.PLAYBACK_POSITION_UNKNOWN, if (isPlaying) 1.0f else 0f)
            .build()
        session.setPlaybackState(state)
    }

    private fun buildNotification(): Notification {
        val isPlaying = BackgroundPlaybackManager.isPlaying
        val title = BackgroundPlaybackManager.currentTitle.ifBlank {
            getString(R.string.bg_audio_default_title)
        }
        val artist = BackgroundPlaybackManager.currentArtist.ifBlank {
            getString(R.string.bg_audio_default_artist)
        }

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseAction = if (isPlaying) {
            Notification.Action.Builder(
                android.R.drawable.ic_media_pause,
                getString(R.string.action_pause),
                servicePendingIntent(ACTION_PAUSE, 1)
            ).build()
        } else {
            Notification.Action.Builder(
                android.R.drawable.ic_media_play,
                getString(R.string.action_play),
                servicePendingIntent(ACTION_PLAY, 2)
            ).build()
        }

        val nextAction = Notification.Action.Builder(
            android.R.drawable.ic_media_next,
            getString(R.string.action_next),
            servicePendingIntent(ACTION_NEXT, 3)
        ).build()

        val stopAction = Notification.Action.Builder(
            android.R.drawable.ic_menu_close_clear_cancel,
            getString(R.string.action_stop),
            servicePendingIntent(ACTION_STOP, 4)
        ).build()

        val mediaStyle = Notification.MediaStyle()
            .setMediaSession(mediaSession?.sessionToken)
            .setShowActionsInCompactView(0, 1)

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(R.drawable.ic_tubefloat_notif)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(contentPendingIntent)
            .setOngoing(isPlaying)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(playPauseAction)
            .addAction(nextAction)
            .addAction(stopAction)
            .setStyle(mediaStyle)
            .build()
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, BackgroundAudioService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val existing = notificationManager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.bg_audio_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.bg_audio_channel_desc)
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                notificationManager.createNotificationChannel(channel)
            }
        }
    }

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(audioFocusChangeListener)
                .build()
            audioFocusRequest = req
            audioManager.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                audioFocusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(audioFocusChangeListener)
        }
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TubeFloat::BackgroundAudio").apply {
                setReferenceCounted(false)
                acquire(60 * 60 * 1000L) // Safety 60-minute max timeout per continuous background session
            }
        } catch (_: Exception) {}
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}
        wakeLock = null
    }

    private fun stopForegroundCompat() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }

    companion object {
        private const val CHANNEL_ID = "tubefloat_background_audio"
        private const val NOTIFICATION_ID = 4091

        const val ACTION_START_OR_UPDATE = "com.example.action.BG_AUDIO_START"
        const val ACTION_PLAY = "com.example.action.BG_AUDIO_PLAY"
        const val ACTION_PAUSE = "com.example.action.BG_AUDIO_PAUSE"
        const val ACTION_NEXT = "com.example.action.BG_AUDIO_NEXT"
        const val ACTION_STOP = "com.example.action.BG_AUDIO_STOP"
    }
}
