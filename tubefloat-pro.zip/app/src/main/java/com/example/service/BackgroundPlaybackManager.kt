package com.example.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

object BackgroundPlaybackManager {
    @Volatile
    var isPlaying: Boolean = false
        private set

    @Volatile
    var isAppInBackground: Boolean = false
        private set

    @Volatile
    var userPausedFromNotification: Boolean = false

    @Volatile
    var isServiceActive: Boolean = false

    @Volatile
    var currentTitle: String = ""
        private set

    @Volatile
    var currentArtist: String = ""
        private set

    @Volatile
    var onCommandPlay: (() -> Unit)? = null

    @Volatile
    var onCommandPause: (() -> Unit)? = null

    @Volatile
    var onCommandNext: (() -> Unit)? = null

    @Volatile
    var onCommandPrevious: (() -> Unit)? = null

    @Volatile
    var onServiceStateUpdated: (() -> Unit)? = null

    fun updatePlaybackState(playing: Boolean, title: String, artist: String) {
        isPlaying = playing
        if (title.isNotBlank()) currentTitle = title
        if (artist.isNotBlank()) currentArtist = artist
        if (playing) {
            userPausedFromNotification = false
        }
        onServiceStateUpdated?.invoke()
    }

    fun setAppBackgroundState(inBackground: Boolean) {
        isAppInBackground = inBackground
    }

    fun startOrUpdateService(context: Context) {
        val intent = Intent(context, BackgroundAudioService::class.java).apply {
            action = BackgroundAudioService.ACTION_START_OR_UPDATE
        }
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (_: Exception) {
            // Best-effort fallback if OS prevents FGS start outside active window transition
        }
    }

    fun stopService(context: Context) {
        isServiceActive = false
        try {
            context.stopService(Intent(context, BackgroundAudioService::class.java))
        } catch (_: Exception) {}
    }

    fun clearCallbacks() {
        onCommandPlay = null
        onCommandPause = null
        onCommandNext = null
        onCommandPrevious = null
        onServiceStateUpdated = null
    }
}
