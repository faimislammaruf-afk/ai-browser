package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.service.BackgroundPlaybackManager
import com.example.ui.player.YouTubeWebViewScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.parseColor("#0F0F0F")),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.parseColor("#0F0F0F"))
        )
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F0F0F)
                ) {
                    YouTubeWebViewScreen()
                }
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) {
            BackgroundPlaybackManager.stopService(this)
        }
        super.onDestroy()
    }
}
